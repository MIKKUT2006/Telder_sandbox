
using System;
using System.Collections.Generic;
using System.IO;
using System.Globalization;

using UnityEngine;


namespace Game.World.Structures.EditorRuntime
{
    public class StructureEditorController :
        MonoBehaviour
    {
        private StructureDefinition current =
            new StructureDefinition();


        private List<
            StructureEditorContentScanner.BlockInfo
        > blocks =
            new List<
                StructureEditorContentScanner.BlockInfo
            >();


        private readonly List<
            StructureEditorContentScanner.BlockInfo
        > filteredBlocks =
            new List<
                StructureEditorContentScanner.BlockInfo
            >();


        private List<
            StructureEditorContentScanner.LootContentInfo
        > lootContents =
            new List<
                StructureEditorContentScanner.LootContentInfo
            >();


        private readonly List<
            StructureEditorContentScanner.LootContentInfo
        > filteredLootContents =
            new List<
                StructureEditorContentScanner.LootContentInfo
            >();


        private readonly Dictionary<
            string,
            StructureEditorContentScanner.LootContentInfo
        > lootById =
            new Dictionary<
                string,
                StructureEditorContentScanner.LootContentInfo
            >(
                StringComparer.OrdinalIgnoreCase
            );


        private string lootPickerSearch =
            string.Empty;


        private int lootPickerEntryIndex =
            -1;


        private Vector2 lootPickerScroll;


        private const float LootPickerRowHeight =
            58f;


        // Numeric fields use text buffers and commit only on Enter.
        // This allows intermediate text such as "", "0,", "-".
        private readonly Dictionary<
            string,
            string
        > numericFieldBuffers =
            new Dictionary<
                string,
                string
            >();


        private readonly Dictionary<
            string,
            StructureEditorContentScanner.BlockInfo
        > blocksById =
            new Dictionary<
                string,
                StructureEditorContentScanner.BlockInfo
            >(
                StringComparer.OrdinalIgnoreCase
            );


        private List<string> surfaceBiomes =
            new List<string>();


        private List<string> caveBiomes =
            new List<string>();


        // O(1) cell lookup.
        //
        // Old editor did a linear scan through current.Cells for every
        // visible grid cell on every OnGUI pass.
        private readonly Dictionary<
            int,
            StructureCellDefinition
        > cellIndex =
            new Dictionary<
                int,
                StructureCellDefinition
            >();


        private string selectedBlockId;


        private enum StructureEditLayer
        {
            Foreground,
            Background,
            Furniture
        }


        private enum StructureTransformEditMode
        {
            None,
            Rotate,
            Mirror
        }


        private StructureEditLayer editLayer =
            StructureEditLayer.Foreground;


        private StructureTransformEditMode transformEditMode =
            StructureTransformEditMode.None;


        private StructureLayerMetadata layerMetadata =
            new StructureLayerMetadata();


        private bool editBackground =>
            editLayer ==
            StructureEditLayer.Background;


        private int selectedCellX =
            -1;


        private int selectedCellY =
            -1;


        // TELDER_AREA_SELECTION_V1
        private bool areaSelectionActive;

        private bool areaSelecting;

        private bool areaMoving;

        private int areaStartX;

        private int areaStartY;

        private int areaEndX;

        private int areaEndY;

        private int moveStartX;

        private int moveStartY;

        private int moveOffsetX;

        private int moveOffsetY;


        private Vector2 blockScroll;

        private Vector2 settingsScroll;

        private Vector2 gridScroll;

        private Vector2 lootScroll;


        private string blockSearch =
            string.Empty;


        private string status =
            string.Empty;


        private GUIStyle editableTextFieldStyle;

        private GUIStyle cellIdStyle;

        private GUIStyle backgroundBadgeStyle;

        private GUIStyle furnitureBadgeStyle;


        private const float CellSize =
            34f;


        private const float PaletteWidth =
            270f;


        private const float SettingsWidth =
            410f;


        private const float PaletteRowHeight =
            62f;


        private void Start()
        {
            RefreshContent();

            NewStructure();
        }


        private void OnDestroy()
        {
            StructureEditorIconCache.Clear();

            StructureEditorLootIconCache.Clear();
        }


        private void Update()
        {
            if (
                Input.GetKeyDown(
                    KeyCode.F5
                )
            )
            {
                Save();
            }


            if (
                Input.GetKeyDown(
                    KeyCode.Z
                )
            )
            {
                CycleTransformEditMode();
            }


            if (
                Input.GetKeyDown(
                    KeyCode.X
                )
            )
            {
                CycleEditLayer();
            }
        }


        private void CycleTransformEditMode()
        {
            switch (
                transformEditMode
            )
            {
                case StructureTransformEditMode.None:
                    transformEditMode =
                        StructureTransformEditMode.Rotate;
                    break;

                case StructureTransformEditMode.Rotate:
                    transformEditMode =
                        StructureTransformEditMode.Mirror;
                    break;

                default:
                    transformEditMode =
                        StructureTransformEditMode.None;
                    break;
            }


            status =
                "Режим: " +
                GetTransformModeLabel();
        }


        private void CycleEditLayer()
        {
            switch (
                editLayer
            )
            {
                case StructureEditLayer.Foreground:
                    editLayer =
                        StructureEditLayer.Background;
                    break;

                case StructureEditLayer.Background:
                    editLayer =
                        StructureEditLayer.Furniture;
                    break;

                default:
                    editLayer =
                        StructureEditLayer.Foreground;
                    break;
            }


            status =
                "Слой: " +
                GetLayerLabel(
                    editLayer
                );
        }


                private void OnGUI()
        {
            global::UnityEngine.Cursor.visible = true;
            global::UnityEngine.Cursor.lockState = CursorLockMode.None;

            EnsureStyles();

            if (GUI.skin != null && GUI.skin.settings != null)
            {
                GUI.skin.settings.cursorColor = Color.white;
                GUI.skin.settings.selectionColor =
                    new Color(0.22f, 0.48f, 0.85f, 0.85f);
                GUI.skin.settings.cursorFlashSpeed = 0.8f;
                GUI.skin.settings.doubleClickSelectsWord = true;
            }

            DrawTopBar();
            DrawBlockPalette();
            DrawGrid();
            DrawSettings();
        }



        // =====================================================
        // STYLES
        // =====================================================

        private void EnsureStyles()
        {
            if (
                cellIdStyle ==
                null
            )
            {
                cellIdStyle =
                    new GUIStyle(
                        GUI.skin.label
                    );


                cellIdStyle.fontSize =
                    8;


                cellIdStyle.alignment =
                    TextAnchor.LowerLeft;


                cellIdStyle.normal.textColor =
                    Color.white;
            }


            if (
                backgroundBadgeStyle ==
                null
            )
            {
                backgroundBadgeStyle =
                    new GUIStyle(
                        GUI.skin.label
                    );


                backgroundBadgeStyle.fontSize =
                    8;


                backgroundBadgeStyle.alignment =
                    TextAnchor.LowerRight;


                backgroundBadgeStyle.normal.textColor =
                    new Color(
                        0.55f,
                        0.75f,
                        1f,
                        1f
                    );
            }
        
            if (
                furnitureBadgeStyle ==
                null
            )
            {
                furnitureBadgeStyle =
                    new GUIStyle(
                        GUI.skin.label
                    );


                furnitureBadgeStyle.fontSize =
                    8;


                furnitureBadgeStyle.alignment =
                    TextAnchor.UpperRight;


                furnitureBadgeStyle.normal.textColor =
                    new Color(
                        1f,
                        0.72f,
                        0.25f,
                        1f
                    );
            }
        }


        // =====================================================
        // TOP BAR
        // =====================================================

        private void DrawTopBar()
        {
            GUILayout.BeginArea(
                new Rect(
                    0f,
                    0f,
                    Screen.width,
                    54f
                ),
                GUI.skin.box
            );


            GUILayout.BeginHorizontal();


            GUILayout.Label(
                "TELDER STRUCTURE EDITOR",
                GUILayout.Width(
                    205f
                )
            );


            if (
                GUILayout.Button(
                    "Новая",
                    GUILayout.Width(
                        72f
                    )
                )
            )
            {
                NewStructure();
            }


            if (
                GUILayout.Button(
                    "Сохранить [F5]",
                    GUILayout.Width(
                        115f
                    )
                )
            )
            {
                Save();
            }


            if (
                GUILayout.Button(
                    "Обновить",
                    GUILayout.Width(
                        90f
                    )
                )
            )
            {
                StructureEditorIconCache.Clear();

                StructureEditorLootIconCache.Clear();

                RefreshContent();
            }


            GUILayout.Space(
                8f
            );


            DrawLayerButton(
                StructureEditLayer.Foreground,
                "ПЕРЕДНИЙ",
                new Color(
                    0.35f,
                    0.65f,
                    0.95f
                )
            );


            DrawLayerButton(
                StructureEditLayer.Background,
                "ЗАДНИЙ",
                new Color(
                    0.30f,
                    0.42f,
                    0.65f
                )
            );


            DrawLayerButton(
                StructureEditLayer.Furniture,
                "ФУРНИТУРА",
                new Color(
                    0.74f,
                    0.48f,
                    0.20f
                )
            );


            GUILayout.Space(
                8f
            );


            Color old =
                GUI.backgroundColor;


            if (
                transformEditMode !=
                StructureTransformEditMode.None
            )
            {
                GUI.backgroundColor =
                    new Color(
                        0.62f,
                        0.48f,
                        0.82f
                    );
            }


            if (
                GUILayout.Button(
                    GetTransformModeLabel() +
                    " [Z]",
                    GUILayout.Width(
                        145f
                    )
                )
            )
            {
                CycleTransformEditMode();
            }


            GUI.backgroundColor =
                old;


            GUILayout.Space(
                8f
            );


            GUILayout.Label(
                "X — слой"
            );


            GUILayout.Space(
                8f
            );


            GUILayout.Label(
                status
            );


            GUILayout.FlexibleSpace();


            GUILayout.EndHorizontal();

            GUILayout.EndArea();
        }


        private void DrawLayerButton(
            StructureEditLayer layer,
            string text,
            Color selectedColor
        )
        {
            Color old =
                GUI.backgroundColor;


            if (
                editLayer ==
                layer
            )
            {
                GUI.backgroundColor =
                    selectedColor;
            }


            if (
                GUILayout.Button(
                    text,
                    GUILayout.Width(
                        layer ==
                        StructureEditLayer.Furniture
                            ? 105f
                            : 92f
                    )
                )
            )
            {
                editLayer =
                    layer;


                status =
                    "Слой: " +
                    GetLayerLabel(
                        layer
                    );
            }


            GUI.backgroundColor =
                old;
        }


        // =====================================================
        // BLOCK PALETTE
        // =====================================================

                private void DrawBlockPalette()
        {
            Rect area = new Rect(
                0f,
                54f,
                PaletteWidth,
                Mathf.Max(1f, Screen.height - 54f)
            );

            GUI.Box(area, string.Empty);

            GUI.Label(
                new Rect(
                    area.x + 8f,
                    area.y + 7f,
                    area.width - 16f,
                    22f
                ),
                "БЛОКИ"
            );

            GUI.Label(
                new Rect(
                    area.x + 8f,
                    area.y + 28f,
                    area.width - 16f,
                    38f
                ),
                "ЛКМ — выбрать | сетка 4 в ряд"
            );

            string nextSearch = GUI.TextField(
                new Rect(
                    area.x + 8f,
                    area.y + 67f,
                    area.width - 16f,
                    24f
                ),
                blockSearch ?? string.Empty,
                GetEditableTextFieldStyle()
            );

            if (!string.Equals(
                    nextSearch,
                    blockSearch,
                    StringComparison.Ordinal
                ))
            {
                blockSearch = nextSearch;
                RebuildFilteredBlocks();
                blockScroll = Vector2.zero;
            }

            Rect viewport = new Rect(
                area.x + 8f,
                area.y + 97f,
                area.width - 16f,
                Mathf.Max(10f, area.height - 105f)
            );

            const int columns = 4;
            const float gap = 4f;
            const float tileHeight = 70f;

            float contentWidth = Mathf.Max(
                1f,
                viewport.width - 18f
            );

            float tileWidth = Mathf.Max(
                40f,
                (contentWidth - gap * (columns - 1)) / columns
            );

            int rowCount = Mathf.CeilToInt(
                filteredBlocks.Count / (float)columns
            );

            float contentHeight = Mathf.Max(
                viewport.height,
                rowCount * (tileHeight + gap)
            );

            Rect content = new Rect(
                0f,
                0f,
                contentWidth,
                contentHeight
            );

            blockScroll = GUI.BeginScrollView(
                viewport,
                blockScroll,
                content
            );

            GUIStyle labelStyle = new GUIStyle(GUI.skin.label);
            labelStyle.fontSize = 9;
            labelStyle.alignment = TextAnchor.LowerCenter;
            labelStyle.clipping = TextClipping.Clip;
            labelStyle.normal.textColor = Color.white;

            int firstRow = Mathf.Max(
                0,
                Mathf.FloorToInt(
                    blockScroll.y / (tileHeight + gap)
                ) - 1
            );

            int lastRow = Mathf.Min(
                Mathf.Max(0, rowCount - 1),
                Mathf.CeilToInt(
                    (blockScroll.y + viewport.height) /
                    (tileHeight + gap)
                ) + 1
            );

            for (int row = firstRow; row <= lastRow; row++)
            {
                for (int column = 0; column < columns; column++)
                {
                    int index = row * columns + column;

                    if (index < 0 || index >= filteredBlocks.Count)
                        continue;

                    StructureEditorContentScanner.BlockInfo block =
                        filteredBlocks[index];

                    Rect buttonRect = new Rect(
                        column * (tileWidth + gap),
                        row * (tileHeight + gap),
                        tileWidth,
                        tileHeight
                    );

                    Color old = GUI.backgroundColor;

                    if (string.Equals(
                            selectedBlockId,
                            block.ID,
                            StringComparison.OrdinalIgnoreCase
                        ))
                    {
                        GUI.backgroundColor =
                            new Color(0.35f, 0.55f, 0.90f);
                    }

                    if (GUI.Button(
                            buttonRect,
                            new GUIContent(
                                string.Empty,
                                block.DisplayLabel
                            )
                        ))
                    {
                        selectedBlockId = block.ID;
                    }

                    GUI.backgroundColor = old;

                    if (Event.current.type == EventType.Repaint)
                    {
                        Texture2D icon =
                            StructureEditorIconCache.Get(block);

                        float iconSize = Mathf.Min(
                            tileWidth - 8f,
                            43f
                        );

                        if (icon != null)
                        {
                            GUI.DrawTexture(
                                new Rect(
                                    buttonRect.x +
                                    (buttonRect.width - iconSize) * 0.5f,
                                    buttonRect.y + 4f,
                                    iconSize,
                                    iconSize
                                ),
                                icon,
                                ScaleMode.ScaleToFit,
                                true
                            );
                        }

                        string label =
                            block.DisplayLabel ??
                            block.ID ??
                            string.Empty;

                        if (label.Length > 10)
                            label = label.Substring(0, 9) + "…";

                        GUI.Label(
                            new Rect(
                                buttonRect.x + 2f,
                                buttonRect.y + buttonRect.height - 22f,
                                buttonRect.width - 4f,
                                19f
                            ),
                            label,
                            labelStyle
                        );
                    }
                }
            }

            GUI.EndScrollView();
        }



        // =====================================================
        // GRID
        // =====================================================

        
        private void DrawGrid()
        {
            float width =
                Mathf.Max(
                    100f,
                    Screen.width -
                    PaletteWidth -
                    SettingsWidth
                );


            Rect area =
                new Rect(
                    PaletteWidth,
                    54f,
                    width,
                    Mathf.Max(
                        1f,
                        Screen.height -
                        54f
                    )
                );


            GUI.Box(
                area,
                string.Empty
            );


            GUI.Label(
                new Rect(
                    area.x + 8f,
                    area.y + 7f,
                    area.width - 16f,
                    22f
                ),
                "СТРУКТУРА | Shift+ЛКМ — выделить | ЛКМ по выделению — перенести | Delete — удалить"
            );


            Rect viewport =
                new Rect(
                    area.x + 8f,
                    area.y + 31f,
                    Mathf.Max(
                        10f,
                        area.width - 16f
                    ),
                    Mathf.Max(
                        10f,
                        area.height - 39f
                    )
                );


            Rect content =
                new Rect(
                    0f,
                    0f,
                    Mathf.Max(
                        1f,
                        current.Width *
                        CellSize
                    ),
                    Mathf.Max(
                        1f,
                        current.Height *
                        CellSize
                    )
                );


            Event evt =
                Event.current;


            Vector2 screenMouse =
                evt.mousePosition;


            if (
                evt.type ==
                EventType.KeyDown
                &&
                evt.keyCode ==
                KeyCode.Delete
                &&
                areaSelectionActive
                &&
                GUIUtility.keyboardControl ==
                0
            )
            {
                DeleteAreaSelection();

                evt.Use();
            }


            if (
                evt.type ==
                EventType.KeyDown
                &&
                evt.keyCode ==
                KeyCode.Escape
                &&
                areaSelectionActive
            )
            {
                ClearAreaSelection();

                evt.Use();
            }


            gridScroll =
                GUI.BeginScrollView(
                    viewport,
                    gridScroll,
                    content
                );


            if (
                evt.type ==
                EventType.Repaint
            )
            {
                DrawVisibleGridCells(
                    viewport
                );


                DrawAreaSelectionOverlay();
            }


            GUI.EndScrollView();


            bool mouseInside =
                viewport.Contains(
                    screenMouse
                );


            int mouseX =
                -1;


            int mouseY =
                -1;


            if (mouseInside)
            {
                float contentX =
                    screenMouse.x -
                    viewport.x +
                    gridScroll.x;


                float contentY =
                    screenMouse.y -
                    viewport.y +
                    gridScroll.y;


                mouseX =
                    Mathf.FloorToInt(
                        contentX /
                        CellSize
                    );


                int displayY =
                    Mathf.FloorToInt(
                        contentY /
                        CellSize
                    );


                mouseY =
                    current.Height -
                    1 -
                    displayY;


                if (
                    mouseX <
                    0
                    ||
                    mouseX >=
                    current.Width
                    ||
                    mouseY <
                    0
                    ||
                    mouseY >=
                    current.Height
                )
                {
                    mouseX =
                        -1;

                    mouseY =
                        -1;
                }
            }


            if (
                evt.type ==
                EventType.MouseDown
                &&
                evt.button ==
                0
                &&
                mouseX >=
                0
            )
            {
                if (evt.shift)
                {
                    BeginAreaSelection(
                        mouseX,
                        mouseY
                    );


                    evt.Use();

                    return;
                }


                if (
                    areaSelectionActive
                    &&
                    IsInsideAreaSelection(
                        mouseX,
                        mouseY
                    )
                )
                {
                    areaMoving =
                        true;


                    moveStartX =
                        mouseX;


                    moveStartY =
                        mouseY;


                    moveOffsetX =
                        0;


                    moveOffsetY =
                        0;


                    evt.Use();

                    return;
                }


                ClearAreaSelection();


                selectedCellX =
                    mouseX;


                selectedCellY =
                    mouseY;


                Place(
                    mouseX,
                    mouseY
                );


                evt.Use();

                return;
            }


            if (
                evt.type ==
                EventType.MouseDrag
                &&
                evt.button ==
                0
                &&
                mouseX >=
                0
            )
            {
                if (areaSelecting)
                {
                    UpdateAreaSelection(
                        mouseX,
                        mouseY
                    );


                    evt.Use();

                    return;
                }


                if (areaMoving)
                {
                    UpdateMoveOffset(
                        mouseX -
                        moveStartX,
                        mouseY -
                        moveStartY
                    );


                    evt.Use();

                    return;
                }


                selectedCellX =
                    mouseX;


                selectedCellY =
                    mouseY;


                Place(
                    mouseX,
                    mouseY
                );


                evt.Use();

                return;
            }


            if (
                evt.type ==
                EventType.MouseUp
                &&
                evt.button ==
                0
            )
            {
                if (areaSelecting)
                {
                    areaSelecting =
                        false;


                    areaSelectionActive =
                        true;


                    evt.Use();

                    return;
                }


                if (areaMoving)
                {
                    CommitAreaMove();


                    areaMoving =
                        false;


                    evt.Use();

                    return;
                }
            }


            if (
                (
                    evt.type ==
                    EventType.MouseDown
                    ||
                    evt.type ==
                    EventType.MouseDrag
                )
                &&
                evt.button ==
                1
                &&
                mouseX >=
                0
            )
            {
                selectedCellX =
                    mouseX;


                selectedCellY =
                    mouseY;


                Remove(
                    mouseX,
                    mouseY
                );


                evt.Use();
            }
        }


        
        private void BeginAreaSelection(
            int x,
            int y
        )
        {
            areaSelecting =
                true;


            areaMoving =
                false;


            areaSelectionActive =
                true;


            areaStartX =
                x;


            areaEndX =
                x;


            areaStartY =
                y;


            areaEndY =
                y;


            moveOffsetX =
                0;


            moveOffsetY =
                0;
        }


        private void UpdateAreaSelection(
            int x,
            int y
        )
        {
            areaEndX =
                Mathf.Clamp(
                    x,
                    0,
                    current.Width - 1
                );


            areaEndY =
                Mathf.Clamp(
                    y,
                    0,
                    current.Height - 1
                );
        }


        private void ClearAreaSelection()
        {
            areaSelectionActive =
                false;


            areaSelecting =
                false;


            areaMoving =
                false;


            moveOffsetX =
                0;


            moveOffsetY =
                0;
        }


        private bool IsInsideAreaSelection(
            int x,
            int y
        )
        {
            if (!areaSelectionActive)
                return false;


            int minX =
                Mathf.Min(
                    areaStartX,
                    areaEndX
                );


            int maxX =
                Mathf.Max(
                    areaStartX,
                    areaEndX
                );


            int minY =
                Mathf.Min(
                    areaStartY,
                    areaEndY
                );


            int maxY =
                Mathf.Max(
                    areaStartY,
                    areaEndY
                );


            return
                x >= minX
                &&
                x <= maxX
                &&
                y >= minY
                &&
                y <= maxY;
        }


        private void UpdateMoveOffset(
            int requestedX,
            int requestedY
        )
        {
            int minX =
                Mathf.Min(
                    areaStartX,
                    areaEndX
                );


            int maxX =
                Mathf.Max(
                    areaStartX,
                    areaEndX
                );


            int minY =
                Mathf.Min(
                    areaStartY,
                    areaEndY
                );


            int maxY =
                Mathf.Max(
                    areaStartY,
                    areaEndY
                );


            moveOffsetX =
                Mathf.Clamp(
                    requestedX,
                    -minX,
                    current.Width -
                    1 -
                    maxX
                );


            moveOffsetY =
                Mathf.Clamp(
                    requestedY,
                    -minY,
                    current.Height -
                    1 -
                    maxY
                );
        }


        private void DeleteAreaSelection()
        {
            if (
                !areaSelectionActive
                ||
                current.Cells ==
                null
            )
            {
                return;
            }


            for (
                int i =
                    current.Cells.Count -
                    1;
                i >=
                0;
                i--
            )
            {
                StructureCellDefinition cell =
                    current.Cells[i];


                if (
                    cell !=
                    null
                    &&
                    IsInsideAreaSelection(
                        cell.X,
                        cell.Y
                    )
                )
                {
                    current.Cells.RemoveAt(
                        i
                    );
                }
            }


            RebuildCellIndex();


            selectedCellX =
                -1;


            selectedCellY =
                -1;


            status =
                "Выделенная область удалена";


            ClearAreaSelection();
        }


        private void CommitAreaMove()
        {
            if (
                !areaSelectionActive
                ||
                current.Cells ==
                null
            )
            {
                return;
            }


            if (
                moveOffsetX ==
                0
                &&
                moveOffsetY ==
                0
            )
            {
                return;
            }


            List<StructureCellDefinition> moving =
                new List<StructureCellDefinition>();


            HashSet<int> movingKeys =
                new HashSet<int>();


            for (
                int i = 0;
                i < current.Cells.Count;
                i++
            )
            {
                StructureCellDefinition cell =
                    current.Cells[i];


                if (
                    cell !=
                    null
                    &&
                    IsInsideAreaSelection(
                        cell.X,
                        cell.Y
                    )
                )
                {
                    moving.Add(
                        cell
                    );


                    movingKeys.Add(
                        cell.X +
                        cell.Y *
                        current.Width
                    );
                }
            }


            HashSet<int> destinationKeys =
                new HashSet<int>();


            for (
                int i = 0;
                i < moving.Count;
                i++
            )
            {
                StructureCellDefinition cell =
                    moving[i];


                int targetX =
                    cell.X +
                    moveOffsetX;


                int targetY =
                    cell.Y +
                    moveOffsetY;


                destinationKeys.Add(
                    targetX +
                    targetY *
                    current.Width
                );
            }


            for (
                int i =
                    current.Cells.Count -
                    1;
                i >=
                0;
                i--
            )
            {
                StructureCellDefinition cell =
                    current.Cells[i];


                if (cell == null)
                    continue;


                int key =
                    cell.X +
                    cell.Y *
                    current.Width;


                if (
                    !movingKeys.Contains(
                        key
                    )
                    &&
                    destinationKeys.Contains(
                        key
                    )
                )
                {
                    current.Cells.RemoveAt(
                        i
                    );
                }
            }


            for (
                int i = 0;
                i < moving.Count;
                i++
            )
            {
                moving[i].X +=
                    moveOffsetX;


                moving[i].Y +=
                    moveOffsetY;
            }


            areaStartX +=
                moveOffsetX;


            areaEndX +=
                moveOffsetX;


            areaStartY +=
                moveOffsetY;


            areaEndY +=
                moveOffsetY;


            moveOffsetX =
                0;


            moveOffsetY =
                0;


            RebuildCellIndex();


            status =
                "Выделенная область перемещена";
        }


        private void DrawAreaSelectionOverlay()
        {
            if (!areaSelectionActive)
                return;


            int minX =
                Mathf.Min(
                    areaStartX,
                    areaEndX
                );


            int maxX =
                Mathf.Max(
                    areaStartX,
                    areaEndX
                );


            int minY =
                Mathf.Min(
                    areaStartY,
                    areaEndY
                );


            int maxY =
                Mathf.Max(
                    areaStartY,
                    areaEndY
                );


            if (areaMoving)
            {
                minX +=
                    moveOffsetX;


                maxX +=
                    moveOffsetX;


                minY +=
                    moveOffsetY;


                maxY +=
                    moveOffsetY;
            }


            int topDisplayY =
                current.Height -
                1 -
                maxY;


            Rect selectionRect =
                new Rect(
                    minX *
                    CellSize,
                    topDisplayY *
                    CellSize,
                    (
                        maxX -
                        minX +
                        1
                    )
                    *
                    CellSize,
                    (
                        maxY -
                        minY +
                        1
                    )
                    *
                    CellSize
                );


            Color old =
                GUI.color;


            GUI.color =
                areaMoving
                    ? new Color(
                        0.35f,
                        1f,
                        0.55f,
                        0.18f
                    )
                    : new Color(
                        0.30f,
                        0.65f,
                        1f,
                        0.18f
                    );


            GUI.DrawTexture(
                selectionRect,
                Texture2D.whiteTexture
            );


            GUI.color =
                areaMoving
                    ? new Color(
                        0.45f,
                        1f,
                        0.60f,
                        0.95f
                    )
                    : new Color(
                        0.45f,
                        0.75f,
                        1f,
                        0.95f
                    );


            const float border =
                2f;


            GUI.DrawTexture(
                new Rect(
                    selectionRect.x,
                    selectionRect.y,
                    selectionRect.width,
                    border
                ),
                Texture2D.whiteTexture
            );


            GUI.DrawTexture(
                new Rect(
                    selectionRect.x,
                    selectionRect.yMax -
                    border,
                    selectionRect.width,
                    border
                ),
                Texture2D.whiteTexture
            );


            GUI.DrawTexture(
                new Rect(
                    selectionRect.x,
                    selectionRect.y,
                    border,
                    selectionRect.height
                ),
                Texture2D.whiteTexture
            );


            GUI.DrawTexture(
                new Rect(
                    selectionRect.xMax -
                    border,
                    selectionRect.y,
                    border,
                    selectionRect.height
                ),
                Texture2D.whiteTexture
            );


            GUI.color =
                old;
        }

        private void DrawVisibleGridCells(
            Rect viewport
        )
        {
            int firstX =
                Mathf.Clamp(
                    Mathf.FloorToInt(
                        gridScroll.x /
                        CellSize
                    )
                    -
                    1,
                    0,
                    Mathf.Max(
                        0,
                        current.Width -
                        1
                    )
                );


            int lastX =
                Mathf.Clamp(
                    Mathf.CeilToInt(
                        (
                            gridScroll.x +
                            viewport.width
                        )
                        /
                        CellSize
                    )
                    +
                    1,
                    0,
                    Mathf.Max(
                        0,
                        current.Width -
                        1
                    )
                );


            int firstDisplayY =
                Mathf.Clamp(
                    Mathf.FloorToInt(
                        gridScroll.y /
                        CellSize
                    )
                    -
                    1,
                    0,
                    Mathf.Max(
                        0,
                        current.Height -
                        1
                    )
                );


            int lastDisplayY =
                Mathf.Clamp(
                    Mathf.CeilToInt(
                        (
                            gridScroll.y +
                            viewport.height
                        )
                        /
                        CellSize
                    )
                    +
                    1,
                    0,
                    Mathf.Max(
                        0,
                        current.Height -
                        1
                    )
                );


            for (
                int displayY = firstDisplayY;
                displayY <= lastDisplayY;
                displayY++
            )
            {
                int y =
                    current.Height -
                    1 -
                    displayY;


                for (
                    int x = firstX;
                    x <= lastX;
                    x++
                )
                {
                    Rect cellRect =
                        new Rect(
                            x *
                            CellSize,
                            displayY *
                            CellSize,
                            CellSize -
                            1f,
                            CellSize -
                            1f
                        );


                    StructureCellDefinition cell =
                        FindCell(
                            x,
                            y
                        );


                    Color old =
                        GUI.backgroundColor;


                    if (
                        x ==
                        current.OriginX
                        &&
                        y ==
                        current.OriginY
                    )
                    {
                        GUI.backgroundColor =
                            new Color(
                                0.30f,
                                0.45f,
                                0.25f
                            );
                    }
                    else if (
                        x ==
                        selectedCellX
                        &&
                        y ==
                        selectedCellY
                    )
                    {
                        GUI.backgroundColor =
                            new Color(
                                0.45f,
                                0.45f,
                                0.75f
                            );
                    }
                    else
                    {
                        GUI.backgroundColor =
                            new Color(
                                0.16f,
                                0.16f,
                                0.18f
                            );
                    }


                    GUI.Box(
                        cellRect,
                        string.Empty
                    );


                    GUI.backgroundColor =
                        old;


                    DrawCellVisual(
                        cellRect,
                        cell
                    );


                    if (
                        cell !=
                        null
                    )
                    {
                        StructureLayerCellMetadata metadata =
                            layerMetadata.Get(
                                x,
                                y
                            );


                        string activeId =
                            GetLayerId(
                                cell,
                                metadata,
                                editLayer
                            );


                        if (
                            !string.IsNullOrWhiteSpace(
                                activeId
                            )
                        )
                        {
                            GUI.Label(
                                cellRect,
                                ShortId(
                                    activeId
                                ),
                                cellIdStyle
                            );
                        }
                    }
                }
            }
        }


        private void DrawCellVisual(
            Rect cellRect,
            StructureCellDefinition cell
        )
        {
            if (
                cell ==
                null
            )
            {
                return;
            }


            StructureLayerCellMetadata metadata =
                layerMetadata.Get(
                    cell.X,
                    cell.Y
                );


            Rect iconRect =
                new Rect(
                    cellRect.x +
                    2f,
                    cellRect.y +
                    2f,
                    cellRect.width -
                    4f,
                    cellRect.height -
                    4f
                );


            if (
                !string.IsNullOrWhiteSpace(
                    cell.BackgroundId
                )
            )
            {
                Texture2D background =
                    StructureEditorIconCache.Get(
                        cell.BackgroundId
                    );


                DrawTransformedIcon(
                    iconRect,
                    background,
                    metadata !=
                        null
                            ? metadata.BackgroundTransform
                            : (byte)0,
                    new Color(
                        0.68f,
                        0.68f,
                        0.68f,
                        1f
                    )
                );
            }


            if (
                metadata !=
                null
                &&
                !string.IsNullOrWhiteSpace(
                    metadata.FurnitureId
                )
            )
            {
                Texture2D furniture =
                    StructureEditorIconCache.Get(
                        metadata.FurnitureId
                    );


                DrawTransformedIcon(
                    iconRect,
                    furniture,
                    metadata.FurnitureTransform,
                    Color.white
                );
            }


            if (
                !string.IsNullOrWhiteSpace(
                    cell.ForegroundId
                )
            )
            {
                Texture2D foreground =
                    StructureEditorIconCache.Get(
                        cell.ForegroundId
                    );


                DrawTransformedIcon(
                    iconRect,
                    foreground,
                    metadata !=
                        null
                            ? metadata.ForegroundTransform
                            : (byte)0,
                    Color.white
                );
            }


            if (
                !string.IsNullOrWhiteSpace(
                    cell.BackgroundId
                )
            )
            {
                GUI.Label(
                    cellRect,
                    "BG",
                    backgroundBadgeStyle
                );
            }


            if (
                metadata !=
                null
                &&
                !string.IsNullOrWhiteSpace(
                    metadata.FurnitureId
                )
            )
            {
                GUI.Label(
                    cellRect,
                    "F",
                    furnitureBadgeStyle
                );
            }
        }


        private static void DrawTransformedIcon(
            Rect rect,
            Texture2D texture,
            byte transform,
            Color color
        )
        {
            if (
                texture ==
                null
            )
            {
                return;
            }


            Matrix4x4 oldMatrix =
                GUI.matrix;


            Color oldColor =
                GUI.color;


            int rotation =
                transform &
                0x03;


            bool mirrored =
                (
                    transform &
                    0x04
                )
                !=
                0;


            GUI.color =
                color;


            GUIUtility.RotateAroundPivot(
                -rotation *
                90f,
                rect.center
            );


            Rect uv =
                new Rect(
                    0f,
                    0f,
                    1f,
                    1f
                );


            if (mirrored)
            {
                uv.x =
                    1f;


                uv.width =
                    -1f;
            }


            GUI.DrawTextureWithTexCoords(
                rect,
                texture,
                uv,
                true
            );


            GUI.matrix =
                oldMatrix;


            GUI.color =
                oldColor;
        }


        // =====================================================
        // SETTINGS
        // =====================================================

        private void DrawSettings()
        {
            GUILayout.BeginArea(
                new Rect(
                    Screen.width -
                    SettingsWidth,
                    54f,
                    SettingsWidth,
                    Mathf.Max(
                        1f,
                        Screen.height -
                        54f
                    )
                ),
                GUI.skin.box
            );


            settingsScroll =
                GUILayout.BeginScrollView(
                    settingsScroll
                );


            GUILayout.Label(
                "ПАРАМЕТРЫ"
            );


            DrawExistingStructures();


            GUILayout.Space(
                8f
            );


            current.ID =
                LabeledText(
                    "ID",
                    current.ID
                );


            current.DisplayName =
                LabeledText(
                    "Имя",
                    current.DisplayName
                );


            GUILayout.Label(
                "Размер"
            );


            current.Width =
                BufferedIntField(
                    "structure.width",
                    "Width",
                    current.Width,
                    1,
                    128
                );


            current.Height =
                BufferedIntField(
                    "structure.height",
                    "Height",
                    current.Height,
                    1,
                    128
                );


            current.OriginX =
                BufferedIntField(
                    "structure.originX",
                    "Origin X",
                    current.OriginX,
                    0,
                    Mathf.Max(
                        0,
                        current.Width -
                        1
                    )
                );


            current.OriginY =
                BufferedIntField(
                    "structure.originY",
                    "Origin Y",
                    current.OriginY,
                    0,
                    Mathf.Max(
                        0,
                        current.Height -
                        1
                    )
                );


            GUILayout.Space(
                8f
            );


            GUILayout.Label(
                "Тип структуры"
            );


            current.Type =
                (StructureType)
                GUILayout.SelectionGrid(
                    (int)
                    current.Type,

                    new[]
                    {
                        "ОБЫЧНАЯ",
                        "ДЕРЕВО"
                    },

                    1
                );


            if (
                current.Type ==
                StructureType.Tree
            )
            {
                GUILayout.Label(
                    "Для ДЕРЕВА Origin X = колонна ствола."
                );
            }


            GUILayout.Space(
                8f
            );


            GUILayout.Label(
                "Тип появления"
            );


            current.SpawnType =
                (StructureSpawnType)
                GUILayout.SelectionGrid(
                    (int)
                    current.SpawnType,

                    new[]
                    {
                        "ПЕЩЕРА",
                        "ПОВЕРХНОСТЬ",
                        "ЛЮБОЙ"
                    },

                    1
                );


            GUILayout.Space(
                8f
            );


            GUILayout.Label(
                "Фильтр биома"
            );


            StructureBiomeSource oldBiomeSource =
                current.BiomeSource;


            current.BiomeSource =
                (StructureBiomeSource)
                GUILayout.SelectionGrid(
                    (int)
                    current.BiomeSource,

                    new[]
                    {
                        "ПОВЕРХНОСТНЫЙ",
                        "ПЕЩЕРНЫЙ",
                        "ЛЮБОЙ"
                    },

                    1
                );


            if (
                current.BiomeSource !=
                oldBiomeSource
            )
            {
                if (
                    current.Biomes ==
                    null
                )
                {
                    current.Biomes =
                        new List<string>();
                }


                current.Biomes.Clear();


                if (
                    current.BiomeSource ==
                    StructureBiomeSource.Cave
                    &&
                    current.SpawnType ==
                    StructureSpawnType.Surface
                )
                {
                    current.SpawnType =
                        StructureSpawnType.Underground;
                }
            }


            if (
                current.BiomeSource ==
                StructureBiomeSource.Cave
                &&
                current.SpawnType ==
                StructureSpawnType.Surface
            )
            {
                GUILayout.Label(
                    "Пещерный биом не используется на поверхности. " +
                    "Выбери ПЕЩЕРА или ЛЮБОЙ."
                );
            }


            current.SpawnChance =
                BufferedFloatField(
                    "structure.spawnChance",
                    "Шанс 0..1",
                    current.SpawnChance,
                    0f,
                    1f
                );


            current.RegionSize =
                BufferedIntField(
                    "structure.regionSize",
                    "Region size",
                    current.RegionSize,
                    8,
                    4096
                );


            current.RequireFreeSpace =
                GUILayout.Toggle(
                    current.RequireFreeSpace,
                    "Искать свободное пространство"
                );


            current.FreeSpacePadding =
                BufferedIntField(
                    "structure.freeSpacePadding",
                    "Отступ воздуха",
                    current.FreeSpacePadding,
                    0,
                    64
                );


            current.UseHeightRange =
                GUILayout.Toggle(
                    current.UseHeightRange,
                    "Ограничить высоту"
                );


            if (
                current.UseHeightRange
            )
            {
                current.MinY =
                    BufferedIntField(
                        "structure.minY",
                        "Min Y",
                        current.MinY,
                        -1000000,
                        1000000
                    );


                current.MaxY =
                    BufferedIntField(
                        "structure.maxY",
                        "Max Y",
                        current.MaxY,
                        -1000000,
                        1000000
                    );
            }


            GUILayout.Space(
                8f
            );


            DrawBiomes();


            GUILayout.Space(
                10f
            );


            DrawSelectedCell();


            GUILayout.EndScrollView();

            GUILayout.EndArea();
        }


        private void DrawExistingStructures()
        {
            GUILayout.Label(
                "СУЩЕСТВУЮЩИЕ"
            );


            IReadOnlyList<
                StructureDefinition
            > structures =
                StructureRegistry.GetAll();


            for (
                int i = 0;
                i < structures.Count;
                i++
            )
            {
                StructureDefinition structure =
                    structures[i];


                if (
                    structure ==
                    null
                )
                {
                    continue;
                }


                if (
                    GUILayout.Button(
                        "Загрузить: " +
                        structure.DisplayName
                    )
                )
                {
                    LoadStructure(
                        structure
                    );
                }
            }
        }


        private void LoadStructure(
            StructureDefinition structure
        )
        {
            string fileName =
                structure.ID
                    .Replace(
                        ":",
                        "_"
                    )
                    .Replace(
                        "/",
                        "_"
                    )
                    .Replace(
                        "\\",
                        "_"
                    )
                +
                ".json";


            string file =
                Path.Combine(
                    StructurePaths.Folder,
                    fileName
                );


            if (
                !File.Exists(
                    file
                )
            )
            {
                return;
            }


            StructureDefinition loaded =
                JsonUtility.FromJson<
                    StructureDefinition
                >(
                    File.ReadAllText(
                        file
                    )
                );


            if (
                loaded ==
                null
            )
            {
                return;
            }


            current =
                loaded;


            layerMetadata =
                StructureLayerMetadataStore.Load(
                    current.ID
                );


            numericFieldBuffers.Clear();


            lootPickerEntryIndex =
                -1;


            NormalizeCurrent();

            RebuildCellIndex();


            selectedCellX =
                -1;


            selectedCellY =
                -1;


            gridScroll =
                Vector2.zero;


            status =
                "Загружено: " +
                current.ID;
        }


        private void DrawBiomes()
        {
            GUILayout.Label(
                "БИОМЫ (ничего = все)"
            );


            if (
                current.Biomes ==
                null
            )
            {
                current.Biomes =
                    new List<string>();
            }


            if (
                current.BiomeSource ==
                StructureBiomeSource.Surface
            )
            {
                DrawBiomeList(
                    "Поверхностные",
                    surfaceBiomes
                );


                return;
            }


            if (
                current.BiomeSource ==
                StructureBiomeSource.Cave
            )
            {
                DrawBiomeList(
                    "Пещерные",
                    caveBiomes
                );


                return;
            }


            DrawBiomeList(
                "Поверхностные",
                surfaceBiomes
            );


            GUILayout.Space(
                6f
            );


            DrawBiomeList(
                "Пещерные",
                caveBiomes
            );
        }


        private void DrawBiomeList(
            string title,
            List<string> list
        )
        {
            GUILayout.Label(
                title +
                " (" +
                (
                    list !=
                    null
                        ? list.Count
                        : 0
                ) +
                ")"
            );


            if (
                list ==
                null
                ||
                list.Count ==
                0
            )
            {
                GUILayout.Label(
                    "Нет доступных биомов."
                );


                return;
            }


            for (
                int i = 0;
                i < list.Count;
                i++
            )
            {
                string biome =
                    list[i];


                bool enabled =
                    current.Biomes.Contains(
                        biome
                    );


                bool next =
                    GUILayout.Toggle(
                        enabled,
                        biome
                    );


                if (
                    next
                    &&
                    !enabled
                )
                {
                    current.Biomes.Add(
                        biome
                    );
                }
                else if (
                    !next
                    &&
                    enabled
                )
                {
                    current.Biomes.Remove(
                        biome
                    );
                }
            }
        }


        // =====================================================
        // SELECTED CELL / LOOT
        // =====================================================

        private void DrawSelectedCell()
        {
            GUILayout.Label(
                "ВЫБРАННАЯ КЛЕТКА"
            );


            if (
                selectedCellX <
                0
                ||
                selectedCellY <
                0
            )
            {
                GUILayout.Label(
                    "Выбери клетку."
                );


                return;
            }


            GUILayout.Label(
                selectedCellX +
                ", " +
                selectedCellY
            );


            StructureCellDefinition cell =
                FindCell(
                    selectedCellX,
                    selectedCellY
                );


            if (
                cell ==
                null
            )
            {
                GUILayout.Label(
                    "Пусто"
                );


                return;
            }


            GUILayout.Label(
                "Foreground: " +
                (
                    string.IsNullOrWhiteSpace(
                        cell.ForegroundId
                    )
                        ? "-"
                        : cell.ForegroundId
                )
            );


            GUILayout.Label(
                "Background: " +
                (
                    string.IsNullOrWhiteSpace(
                        cell.BackgroundId
                    )
                        ? "-"
                        : cell.BackgroundId
                )
            );


            StructureLayerCellMetadata metadata =
                layerMetadata.Get(
                    selectedCellX,
                    selectedCellY
                );


            GUILayout.Label(
                "Furniture: " +
                (
                    metadata ==
                        null
                    ||
                    string.IsNullOrWhiteSpace(
                        metadata.FurnitureId
                    )
                        ? "-"
                        : metadata.FurnitureId
                )
            );


            GUILayout.Label(
                "Активный слой: " +
                GetLayerLabel(
                    editLayer
                )
            );


            GUILayout.Label(
                "Transform: " +
                TransformLabel(
                    GetLayerTransform(
                        metadata,
                        editLayer
                    )
                )
            );


            if (
                !IsChestId(
                    cell.ForegroundId
                )
            )
            {
                GUILayout.Label(
                    "Loot доступен только для chest."
                );


                return;
            }


            GUILayout.Label(
                "LOOT TABLE"
            );


            if (
                cell.Loot ==
                null
            )
            {
                cell.Loot =
                    new List<
                        StructureLootEntryDefinition
                    >();
            }


            lootScroll =
                GUILayout.BeginScrollView(
                    lootScroll,
                    GUILayout.Height(
                        220f
                    )
                );


            for (
                int i = 0;
                i < cell.Loot.Count;
                i++
            )
            {
                StructureLootEntryDefinition entry =
                    cell.Loot[i];


                GUILayout.BeginVertical(
                    GUI.skin.box
                );


                DrawLootSelectedContent(
                    entry,
                    i
                );


                entry.Chance =
                    BufferedFloatField(
                        "loot." +
                        i +
                        ".chance",
                        "Chance",
                        entry.Chance,
                        0f,
                        1f
                    );


                entry.MinCount =
                    BufferedIntField(
                        "loot." +
                        i +
                        ".min",
                        "Min",
                        entry.MinCount,
                        1,
                        9999
                    );


                entry.MaxCount =
                    BufferedIntField(
                        "loot." +
                        i +
                        ".max",
                        "Max",
                        entry.MaxCount,
                        entry.MinCount,
                        9999
                    );


                if (
                    lootPickerEntryIndex ==
                    i
                )
                {
                    DrawLootPicker(
                        entry
                    );
                }


                if (
                    GUILayout.Button(
                        "Удалить loot"
                    )
                )
                {
                    cell.Loot.RemoveAt(
                        i
                    );


                    lootPickerEntryIndex =
                        -1;


                    numericFieldBuffers.Clear();


                    i--;


                    GUILayout.EndVertical();


                    continue;
                }


                GUILayout.EndVertical();
            }


            GUILayout.EndScrollView();


            if (
                GUILayout.Button(
                    "+ Добавить loot"
                )
            )
            {
                cell.Loot.Add(
                    new StructureLootEntryDefinition
                    {
                        ItemId =
                            lootContents.Count >
                            0
                                ? lootContents[
                                    0
                                ].ID
                                : "game:stone",

                        Chance =
                            1f,

                        MinCount =
                            1,

                        MaxCount =
                            1
                    }
                );
            }
        }


        private void DrawLootSelectedContent(
            StructureLootEntryDefinition entry,
            int entryIndex
        )
        {
            GUILayout.BeginHorizontal();


            Texture2D icon =
                null;


            string label =
                string.IsNullOrWhiteSpace(
                    entry.ItemId
                )
                    ? "Не выбран"
                    : entry.ItemId;


            if (
                !string.IsNullOrWhiteSpace(
                    entry.ItemId
                )
                &&
                lootById.TryGetValue(
                    entry.ItemId,
                    out StructureEditorContentScanner.LootContentInfo info
                )
            )
            {
                icon =
                    StructureEditorLootIconCache.Get(
                        info
                    );


                label =
                    info.DisplayLabel;
            }


            Rect iconRect =
                GUILayoutUtility.GetRect(
                    48f,
                    48f,
                    GUILayout.Width(
                        48f
                    ),
                    GUILayout.Height(
                        48f
                    )
                );


            GUI.Box(
                iconRect,
                string.Empty
            );


            if (
                icon !=
                null
            )
            {
                GUI.DrawTexture(
                    new Rect(
                        iconRect.x +
                        3f,
                        iconRect.y +
                        3f,
                        iconRect.width -
                        6f,
                        iconRect.height -
                        6f
                    ),
                    icon,
                    ScaleMode.ScaleToFit,
                    true
                );
            }


            GUILayout.Label(
                label,
                GUILayout.MinHeight(
                    48f
                )
            );


            if (
                GUILayout.Button(
                    lootPickerEntryIndex ==
                    entryIndex
                        ? "Закрыть"
                        : "Выбрать",
                    GUILayout.Width(
                        78f
                    ),
                    GUILayout.Height(
                        38f
                    )
                )
            )
            {
                lootPickerEntryIndex =
                    lootPickerEntryIndex ==
                    entryIndex
                        ? -1
                        : entryIndex;


                lootPickerScroll =
                    Vector2.zero;
            }


            GUILayout.EndHorizontal();
        }


        private void DrawLootPicker(
            StructureLootEntryDefinition entry
        )
        {
            GUILayout.BeginVertical(
                GUI.skin.box
            );


            GUILayout.Label(
                "Выбор item / block"
            );


            string nextSearch =
                GUILayout.TextField(
                    lootPickerSearch ??
                    string.Empty
                );


            if (
                !string.Equals(
                    nextSearch,
                    lootPickerSearch,
                    StringComparison.Ordinal
                )
            )
            {
                lootPickerSearch =
                    nextSearch;


                RebuildFilteredLootContents();


                lootPickerScroll =
                    Vector2.zero;
            }


            float viewportHeight =
                220f;


            Rect viewport =
                GUILayoutUtility.GetRect(
                    10f,
                    viewportHeight,
                    GUILayout.ExpandWidth(
                        true
                    )
                );


            float contentHeight =
                Mathf.Max(
                    viewport.height,
                    filteredLootContents.Count *
                    LootPickerRowHeight
                );


            Rect content =
                new Rect(
                    0f,
                    0f,
                    Mathf.Max(
                        1f,
                        viewport.width -
                        18f
                    ),
                    contentHeight
                );


            lootPickerScroll =
                GUI.BeginScrollView(
                    viewport,
                    lootPickerScroll,
                    content
                );


            if (
                filteredLootContents.Count >
                0
            )
            {
                int first =
                    Mathf.Clamp(
                        Mathf.FloorToInt(
                            lootPickerScroll.y /
                            LootPickerRowHeight
                        )
                        -
                        1,
                        0,
                        filteredLootContents.Count -
                        1
                    );


                int last =
                    Mathf.Clamp(
                        Mathf.CeilToInt(
                            (
                                lootPickerScroll.y +
                                viewport.height
                            )
                            /
                            LootPickerRowHeight
                        )
                        +
                        1,
                        0,
                        filteredLootContents.Count -
                        1
                    );


                for (
                    int i = first;
                    i <= last;
                    i++
                )
                {
                    StructureEditorContentScanner.LootContentInfo info =
                        filteredLootContents[i];


                    Rect row =
                        new Rect(
                            0f,
                            i *
                            LootPickerRowHeight,
                            content.width,
                            LootPickerRowHeight -
                            3f
                        );


                    if (
                        GUI.Button(
                            row,
                            string.Empty
                        )
                    )
                    {
                        entry.ItemId =
                            info.ID;


                        lootPickerEntryIndex =
                            -1;


                        GUI.EndScrollView();

                        GUILayout.EndVertical();

                        return;
                    }


                    Texture2D icon =
                        StructureEditorLootIconCache.Get(
                            info
                        );


                    if (
                        icon !=
                        null
                    )
                    {
                        GUI.DrawTexture(
                            new Rect(
                                row.x +
                                4f,
                                row.y +
                                4f,
                                46f,
                                46f
                            ),
                            icon,
                            ScaleMode.ScaleToFit,
                            true
                        );
                    }


                    GUI.Label(
                        new Rect(
                            row.x +
                            58f,
                            row.y +
                            3f,
                            row.width -
                            62f,
                            row.height -
                            6f
                        ),
                        info.DisplayLabel
                    );
                }
            }


            GUI.EndScrollView();


            GUILayout.EndVertical();
        }


        private void RebuildFilteredLootContents()
        {
            filteredLootContents.Clear();


            string search =
                (
                    lootPickerSearch ??
                    string.Empty
                ).Trim();


            if (
                string.IsNullOrWhiteSpace(
                    search
                )
            )
            {
                filteredLootContents.AddRange(
                    lootContents
                );


                return;
            }


            for (
                int i = 0;
                i < lootContents.Count;
                i++
            )
            {
                StructureEditorContentScanner.LootContentInfo info =
                    lootContents[i];


                if (
                    info ==
                    null
                )
                {
                    continue;
                }


                if (
                    ContainsIgnoreCase(
                        info.ID,
                        search
                    )
                    ||
                    ContainsIgnoreCase(
                        info.Name,
                        search
                    )
                )
                {
                    filteredLootContents.Add(
                        info
                    );
                }
            }
        }


        // =====================================================
        // DATA / INDEX
        // =====================================================

        private void NewStructure()
        {
            current =
                new StructureDefinition();


            layerMetadata =
                new StructureLayerMetadata();


            numericFieldBuffers.Clear();


            lootPickerEntryIndex =
                -1;


            NormalizeCurrent();

            RebuildCellIndex();


            selectedCellX =
                -1;


            selectedCellY =
                -1;


            gridScroll =
                Vector2.zero;


            status =
                "Новая структура";
        }


        private void NormalizeCurrent()
        {
            if (
                current ==
                null
            )
            {
                current =
                    new StructureDefinition();
            }


            if (
                current.Cells ==
                null
            )
            {
                current.Cells =
                    new List<
                        StructureCellDefinition
                    >();
            }


            if (
                current.Biomes ==
                null
            )
            {
                current.Biomes =
                    new List<string>();
            }


            current.Width =
                Mathf.Max(
                    1,
                    current.Width
                );


            current.Height =
                Mathf.Max(
                    1,
                    current.Height
                );
        }


        private void RefreshContent()
        {
            blocks =
                StructureEditorContentScanner
                    .LoadBlocks();


            lootContents =
                StructureEditorContentScanner
                    .LoadLootContents(
                        blocks
                    );


            lootById.Clear();


            for (
                int i = 0;
                i < lootContents.Count;
                i++
            )
            {
                StructureEditorContentScanner.LootContentInfo loot =
                    lootContents[i];


                if (
                    loot ==
                    null
                    ||
                    string.IsNullOrWhiteSpace(
                        loot.ID
                    )
                )
                {
                    continue;
                }


                lootById[
                    loot.ID
                ] =
                    loot;
            }


            RebuildFilteredLootContents();


            surfaceBiomes =
                StructureEditorContentScanner
                    .LoadSurfaceBiomeIds();


            caveBiomes =
                StructureEditorContentScanner
                    .LoadCaveBiomeIds();


            blocksById.Clear();


            for (
                int i = 0;
                i < blocks.Count;
                i++
            )
            {
                StructureEditorContentScanner.BlockInfo block =
                    blocks[i];


                if (
                    block ==
                    null
                    ||
                    string.IsNullOrWhiteSpace(
                        block.ID
                    )
                )
                {
                    continue;
                }


                blocksById[
                    block.ID
                ] =
                    block;
            }


            StructureEditorIconCache.Configure(
                blocks
            );


            RebuildFilteredBlocks();


            if (
                blocks.Count >
                0
                &&
                (
                    string.IsNullOrWhiteSpace(
                        selectedBlockId
                    )
                    ||
                    !blocksById.ContainsKey(
                        selectedBlockId
                    )
                )
            )
            {
                selectedBlockId =
                    blocks[
                        0
                    ].ID;
            }


            status =
                "Blocks: " +
                blocks.Count +
                " | Loot entries: " +
                lootContents.Count +
                " | Surface biomes: " +
                surfaceBiomes.Count +
                " | Cave biomes: " +
                caveBiomes.Count;
        }


        private void RebuildFilteredBlocks()
        {
            filteredBlocks.Clear();


            string search =
                (
                    blockSearch ??
                    string.Empty
                ).Trim();


            if (
                string.IsNullOrWhiteSpace(
                    search
                )
            )
            {
                filteredBlocks.AddRange(
                    blocks
                );


                return;
            }


            for (
                int i = 0;
                i < blocks.Count;
                i++
            )
            {
                StructureEditorContentScanner.BlockInfo block =
                    blocks[i];


                if (
                    block ==
                    null
                )
                {
                    continue;
                }


                if (
                    ContainsIgnoreCase(
                        block.ID,
                        search
                    )
                    ||
                    ContainsIgnoreCase(
                        block.Name,
                        search
                    )
                )
                {
                    filteredBlocks.Add(
                        block
                    );
                }
            }
        }


        private static bool ContainsIgnoreCase(
            string text,
            string search
        )
        {
            return
                !string.IsNullOrEmpty(
                    text
                )
                &&
                text.IndexOf(
                    search,
                    StringComparison.OrdinalIgnoreCase
                ) >=
                0;
        }


        private void RebuildCellIndex()
        {
            cellIndex.Clear();


            if (
                current ==
                null
                ||
                current.Cells ==
                null
            )
            {
                return;
            }


            for (
                int i = 0;
                i < current.Cells.Count;
                i++
            )
            {
                StructureCellDefinition cell =
                    current.Cells[i];


                if (
                    cell ==
                    null
                )
                {
                    continue;
                }


                cellIndex[
                    CellKey(
                        cell.X,
                        cell.Y
                    )
                ] =
                    cell;
            }
        }


        private void Place(
            int x,
            int y
        )
        {
            if (
                string.IsNullOrWhiteSpace(
                    selectedBlockId
                )
            )
            {
                return;
            }


            StructureCellDefinition cell =
                GetOrCreateCell(
                    x,
                    y
                );


            StructureLayerCellMetadata metadata =
                layerMetadata.GetOrCreate(
                    x,
                    y
                );


            switch (
                editLayer
            )
            {
                case StructureEditLayer.Background:
                    cell.BackgroundId =
                        selectedBlockId;


                    metadata.BackgroundTransform =
                        0;
                    break;


                case StructureEditLayer.Furniture:
                    metadata.FurnitureId =
                        selectedBlockId;


                    metadata.FurnitureTransform =
                        0;
                    break;


                default:
                    cell.ForegroundId =
                        selectedBlockId;


                    metadata.ForegroundTransform =
                        0;
                    break;
            }


            if (
                cell.Loot ==
                null
            )
            {
                cell.Loot =
                    new List<
                        StructureLootEntryDefinition
                    >();
            }
        }


        private StructureCellDefinition GetOrCreateCell(
            int x,
            int y
        )
        {
            int key =
                CellKey(
                    x,
                    y
                );


            if (
                cellIndex.TryGetValue(
                    key,
                    out StructureCellDefinition existing
                )
            )
            {
                return existing;
            }


            StructureCellDefinition cell =
                new StructureCellDefinition
                {
                    X =
                        x,

                    Y =
                        y,

                    Loot =
                        new List<
                            StructureLootEntryDefinition
                        >()
                };


            current.Cells.Add(
                cell
            );


            cellIndex.Add(
                key,
                cell
            );


            return cell;
        }


        private void Remove(
            int x,
            int y
        )
        {
            int key =
                CellKey(
                    x,
                    y
                );


            if (
                !cellIndex.TryGetValue(
                    key,
                    out StructureCellDefinition cell
                )
            )
            {
                return;
            }


            StructureLayerCellMetadata metadata =
                layerMetadata.GetOrCreate(
                    x,
                    y
                );


            switch (
                editLayer
            )
            {
                case StructureEditLayer.Background:
                    cell.BackgroundId =
                        string.Empty;


                    metadata.BackgroundTransform =
                        0;
                    break;


                case StructureEditLayer.Furniture:
                    metadata.FurnitureId =
                        string.Empty;


                    metadata.FurnitureTransform =
                        0;
                    break;


                default:
                    cell.ForegroundId =
                        string.Empty;


                    metadata.ForegroundTransform =
                        0;


                    if (
                        cell.Loot !=
                        null
                    )
                    {
                        cell.Loot.Clear();
                    }
                    break;
            }


            if (
                string.IsNullOrWhiteSpace(
                    cell.ForegroundId
                )
                &&
                string.IsNullOrWhiteSpace(
                    cell.BackgroundId
                )
                &&
                string.IsNullOrWhiteSpace(
                    metadata.FurnitureId
                )
            )
            {
                current.Cells.Remove(
                    cell
                );


                cellIndex.Remove(
                    key
                );


                layerMetadata.Remove(
                    x,
                    y
                );
            }
        }


        private void TransformCell(
            int x,
            int y
        )
        {
            StructureCellDefinition cell =
                FindCell(
                    x,
                    y
                );


            if (
                cell ==
                null
            )
            {
                return;
            }


            StructureLayerCellMetadata metadata =
                layerMetadata.GetOrCreate(
                    x,
                    y
                );


            string activeId =
                GetLayerId(
                    cell,
                    metadata,
                    editLayer
                );


            if (
                string.IsNullOrWhiteSpace(
                    activeId
                )
            )
            {
                return;
            }


            byte value =
                GetLayerTransform(
                    metadata,
                    editLayer
                );


            if (
                transformEditMode ==
                StructureTransformEditMode.Rotate
            )
            {
                int rotation =
                    (
                        value &
                        0x03
                    );


                rotation =
                    (
                        rotation +
                        1
                    )
                    &
                    0x03;


                value =
                    (byte)(
                        (
                            value &
                            ~0x03
                        )
                        |
                        rotation
                    );
            }
            else if (
                transformEditMode ==
                StructureTransformEditMode.Mirror
            )
            {
                value ^=
                    0x04;
            }
            else
            {
                return;
            }


            SetLayerTransform(
                metadata,
                editLayer,
                value
            );


            status =
                GetLayerLabel(
                    editLayer
                )
                +
                ": "
                +
                TransformLabel(
                    value
                );
        }


        private static string GetLayerId(
            StructureCellDefinition cell,
            StructureLayerCellMetadata metadata,
            StructureEditLayer layer
        )
        {
            if (
                cell ==
                null
            )
            {
                return null;
            }


            switch (layer)
            {
                case StructureEditLayer.Background:
                    return
                        cell.BackgroundId;

                case StructureEditLayer.Furniture:
                    return
                        metadata !=
                        null
                            ? metadata.FurnitureId
                            : null;

                default:
                    return
                        cell.ForegroundId;
            }
        }


        private static byte GetLayerTransform(
            StructureLayerCellMetadata metadata,
            StructureEditLayer layer
        )
        {
            if (
                metadata ==
                null
            )
            {
                return 0;
            }


            switch (layer)
            {
                case StructureEditLayer.Background:
                    return
                        metadata.BackgroundTransform;

                case StructureEditLayer.Furniture:
                    return
                        metadata.FurnitureTransform;

                default:
                    return
                        metadata.ForegroundTransform;
            }
        }


        private static void SetLayerTransform(
            StructureLayerCellMetadata metadata,
            StructureEditLayer layer,
            byte value
        )
        {
            if (
                metadata ==
                null
            )
            {
                return;
            }


            switch (layer)
            {
                case StructureEditLayer.Background:
                    metadata.BackgroundTransform =
                        value;
                    break;

                case StructureEditLayer.Furniture:
                    metadata.FurnitureTransform =
                        value;
                    break;

                default:
                    metadata.ForegroundTransform =
                        value;
                    break;
            }
        }


        private static string GetLayerLabel(
            StructureEditLayer layer
        )
        {
            switch (layer)
            {
                case StructureEditLayer.Background:
                    return
                        "ЗАДНИЙ";

                case StructureEditLayer.Furniture:
                    return
                        "ФУРНИТУРА";

                default:
                    return
                        "ПЕРЕДНИЙ";
            }
        }


        private string GetTransformModeLabel()
        {
            switch (
                transformEditMode
            )
            {
                case StructureTransformEditMode.Rotate:
                    return
                        "ПОВОРОТ";

                case StructureTransformEditMode.Mirror:
                    return
                        "ОТРАЖЕНИЕ";

                default:
                    return
                        "ОБЫЧНЫЙ";
            }
        }


        private static string TransformLabel(
            byte value
        )
        {
            int rotation =
                (
                    value &
                    0x03
                )
                *
                90;


            bool mirror =
                (
                    value &
                    0x04
                )
                !=
                0;


            return
                rotation +
                "°"
                +
                (
                    mirror
                        ? " + Mirror"
                        : string.Empty
                );
        }


        private StructureCellDefinition FindCell(
            int x,
            int y
        )
        {
            cellIndex.TryGetValue(
                CellKey(
                    x,
                    y
                ),
                out StructureCellDefinition cell
            );


            return cell;
        }


        private static int CellKey(
            int x,
            int y
        )
        {
            return
                (
                    x &
                    0xFFFF
                )
                |
                (
                    y <<
                    16
                );
        }


        private bool IsChestId(
            string id
        )
        {
            return
                !string.IsNullOrWhiteSpace(
                    id
                )
                &&
                blocksById.TryGetValue(
                    id,
                    out StructureEditorContentScanner.BlockInfo block
                )
                &&
                block !=
                null
                &&
                block.IsChest;
        }


        // =====================================================
        // SAVE
        // =====================================================

        private void Save()
        {
            if (
                string.IsNullOrWhiteSpace(
                    current.ID
                )
            )
            {
                status =
                    "ERROR: ID пустой";


                return;
            }


            string safe =
                current.ID
                    .Replace(
                        ":",
                        "_"
                    )
                    .Replace(
                        "/",
                        "_"
                    )
                    .Replace(
                        "\\",
                        "_"
                    );


            string file =
                Path.Combine(
                    StructurePaths.Folder,
                    safe +
                    ".json"
                );


            File.WriteAllText(
                file,
                JsonUtility.ToJson(
                    current,
                    true
                )
            );


            StructureLayerMetadataStore.Save(
                current.ID,
                layerMetadata
            );


            StructureRegistry.Reload();


            status =
                "Сохранено: " +
                file;
        }


        // =====================================================
        // FIELD HELPERS
        // =====================================================

                private string LabeledText(
            string label,
            string value
        )
        {
            GUILayout.BeginHorizontal();

            GUILayout.Label(
                label,
                GUILayout.Width(120f)
            );

            GUI.SetNextControlName(
                "StructureText_" + label
            );

            value = GUILayout.TextField(
                value ?? string.Empty,
                GetEditableTextFieldStyle()
            );

            GUILayout.EndHorizontal();
            return value;
        }



                private int BufferedIntField(
            string key,
            string label,
            int value,
            int min,
            int max
        )
        {
            GUILayout.BeginHorizontal();

            GUILayout.Label(
                label,
                GUILayout.Width(120f)
            );

            string bufferKey = "int:" + key;

            if (!numericFieldBuffers.TryGetValue(bufferKey, out string text))
            {
                text = value.ToString(CultureInfo.InvariantCulture);
                numericFieldBuffers[bufferKey] = text;
            }

            string controlName = "StructureNumeric_" + bufferKey;
            Event evt = Event.current;

            // Capture Enter BEFORE TextField processes the event.
            bool enterRequested =
                evt != null &&
                evt.type == EventType.KeyDown &&
                (evt.keyCode == KeyCode.Return ||
                 evt.keyCode == KeyCode.KeypadEnter) &&
                string.Equals(
                    GUI.GetNameOfFocusedControl(),
                    controlName,
                    StringComparison.Ordinal
                );

            GUI.SetNextControlName(controlName);

            string next = GUILayout.TextField(
                text,
                GetEditableTextFieldStyle()
            );

            numericFieldBuffers[bufferKey] = next;

            int liveParsed;
            bool liveValid =
                int.TryParse(
                    next,
                    NumberStyles.Integer,
                    CultureInfo.InvariantCulture,
                    out liveParsed
                ) ||
                int.TryParse(
                    next,
                    NumberStyles.Integer,
                    CultureInfo.CurrentCulture,
                    out liveParsed
                );

            // Valid in-range values update immediately, so the editor visibly
            // reacts while typing. Invalid/out-of-range text remains editable.
            if (liveValid && liveParsed >= min && liveParsed <= max)
                value = liveParsed;

            if (enterRequested)
            {
                int parsed;
                bool parsedOk =
                    int.TryParse(
                        next,
                        NumberStyles.Integer,
                        CultureInfo.InvariantCulture,
                        out parsed
                    ) ||
                    int.TryParse(
                        next,
                        NumberStyles.Integer,
                        CultureInfo.CurrentCulture,
                        out parsed
                    );

                if (parsedOk)
                    value = Mathf.Clamp(parsed, min, max);

                numericFieldBuffers[bufferKey] =
                    value.ToString(CultureInfo.InvariantCulture);

                GUI.FocusControl(null);

                if (evt.type != EventType.Used)
                    evt.Use();
            }

            GUILayout.EndHorizontal();
            return value;
        }



                private float BufferedFloatField(
            string key,
            string label,
            float value,
            float min,
            float max
        )
        {
            GUILayout.BeginHorizontal();

            GUILayout.Label(
                label,
                GUILayout.Width(120f)
            );

            string bufferKey = "float:" + key;

            if (!numericFieldBuffers.TryGetValue(bufferKey, out string text))
            {
                text = value.ToString(
                    "0.###",
                    CultureInfo.InvariantCulture
                );
                numericFieldBuffers[bufferKey] = text;
            }

            string controlName = "StructureNumeric_" + bufferKey;
            Event evt = Event.current;

            bool enterRequested =
                evt != null &&
                evt.type == EventType.KeyDown &&
                (evt.keyCode == KeyCode.Return ||
                 evt.keyCode == KeyCode.KeypadEnter) &&
                string.Equals(
                    GUI.GetNameOfFocusedControl(),
                    controlName,
                    StringComparison.Ordinal
                );

            GUI.SetNextControlName(controlName);

            string next = GUILayout.TextField(
                text,
                GetEditableTextFieldStyle()
            );

            numericFieldBuffers[bufferKey] = next;

            if (TryParseFlexibleFloat(next, out float liveParsed))
            {
                if (liveParsed >= min && liveParsed <= max)
                    value = liveParsed;
            }

            if (enterRequested)
            {
                if (TryParseFlexibleFloat(next, out float parsed))
                    value = Mathf.Clamp(parsed, min, max);

                numericFieldBuffers[bufferKey] =
                    value.ToString(
                        "0.###",
                        CultureInfo.InvariantCulture
                    );

                GUI.FocusControl(null);

                if (evt.type != EventType.Used)
                    evt.Use();
            }

            GUILayout.EndHorizontal();
            return value;
        }



        private static bool TryParseFlexibleFloat(
            string text,
            out float value
        )
        {
            value =
                0f;


            if (
                string.IsNullOrWhiteSpace(
                    text
                )
            )
            {
                return false;
            }


            if (
                float.TryParse(
                    text,
                    NumberStyles.Float,
                    CultureInfo.CurrentCulture,
                    out value
                )
            )
            {
                return true;
            }


            string invariantText =
                text
                    .Trim()
                    .Replace(
                        ',',
                        '.'
                    );


            return
                float.TryParse(
                    invariantText,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out value
                );
        }


        private static bool IsEnterPressedForControl(
            string controlName
        )
        {
            Event currentEvent =
                Event.current;


            if (
                currentEvent ==
                null
                ||
                currentEvent.type !=
                EventType.KeyDown
                ||
                (
                    currentEvent.keyCode !=
                    KeyCode.Return
                    &&
                    currentEvent.keyCode !=
                    KeyCode.KeypadEnter
                )
                ||
                !string.Equals(
                    GUI.GetNameOfFocusedControl(),
                    controlName,
                    StringComparison.Ordinal
                )
            )
            {
                return false;
            }


            currentEvent.Use();


            return true;
        }


                private GUIStyle GetEditableTextFieldStyle()
        {
            if (editableTextFieldStyle == null)
            {
                editableTextFieldStyle =
                    new GUIStyle(GUI.skin.textField);

                editableTextFieldStyle.normal.textColor = Color.white;
                editableTextFieldStyle.hover.textColor = Color.white;
                editableTextFieldStyle.active.textColor = Color.white;
                editableTextFieldStyle.focused.textColor = Color.white;
                editableTextFieldStyle.alignment = TextAnchor.MiddleLeft;
                editableTextFieldStyle.clipping = TextClipping.Clip;
            }

            return editableTextFieldStyle;
        }


        private string ShortId(
            string id
        )
        {
            if (
                string.IsNullOrWhiteSpace(
                    id
                )
            )
            {
                return string.Empty;
            }


            int separator =
                id.IndexOf(
                    ':'
                );


            string value =
                separator >=
                0
                    ? id.Substring(
                        separator +
                        1
                    )
                    : id;


            return
                value.Length >
                4
                    ? value.Substring(
                        0,
                        4
                    )
                    : value;
        }
}
}
