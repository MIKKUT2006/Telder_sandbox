using Game.InputSupport;
using System.Collections.Generic;

using UnityEngine;

using Game.World.Lighting;

namespace Game.World.Rendering
{
    public class ChunkRenderer
    {
        private readonly Dictionary<
            UnityEngine.Vector2Int,
            ChunkRenderData
        > renderedChunks =
            new Dictionary<
                UnityEngine.Vector2Int,
                ChunkRenderData
            >();


        // Assignable by ChunkLoader. Off-camera chunks keep CPU data but do not
        // allocate expensive sprite textures until they enter the viewport.
        public System.Func<int, int, bool> RenderEligibility;

        public bool HasChunkVisual(int x, int y)
        {
            return renderedChunks.ContainsKey(new UnityEngine.Vector2Int(x, y));
        }

        public bool IsChunkVisualEnabled(int x, int y)
        {
            return renderedChunks.TryGetValue(new UnityEngine.Vector2Int(x, y),
                out ChunkRenderData data) && data.Root != null && data.Root.activeSelf;
        }

        public void SetChunkVisible(int x, int y, bool visible)
        {
            if (renderedChunks.TryGetValue(new UnityEngine.Vector2Int(x, y),
                out ChunkRenderData data) && data.Root != null &&
                data.Root.activeSelf != visible)
                data.Root.SetActive(visible);
        }

        private Game.World.World world;

        private Material lightingMaterial;

        private readonly List<int> dynamicCellScratch =
            new List<int>(128);

        private readonly List<int> dynamicRemoveScratch =
            new List<int>(32);

        private float nextDynamicVisualCheck;

        private int lightingDetail = 2;
        public void SetLightingDetail(int value)
        {
            lightingDetail = Mathf.Clamp(value, 0, 2);
            foreach (var pair in renderedChunks)
            {
                if (pair.Value.LightTexture != null)
                    pair.Value.LightTexture.filterMode = lightingDetail == 0 ? FilterMode.Point : FilterMode.Bilinear;
            }
        }



        // =========================================================
        // VISUAL LAYERS
        // =========================================================
        //
        // Background is ALWAYS 30% darker than foreground.
        //
        // IMPORTANT:
        // This is SpriteRenderer tint, not light level.
        // Therefore a torch can brighten the background, but even
        // under maximum light its albedo remains visibly darker.
        //
        // 1.00 = normal foreground
        // 0.70 = 30% darker background
        //
        private const float BackgroundSpriteBrightness =
            0.70f;


        private const int LightBorder =
            1;


        private const int LightTextureWidth =
            Chunk.SizeX +
            LightBorder *
            2;


        private const int LightTextureHeight =
            Chunk.SizeY +
            LightBorder *
            2;


        public ChunkRenderer()
        {
            lightingDetail = GameInput.Settings.LightingQuality;
            CreateMaterial();
        }


        public ChunkRenderer(
            Game.World.World world
        )
        {
            this.world =
                world;


            lightingDetail = GameInput.Settings.LightingQuality;
            CreateMaterial();
        }


        public void SetWorld(
            Game.World.World world
        )
        {
            this.world =
                world;
        }


        // =========================================================
        // MATERIAL
        // =========================================================

        private void CreateMaterial()
        {
            Shader shader =
                ChunkLightingShaderProvider.Get();


            if (
                shader ==
                null
            )
            {
                Debug.LogError(
                    "Shader Game/ChunkLitSprite " +
                    "not found."
                );


                return;
            }


            lightingMaterial =
                new Material(
                    shader
                );


            lightingMaterial.name =
                "Runtime Chunk Lighting";
        }


        // =========================================================
        // RENDER WHOLE CHUNK
        // =========================================================

        public void Render(
            Chunk chunk
        )
        {
            if (
                chunk ==
                null
            )
            {
                return;
            }


            if (RenderEligibility != null && !RenderEligibility(chunk.X, chunk.Y))
                return;

            UnityEngine.Vector2Int key =
                new UnityEngine.Vector2Int(
                    chunk.X,
                    chunk.Y
                );


            if (
                !renderedChunks.TryGetValue(
                    key,
                    out ChunkRenderData data
                )
            )
            {
                data =
                    CreateChunkRenderData(
                        chunk
                    );


                renderedChunks.Add(
                    key,
                    data
                );
            }


            DrawBlocks(
                chunk,
                data
            );


            UpdateLightTexture(
                chunk,
                data
            );
        }


        // =========================================================
        // CREATE CHUNK OBJECT
        // =========================================================

        private ChunkRenderData CreateChunkRenderData(
            Chunk chunk
        )
        {
            ChunkRenderData data =
                new ChunkRenderData();


            GameObject root =
                new GameObject(
                    "Chunk_" +
                    chunk.X +
                    "_" +
                    chunk.Y
                );


            root.transform.position =
                new Vector3(
                    chunk.X *
                    Chunk.SizeX,

                    chunk.Y *
                    Chunk.SizeY,

                    0f
                );


            data.Root =
                root;


            // -------------------------
            // BACKGROUND
            // -------------------------

            GameObject backgroundObject =
                new GameObject(
                    "Background"
                );


            backgroundObject.transform.SetParent(
                root.transform,
                false
            );


            SpriteRenderer backgroundRenderer =
                backgroundObject.AddComponent<
                    SpriteRenderer
                >();


            backgroundRenderer.sortingOrder =
                0;


            // -----------------------------------------------------
            // PERMANENT BACKGROUND TINT
            // -----------------------------------------------------
            //
            // The layer is darkened at SpriteRenderer level.
            // Lighting remains exactly the same for both terrain
            // layers, so torch/sun light cannot erase the visual
            // distinction between foreground and background.
            //
            backgroundRenderer.color =
                new Color(
                    BackgroundSpriteBrightness,
                    BackgroundSpriteBrightness,
                    BackgroundSpriteBrightness,
                    1f
                );


            data.BackgroundRenderer =
                backgroundRenderer;


            // -------------------------
            // FOREGROUND
            // -------------------------

            GameObject foregroundObject =
                new GameObject(
                    "Foreground"
                );


            foregroundObject.transform.SetParent(
                root.transform,
                false
            );


            SpriteRenderer foregroundRenderer =
                foregroundObject.AddComponent<
                    SpriteRenderer
                >();


            foregroundRenderer.sortingOrder =
                1;


            foregroundRenderer.color =
                Color.white;


            data.ForegroundRenderer =
                foregroundRenderer;


            // -------------------------
            // TILE TEXTURES
            // -------------------------

            int textureWidth =
                Chunk.SizeX *
                BlockRenderer.BlockPixelSize;


            int textureHeight =
                Chunk.SizeY *
                BlockRenderer.BlockPixelSize;


            data.BackgroundTexture =
                CreateBlockTexture(
                    textureWidth,
                    textureHeight
                );


            data.ForegroundTexture =
                CreateBlockTexture(
                    textureWidth,
                    textureHeight
                );


            data.BackgroundRenderer.sprite =
                CreateSprite(
                    data.BackgroundTexture
                );


            data.ForegroundRenderer.sprite =
                CreateSprite(
                    data.ForegroundTexture
                );


            // -------------------------
            // LIGHT TEXTURE
            // -------------------------

            data.LightTexture =
                new Texture2D(
                    LightTextureWidth,
                    LightTextureHeight,
                    TextureFormat.RGBA32,
                    false
                );


            data.LightTexture.name =
                "Light_" +
                chunk.X +
                "_" +
                chunk.Y;


            data.LightTexture.filterMode =
                lightingDetail == 0 ? FilterMode.Point : FilterMode.Bilinear;


            data.LightTexture.wrapMode =
                TextureWrapMode.Clamp;


            data.LightPixels =
                new Color32[
                    LightTextureWidth *
                    LightTextureHeight
                ];


            if (
                lightingMaterial !=
                null
            )
            {
                data.BackgroundRenderer.sharedMaterial =
                    lightingMaterial;


                data.ForegroundRenderer.sharedMaterial =
                    lightingMaterial;
            }


            data.BackgroundProperties =
                new MaterialPropertyBlock();


            data.ForegroundProperties =
                new MaterialPropertyBlock();


            ApplyMaterialProperties(
                data
            );


            return data;
        }


        private Texture2D CreateBlockTexture(
            int width,
            int height
        )
        {
            Texture2D texture =
                new Texture2D(
                    width,
                    height,
                    TextureFormat.RGBA32,
                    false
                );


            texture.filterMode =
                FilterMode.Point;


            texture.wrapMode =
                TextureWrapMode.Clamp;


            return texture;
        }


        private Sprite CreateSprite(
            Texture2D texture
        )
        {
            return
                Sprite.Create(
                    texture,

                    new Rect(
                        0,
                        0,
                        texture.width,
                        texture.height
                    ),

                    Vector2.zero,

                    BlockRenderer.BlockPixelSize
                );
        }


        // =========================================================
        // DRAW BLOCKS
        // =========================================================

        private void DrawBlocks(
            Chunk chunk,
            ChunkRenderData data
        )
        {
            for (
                int y = 0;
                y < Chunk.SizeY;
                y++
            )
            {
                for (
                    int x = 0;
                    x < Chunk.SizeX;
                    x++
                )
                {
                    ushort backgroundId =
                        chunk.GetBackground(
                            x,
                            y
                        );

                    int worldX =
                        chunk.X * Chunk.SizeX +
                        x;

                    int worldY =
                        chunk.Y * Chunk.SizeY +
                        y;

                    BlockRenderer.DrawBlock(
                        data.BackgroundTexture,
                        x,
                        y,
                        backgroundId,
                        worldX,
                        worldY,
                        BlockVisualLayer.Background
                    );

                    TrackDynamicCell(
                        data.BackgroundDynamicVisuals,
                        x,
                        y,
                        backgroundId,
                        worldX,
                        worldY,
                        BlockVisualLayer.Background
                    );
                    // [STRUCTURE-LAYERS-BACKGROUND-TRANSFORM-V1]
                    Game.BlockTransforms.BackgroundBlockTransformRegistry.ApplyToCell(
                        data.BackgroundTexture,
                        x,
                        y,
                        BlockRenderer.BlockPixelSize,
                        chunk.X * Chunk.SizeX + x,
                        chunk.Y * Chunk.SizeY + y);



                    ushort foregroundId =
                        chunk.GetBlock(
                            x,
                            y
                        );

                    BlockRenderer.DrawBlock(
                        data.ForegroundTexture,
                        x,
                        y,
                        foregroundId,
                        worldX,
                        worldY,
                        BlockVisualLayer.Foreground
                    );

                    TrackDynamicCell(
                        data.ForegroundDynamicVisuals,
                        x,
                        y,
                        foregroundId,
                        worldX,
                        worldY,
                        BlockVisualLayer.Foreground
                    );
                    // [BT-AUTO-RENDER] EXACT_V14
                    Game.BlockTransforms.BlockTransformRenderBridge.ApplyToCell(
                        data.ForegroundTexture,
                        x,
                        y,
                        BlockRenderer.BlockPixelSize,
                        chunk.X * Chunk.SizeX + x,
                        chunk.Y * Chunk.SizeY + y);
                }
            }


            data.BackgroundTexture.Apply(
                false,
                false
            );


            data.ForegroundTexture.Apply(
                false,
                false
            );
        }


        private static void TrackDynamicCell(
            Dictionary<int, string> registry,
            int localX,
            int localY,
            ushort blockId,
            int worldX,
            int worldY,
            BlockVisualLayer layer)
        {
            if (registry == null)
                return;

            int index =
                localY * Chunk.SizeX +
                localX;

            if (!BlockRenderer.IsDynamic(blockId))
            {
                registry.Remove(index);
                return;
            }

            registry[index] =
                BlockRenderer.GetVisualKey(
                    blockId,
                    worldX,
                    worldY,
                    layer
                );
        }


        /// <summary>
        /// Redraws only cells whose visual can change with time/state.
        /// Static terrain never enters this path.
        /// </summary>
        public void UpdateAnimatedVisuals()
        {
            if (world == null || renderedChunks.Count == 0)
                return;

            // The game can run at several hundred FPS. Visual animations do not
            // need a 400 Hz scheduler, so cap checks at 60 Hz.
            if (Time.time < nextDynamicVisualCheck)
                return;

            nextDynamicVisualCheck = Time.time + 1f / 60f;

            foreach (KeyValuePair<UnityEngine.Vector2Int, ChunkRenderData> pair in renderedChunks)
            {
                if (pair.Value.Root == null || !pair.Value.Root.activeSelf) continue;
                Chunk chunk =
                    world.GetChunk(
                        pair.Key.x,
                        pair.Key.y
                    );

                if (chunk == null)
                    continue;

                ChunkRenderData data = pair.Value;
                bool foregroundDirty = UpdateDynamicLayer(
                    chunk,
                    data.ForegroundTexture,
                    data.ForegroundDynamicVisuals,
                    false
                );

                bool backgroundDirty = UpdateDynamicLayer(
                    chunk,
                    data.BackgroundTexture,
                    data.BackgroundDynamicVisuals,
                    true
                );

                if (foregroundDirty)
                    data.ForegroundTexture.Apply(false, false);

                if (backgroundDirty)
                    data.BackgroundTexture.Apply(false, false);
            }
        }


        private bool UpdateDynamicLayer(
            Chunk chunk,
            Texture2D texture,
            Dictionary<int, string> registry,
            bool background)
        {
            if (texture == null || registry == null || registry.Count == 0)
                return false;

            bool dirty = false;

            dynamicCellScratch.Clear();
            dynamicRemoveScratch.Clear();

            foreach (int key in registry.Keys)
                dynamicCellScratch.Add(key);

            for (int i = 0; i < dynamicCellScratch.Count; i++)
            {
                int index = dynamicCellScratch[i];
                int localX = index % Chunk.SizeX;
                int localY = index / Chunk.SizeX;

                ushort blockId =
                    background
                        ? chunk.GetBackground(localX, localY)
                        : chunk.GetBlock(localX, localY);

                if (!BlockRenderer.IsDynamic(blockId))
                {
                    dynamicRemoveScratch.Add(index);
                    continue;
                }

                int worldX = chunk.X * Chunk.SizeX + localX;
                int worldY = chunk.Y * Chunk.SizeY + localY;
                BlockVisualLayer layer =
                    background
                        ? BlockVisualLayer.Background
                        : BlockVisualLayer.Foreground;

                string currentKey =
                    BlockRenderer.GetVisualKey(
                        blockId,
                        worldX,
                        worldY,
                        layer
                    );

                registry.TryGetValue(index, out string oldKey);
                if (string.Equals(oldKey, currentKey, System.StringComparison.OrdinalIgnoreCase))
                    continue;

                BlockRenderer.DrawBlock(
                    texture,
                    localX,
                    localY,
                    blockId,
                    worldX,
                    worldY,
                    layer
                );

                if (background)
                {
                    Game.BlockTransforms.BackgroundBlockTransformRegistry.ApplyToCell(
                        texture,
                        localX,
                        localY,
                        BlockRenderer.BlockPixelSize,
                        worldX,
                        worldY
                    );
                }
                else
                {
                    Game.BlockTransforms.BlockTransformRenderBridge.ApplyToCell(
                        texture,
                        localX,
                        localY,
                        BlockRenderer.BlockPixelSize,
                        worldX,
                        worldY
                    );
                }

                registry[index] = currentKey;
                dirty = true;
            }

            for (int i = 0; i < dynamicRemoveScratch.Count; i++)
                registry.Remove(dynamicRemoveScratch[i]);

            return dirty;
        }


        public void RefreshVisualAt(
            int worldX,
            int worldY,
            BlockVisualLayer layer)
        {
            if (world == null || layer == BlockVisualLayer.Furniture)
                return;

            int chunkX = Mathf.FloorToInt(worldX / (float)Chunk.SizeX);
            int chunkY = Mathf.FloorToInt(worldY / (float)Chunk.SizeY);

            Chunk chunk = world.GetChunk(chunkX, chunkY);
            if (chunk == null)
                return;

            int localX = worldX - chunkX * Chunk.SizeX;
            int localY = worldY - chunkY * Chunk.SizeY;

            if (layer == BlockVisualLayer.Background)
                UpdateBackgroundBlock(chunk, localX, localY);
            else
                UpdateBlock(chunk, localX, localY);
        }


        // =========================================================
        // UPDATE ONE BLOCK
        // =========================================================

        public void UpdateBlock(
            Chunk chunk,
            int localX,
            int localY
        )
        {
            if (
                chunk ==
                null
            )
            {
                return;
            }


            UnityEngine.Vector2Int key =
                new UnityEngine.Vector2Int(
                    chunk.X,
                    chunk.Y
                );


            if (
                !renderedChunks.TryGetValue(
                    key,
                    out ChunkRenderData data
                )
            )
            {
                Render(
                    chunk
                );


                return;
            }


            ushort blockId =
                chunk.GetBlock(
                    localX,
                    localY
                );

            int worldX =
                chunk.X * Chunk.SizeX +
                localX;

            int worldY =
                chunk.Y * Chunk.SizeY +
                localY;

            BlockRenderer.DrawBlock(
                data.ForegroundTexture,
                localX,
                localY,
                blockId,
                worldX,
                worldY,
                BlockVisualLayer.Foreground
            );

            TrackDynamicCell(
                data.ForegroundDynamicVisuals,
                localX,
                localY,
                blockId,
                worldX,
                worldY,
                BlockVisualLayer.Foreground
            );
            // [BT-AUTO-RENDER] EXACT_V14
            Game.BlockTransforms.BlockTransformRenderBridge.ApplyToCell(
                data.ForegroundTexture,
                localX,
                localY,
                BlockRenderer.BlockPixelSize,
                chunk.X * Chunk.SizeX + localX,
                chunk.Y * Chunk.SizeY + localY);


            data.ForegroundTexture.Apply(
                false,
                false
            );
        }


        public void UpdateBackgroundBlock(
            Chunk chunk,
            int localX,
            int localY
        )
        {
            if (
                chunk ==
                null
            )
            {
                return;
            }


            UnityEngine.Vector2Int key =
                new UnityEngine.Vector2Int(
                    chunk.X,
                    chunk.Y
                );


            if (
                !renderedChunks.TryGetValue(
                    key,
                    out ChunkRenderData data
                )
            )
            {
                Render(
                    chunk
                );


                return;
            }


            ushort blockId =
                chunk.GetBackground(
                    localX,
                    localY
                );

            int worldX =
                chunk.X * Chunk.SizeX +
                localX;

            int worldY =
                chunk.Y * Chunk.SizeY +
                localY;

            BlockRenderer.DrawBlock(
                data.BackgroundTexture,
                localX,
                localY,
                blockId,
                worldX,
                worldY,
                BlockVisualLayer.Background
            );

            TrackDynamicCell(
                data.BackgroundDynamicVisuals,
                localX,
                localY,
                blockId,
                worldX,
                worldY,
                BlockVisualLayer.Background
            );
            // [STRUCTURE-LAYERS-BACKGROUND-TRANSFORM-V1]
            Game.BlockTransforms.BackgroundBlockTransformRegistry.ApplyToCell(
                data.BackgroundTexture,
                localX,
                localY,
                BlockRenderer.BlockPixelSize,
                chunk.X * Chunk.SizeX + localX,
                chunk.Y * Chunk.SizeY + localY);



            data.BackgroundTexture.Apply(
                false,
                false
            );
        }


        // =========================================================
        // LIGHT UPDATES
        // =========================================================

        public void UpdateDirtyLighting(
            int maxChunksPerFrame =
                6
        )
        {
            // Low/medium reduce light-texture upload workload. High is the
            // original visual quality, including soft bilinear transitions.
            maxChunksPerFrame = Mathf.Min(maxChunksPerFrame,
                lightingDetail == 0 ? 2 : lightingDetail == 1 ? 4 : 6);
            if (
                world ==
                null
            )
            {
                return;
            }


            int updated =
                0;


            foreach (
                var pair
                in world.GetLoadedChunks()
            )
            {
                if (
                    updated >=
                    maxChunksPerFrame
                )
                {
                    break;
                }


                Chunk chunk =
                    pair.Value;


                if (
                    chunk ==
                    null
                )
                {
                    continue;
                }


                ChunkLightData lightData =
                    chunk.GetLightData();


                if (
                    lightData ==
                    null
                    ||
                    !lightData.IsDirty
                )
                {
                    continue;
                }


                UnityEngine.Vector2Int key =
                    new UnityEngine.Vector2Int(
                        chunk.X,
                        chunk.Y
                    );


                if (
                    !renderedChunks.TryGetValue(
                        key,
                        out ChunkRenderData data
                    )
                )
                {
                    continue;
                }


                // Hidden chunks keep their dirty flag until shown again.
                if (data.Root == null || !data.Root.activeSelf) continue;
                UpdateLightTexture(
                    chunk,
                    data
                );


                updated++;
            }
        }


        private void UpdateLightTexture(
            Chunk chunk,
            ChunkRenderData data
        )
        {
            int startWorldX =
                chunk.X *
                Chunk.SizeX;


            int startWorldY =
                chunk.Y *
                Chunk.SizeY;


            int index =
                0;


            for (
                int lightY = -LightBorder;
                lightY < Chunk.SizeY + LightBorder;
                lightY++
            )
            {
                for (
                    int lightX = -LightBorder;
                    lightX < Chunk.SizeX + LightBorder;
                    lightX++
                )
                {
                    int worldX =
                        startWorldX +
                        lightX;


                    int worldY =
                        startWorldY +
                        lightY;


                    LightNode node =
                        GetWorldLight(
                            chunk,
                            lightX,
                            lightY,
                            worldX,
                            worldY
                        );


                    // Store artificial light independently from sunlight.
                    // RGB = torches/lava/other emissive blocks; A = daylight.
                    // The shader attenuates only A at night; lamp RGB never dims.
                    data.LightPixels[index++] = new Color32(
                        node.R == 0 ? (byte)0 : (byte)Mathf.RoundToInt(node.R * (255f / 15f)),
                        node.G == 0 ? (byte)0 : (byte)Mathf.RoundToInt(node.G * (255f / 15f)),
                        node.B == 0 ? (byte)0 : (byte)Mathf.RoundToInt(node.B * (255f / 15f)),
                        node.Sun == 0 ? (byte)0 : (byte)Mathf.RoundToInt(node.Sun * (255f / 15f))
                    );
                }
            }


            data.LightTexture.SetPixels32(
                data.LightPixels
            );


            data.LightTexture.Apply(
                false,
                false
            );


            chunk
                .GetLightData()
                .MarkClean();
        }


        private LightNode GetWorldLight(
            Chunk chunk,
            int localX,
            int localY,
            int worldX,
            int worldY
        )
        {
            if (
                world !=
                null
            )
            {
                return
                    world.GetLight(
                        worldX,
                        worldY
                    );
            }


            if (
                localX >=
                0
                &&
                localX <
                Chunk.SizeX
                &&
                localY >=
                0
                &&
                localY <
                Chunk.SizeY
            )
            {
                return
                    chunk
                        .GetLightData()
                        .Get(
                            localX,
                            localY
                        );
            }


            return
                LightNode.None;
        }


        /// <summary>
        /// Read-only handle to the same updated RGBA light texture used by the
        /// foreground and background renderers. Never allocate/copy its pixels.
        /// Returning false is normal while a chunk is still streaming.
        /// </summary>
        public bool TryGetChunkLightTexture(
            int chunkX, int chunkY, out Texture2D texture)
        {
            texture = null;
            ChunkRenderData renderData;
            if (!renderedChunks.TryGetValue(
                    new UnityEngine.Vector2Int(chunkX, chunkY), out renderData) ||
                renderData == null || renderData.LightTexture == null)
                return false;

            texture = renderData.LightTexture;
            return true;
        }

        // =========================================================
        // SHADER PROPERTIES
        // =========================================================

        private void ApplyMaterialProperties(
            ChunkRenderData data
        )
        {
            float scaleX =
                (float)
                Chunk.SizeX /
                LightTextureWidth;


            float scaleY =
                (float)
                Chunk.SizeY /
                LightTextureHeight;


            float offsetX =
                (float)
                LightBorder /
                LightTextureWidth;


            float offsetY =
                (float)
                LightBorder /
                LightTextureHeight;


            Vector4 lightUV =
                new Vector4(
                    scaleX,
                    scaleY,
                    offsetX,
                    offsetY
                );


            // -------------------------
            // FOREGROUND
            // -------------------------

            data.ForegroundProperties.SetTexture(
                "_LightTex",
                data.LightTexture
            );


            data.ForegroundProperties.SetVector(
                "_LightUVScaleOffset",
                lightUV
            );


            data.ForegroundProperties.SetFloat(
                "_LayerBrightness",
                1f
            );


            data.ForegroundProperties.SetFloat("_Ambient", 0f);


            data.ForegroundProperties.SetFloat(
                "_LightGamma",
                0.72f
            );


            data.ForegroundRenderer.SetPropertyBlock(
                data.ForegroundProperties
            );


            // -------------------------
            // BACKGROUND
            // -------------------------
            //
            // DO NOT darken the background through lighting.
            //
            // The old renderer used 0.68 here. That couples visual
            // separation to the lighting shader. We now keep the
            // same light response as foreground and darken the actual
            // SpriteRenderer by exactly 30% instead.
            //
            data.BackgroundProperties.SetTexture(
                "_LightTex",
                data.LightTexture
            );


            data.BackgroundProperties.SetVector(
                "_LightUVScaleOffset",
                lightUV
            );


            data.BackgroundProperties.SetFloat(
                "_LayerBrightness",
                1f
            );


            data.BackgroundProperties.SetFloat("_Ambient", 0f);


            data.BackgroundProperties.SetFloat(
                "_LightGamma",
                0.72f
            );


            data.BackgroundRenderer.SetPropertyBlock(
                data.BackgroundProperties
            );
        }


        // =========================================================
        // REMOVE
        // =========================================================

        public void RemoveChunk(
            int chunkX,
            int chunkY
        )
        {
            UnityEngine.Vector2Int key =
                new UnityEngine.Vector2Int(
                    chunkX,
                    chunkY
                );


            if (
                !renderedChunks.TryGetValue(
                    key,
                    out ChunkRenderData data
                )
            )
            {
                return;
            }


            renderedChunks.Remove(
                key
            );


            if (
                data.Root !=
                null
            )
            {
                Object.Destroy(
                    data.Root
                );
            }


            if (
                data.ForegroundTexture !=
                null
            )
            {
                Object.Destroy(
                    data.ForegroundTexture
                );
            }


            if (
                data.BackgroundTexture !=
                null
            )
            {
                Object.Destroy(
                    data.BackgroundTexture
                );
            }


            if (
                data.LightTexture !=
                null
            )
            {
                Object.Destroy(
                    data.LightTexture
                );
            }
        }


        public void Clear()
        {
            foreach (
                var pair
                in renderedChunks
            )
            {
                ChunkRenderData data =
                    pair.Value;


                if (
                    data.Root !=
                    null
                )
                {
                    Object.Destroy(
                        data.Root
                    );
                }


                if (
                    data.ForegroundTexture !=
                    null
                )
                {
                    Object.Destroy(
                        data.ForegroundTexture
                    );
                }


                if (
                    data.BackgroundTexture !=
                    null
                )
                {
                    Object.Destroy(
                        data.BackgroundTexture
                    );
                }


                if (
                    data.LightTexture !=
                    null
                )
                {
                    Object.Destroy(
                        data.LightTexture
                    );
                }
            }


            renderedChunks.Clear();
        }


        // =========================================================
        // RENDER DATA
        // =========================================================

        private sealed class ChunkRenderData
        {
            public GameObject Root;


            public SpriteRenderer
                ForegroundRenderer;


            public SpriteRenderer
                BackgroundRenderer;


            public Texture2D
                ForegroundTexture;


            public Texture2D
                BackgroundTexture;


            public Texture2D
                LightTexture;


            public Color32[]
                LightPixels;


            public MaterialPropertyBlock
                ForegroundProperties;


            public MaterialPropertyBlock
                BackgroundProperties;


            // localCellIndex -> last resolved visual texture name.
            // Only blocks that actually have Animation/States live here.
            public readonly Dictionary<int, string>
                ForegroundDynamicVisuals =
                    new Dictionary<int, string>();


            public readonly Dictionary<int, string>
                BackgroundDynamicVisuals =
                    new Dictionary<int, string>();
        }


        // =========================================================
        // RENDER ALL
        // =========================================================

        public void RenderAllLoaded(
            Game.World.World world
        )
        {
            if (
                world ==
                null
            )
            {
                return;
            }


            foreach (
                var pair
                in world.GetLoadedChunks()
            )
            {
                Chunk chunk =
                    pair.Value;


                if (
                    chunk ==
                    null
                )
                {
                    continue;
                }


                if (RenderEligibility == null || RenderEligibility(chunk.X, chunk.Y))
                    Render(chunk);
            }
        }
    }
}
