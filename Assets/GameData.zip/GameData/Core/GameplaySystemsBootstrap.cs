using System.Collections;
using UnityEngine;
using Game.Inventory;
using Game.GameplaySystems.Multiblock;
using Game.GameplaySystems.Respawn;
using Game.GameplaySystems.Furnace;

namespace Game.GameplaySystems
{
    public sealed class GameplaySystemsBootstrap : MonoBehaviour
    {
        private static GameplaySystemsBootstrap instance;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void Ensure()
        {
            if (instance != null) return;
            GameObject go = new GameObject("GameplaySystemsBootstrap");
            DontDestroyOnLoad(go);
            instance = go.AddComponent<GameplaySystemsBootstrap>();
            go.AddComponent<FurnaceRuntime>();
        }

        private IEnumerator Start()
        {
            while (true)
            {
                PlayerInventory inventory = FindObjectOfType<PlayerInventory>();
                if (inventory != null)
                {
                    GameObject player = inventory.gameObject;
                    if (player.GetComponent<MultiBlockPlayerController>() == null)
                        player.AddComponent<MultiBlockPlayerController>();
                    if (player.GetComponent<PlayerDeathRespawnController>() == null)
                        player.AddComponent<PlayerDeathRespawnController>();
                }
                yield return new WaitForSecondsRealtime(0.5f);
            }
        }
    }
}
