using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Game.GameplaySystems
{
    internal static class GameplayContextKey
    {
        public static string Get()
        {
            string save = FindStaticString(new [] { "CurrentSaveId", "CurrentSaveID", "SaveId", "SaveID", "CurrentSaveName", "SaveName" });
            string dim = FindStaticString(new [] { "CurrentDimensionId", "CurrentDimensionID", "DimensionId", "DimensionID", "CurrentDimension", "Dimension" });
            if (string.IsNullOrWhiteSpace(save)) save = "default";
            if (string.IsNullOrWhiteSpace(dim)) dim = SceneManager.GetActiveScene().name;
            return Sanitize(save) + "__" + Sanitize(dim);
        }

        private static string FindStaticString(string[] names)
        {
            Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
            for (int a = 0; a < assemblies.Length; a++)
            {
                Type[] types;
                try { types = assemblies[a].GetTypes(); }
                catch { continue; }
                for (int t = 0; t < types.Length; t++)
                {
                    Type type = types[t];
                    string n = type.FullName ?? type.Name;
                    if (n.IndexOf("Save", StringComparison.OrdinalIgnoreCase) < 0 &&
                        n.IndexOf("Dimension", StringComparison.OrdinalIgnoreCase) < 0)
                        continue;

                    for (int i = 0; i < names.Length; i++)
                    {
                        const BindingFlags f = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase;
                        PropertyInfo p = type.GetProperty(names[i], f);
                        if (p != null && p.CanRead)
                        {
                            try { object v = p.GetValue(null, null); if (v != null) return v.ToString(); } catch { }
                        }
                        FieldInfo field = type.GetField(names[i], f);
                        if (field != null)
                        {
                            try { object v = field.GetValue(null); if (v != null) return v.ToString(); } catch { }
                        }
                    }
                }
            }
            return null;
        }

        private static string Sanitize(string value)
        {
            if (string.IsNullOrEmpty(value)) return "default";
            foreach (char c in System.IO.Path.GetInvalidFileNameChars()) value = value.Replace(c, '_');
            return value.Replace(':', '_').Replace('/', '_').Replace('\\', '_');
        }
    }
}
