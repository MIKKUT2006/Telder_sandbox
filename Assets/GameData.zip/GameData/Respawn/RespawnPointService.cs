using System;
using System.IO;
using UnityEngine;
using Game.GameplaySystems;

namespace Game.GameplaySystems.Respawn
{
    [Serializable] internal sealed class SpawnData { public bool HasSpawn; public float X; public float Y; }

    public static class RespawnPointService
    {
        public static void SetSpawn(int anchorX,int anchorY,int width,int height)
        {
            SpawnData d=new SpawnData{HasSpawn=true,X=anchorX + 0.5f,Y=anchorY + Mathf.Max(1,height)};
            Directory.CreateDirectory(Folder()); File.WriteAllText(PathNow(),JsonUtility.ToJson(d,true));
            DeathScreenUI.ShowToast("Точка возрождения установлена");
        }
        public static bool TryGet(out Vector2 p)
        {
            p=Vector2.zero; string path=PathNow(); if(!File.Exists(path)) return false;
            try { SpawnData d=JsonUtility.FromJson<SpawnData>(File.ReadAllText(path)); if(d==null||!d.HasSpawn)return false; p=new Vector2(d.X,d.Y); return true; } catch { return false; }
        }
        private static string Folder()=>Path.Combine(Application.persistentDataPath,"TelderGameplaySystems");
        private static string PathNow()=>Path.Combine(Folder(),"spawn_"+GameplayContextKey.Get()+".json");
    }
}
