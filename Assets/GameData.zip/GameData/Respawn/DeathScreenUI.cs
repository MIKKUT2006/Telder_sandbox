using System;
using UnityEngine;
using UnityEngine.UI;

namespace Game.GameplaySystems.Respawn
{
    internal static class DeathScreenUI
    {
        private static GameObject root; private static GameObject toast;
        public static void Show(MonoBehaviour owner,Action respawn,Action menu)
        {
            Hide();
            root=new GameObject("DeathScreen",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));
            Canvas c=root.GetComponent<Canvas>(); c.renderMode=RenderMode.ScreenSpaceOverlay; c.sortingOrder=30000;
            CanvasScaler sc=root.GetComponent<CanvasScaler>(); sc.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize; sc.referenceResolution=new Vector2(1280,720);
            Image shade=RuntimeUI.Image(root.transform,"Shade",new Color(0,0,0,0.35f)); RectTransform sr=(RectTransform)shade.transform; sr.anchorMin=Vector2.zero;sr.anchorMax=Vector2.one;sr.offsetMin=sr.offsetMax=Vector2.zero;
            Image panel=RuntimeUI.Image(root.transform,"Panel",new Color32(252,252,252,255)); RectTransform pr=(RectTransform)panel.transform; pr.anchorMin=pr.anchorMax=new Vector2(.5f,.5f);pr.pivot=new Vector2(.5f,.5f);pr.sizeDelta=new Vector2(650,450); RuntimeUI.AddBorder(pr,8);
            Text title=RuntimeUI.Text(pr,"Title","Вы умерли",42,TextAnchor.MiddleCenter); SetRect(title.rectTransform,new Vector2(.5f,.5f),new Vector2(0,120),new Vector2(500,80));
            Button b1=RuntimeUI.Button(pr,"Respawn","Возродиться",new Vector2(350,70)); SetRect((RectTransform)b1.transform,new Vector2(.5f,.5f),new Vector2(0,20),new Vector2(350,70)); b1.onClick.AddListener(()=>respawn());
            Button b2=RuntimeUI.Button(pr,"Menu","Выйти в главное меню",new Vector2(350,70)); SetRect((RectTransform)b2.transform,new Vector2(.5f,.5f),new Vector2(0,-80),new Vector2(350,70)); b2.onClick.AddListener(()=>menu());
            //Cursor.visible=true;
        }
        public static void Hide(){if(root!=null)UnityEngine.Object.Destroy(root);root=null;}
        public static void ShowToast(string message)
        {
            if(toast!=null)UnityEngine.Object.Destroy(toast);
            toast=new GameObject("GameplayToast",typeof(Canvas),typeof(CanvasScaler)); Canvas c=toast.GetComponent<Canvas>();c.renderMode=RenderMode.ScreenSpaceOverlay;c.sortingOrder=29999;
            Text t=RuntimeUI.Text(toast.transform,"Text",message,22,TextAnchor.MiddleCenter); RectTransform r=t.rectTransform;r.anchorMin=r.anchorMax=new Vector2(.5f,.15f);r.sizeDelta=new Vector2(600,50);r.anchoredPosition=Vector2.zero;
            UnityEngine.Object.Destroy(toast,2f);
        }
        private static void SetRect(RectTransform r,Vector2 a,Vector2 pos,Vector2 size){r.anchorMin=r.anchorMax=a;r.pivot=new Vector2(.5f,.5f);r.anchoredPosition=pos;r.sizeDelta=size;}
    }
}
