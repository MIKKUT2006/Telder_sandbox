using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using Game.Inventory;
using Game.World.Items;

namespace Game.GameplaySystems.Respawn
{
    public sealed class PlayerDeathRespawnController : MonoBehaviour
    {
        private PlayerInventory inventory;
        private bool dead;
        private float armedAt;
        private readonly List<MonoBehaviour> disabled = new List<MonoBehaviour>();

        private void Awake(){inventory=GetComponent<PlayerInventory>(); armedAt=Time.unscaledTime+1f;}
        private void Update()
        {
            if(dead || Time.unscaledTime<armedAt) return;
            if(StatsReflection.TryGetHealth(gameObject,out float hp,out float max) && max>0f && hp<=0f) Die();
        }
        private void Die()
        {
            dead=true; DropAllItems(); DisablePlayerControl();
            Rigidbody2D rb=GetComponent<Rigidbody2D>(); if(rb!=null){rb.linearVelocity=Vector2.zero;rb.angularVelocity=0f;}
            DeathScreenUI.Show(this,Respawn,GoMenu);
        }
        private void DropAllItems()
        {
            if(inventory==null)return;
            Vector2 pos=transform.position;
            for(int i=0;i<PlayerInventory.SlotCount;i++)
            {
                ItemStack s=inventory.GetSlot(i); if(s==null||s.IsEmpty)continue;
                bool ok=ItemDropSpawner.Instance!=null && ItemDropSpawner.Instance.SpawnFromPlayer(s.ItemId,s.Count,pos);
                if(ok) s.Clear();
            }
            try { typeof(PlayerInventory).GetMethod("NotifyChanged",BindingFlags.Instance|BindingFlags.NonPublic)?.Invoke(inventory,null); } catch { }
        }
        private void DisablePlayerControl()
        {
            MonoBehaviour[] all=GetComponents<MonoBehaviour>();
            for(int i=0;i<all.Length;i++)
            {
                MonoBehaviour c=all[i]; if(c==null||c==this)continue;
                string n=c.GetType().Name.ToLowerInvariant();
                if(n.Contains("movement")||n.Contains("controller")||n.Contains("interaction")||n.Contains("weapon")||n.Contains("mining")||n.Contains("fooduse"))
                { if(c.enabled){c.enabled=false;disabled.Add(c);} }
            }
        }
        private void Respawn()
        {
            Vector2 p;
            if(!RespawnPointService.TryGet(out p)) p=transform.position;
            float half=0.9f;
            Component pc=GetComponent("PlayerCollision");
            if(pc!=null) try { MethodInfo m=pc.GetType().GetMethod("GetColliderSize"); if(m!=null && m.Invoke(pc,null) is Vector2 s) half=s.y*0.5f; } catch { }
            transform.position=new Vector3(p.x,p.y+half+0.05f,transform.position.z);
            Rigidbody2D rb=GetComponent<Rigidbody2D>(); if(rb!=null){rb.linearVelocity=Vector2.zero;rb.angularVelocity=0f;}
            StatsReflection.RestoreFull(gameObject);
            for(int i=0;i<disabled.Count;i++) if(disabled[i]!=null) disabled[i].enabled=true; disabled.Clear();
            dead=false; armedAt=Time.unscaledTime+0.5f; DeathScreenUI.Hide();
        }
        private void GoMenu(){ DeathScreenUI.Hide(); Time.timeScale=1f; try{UnityEngine.SceneManagement.SceneManager.LoadScene(0);}catch{} }
    }
}
