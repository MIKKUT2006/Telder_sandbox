using System;
using System.Collections.Generic;
using Game.InputSupport;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Game.UI.Settings
{
    // Runtime panel installed by both main-menu and pause menu. Keeps all authored
    // legacy UI intact. It lives on its own screen-space canvas and is editable
    // using the inspector theme below, not baked sprites / images.
    public sealed class SettingsTabsController : MonoBehaviour
    {
        private static SettingsTabsController active;
        public static bool IsOpen { get { return active != null && active.gameObject.activeSelf; } }
        public static Transform Root { get { return active != null ? active.transform : null; } }
        [Header("Custom look (optional)")]
        public Sprite WindowTexture;
        public Sprite TabTexture;
        public Sprite ButtonTexture;
        public TMP_FontAsset Font;
        public Color WindowColor = new Color(.075f, .09f, .12f, .98f);
        public Color ButtonColor = new Color(.15f, .19f, .24f, 1f);
        public Color SelectedColor = new Color(.25f, .38f, .46f, 1f);
        public Color TextColor = new Color(.93f, .95f, .98f);

        private Action onClosed;
        private RectTransform window;
        private RectTransform content;
        private int tab;
        private bool gamepadTab;
        private int bindingPage;
        private GameAction? bindingCapture;
        private float captureStart;
        private readonly List<GameObject> contentItems = new List<GameObject>();
        private Button[] tabs;
        private float navDelay;

        private static readonly string[] Names = {
            "Прыжок", "Атака / копать", "Использовать / ставить", "Взаимодействие",
            "Инвентарь", "Пауза", "Хотбар назад", "Хотбар вперёд",
            "Выбросить", "Быстрый перенос", "Разделить стак", "Поворот блока",
            "Слой блоков", "Движение влево", "Движение вправо", "Подтвердить",
            "Отмена", "Меню вверх", "Меню вниз", "Меню влево", "Меню вправо",
            "Меню измерений", "Вид от 3-го лица",
            "Хотбар 1", "Хотбар 2", "Хотбар 3", "Хотбар 4", "Хотбар 5",
            "Хотбар 6", "Хотбар 7", "Хотбар 8", "Хотбар 9"
        };
        public static void Open(Action closed = null)
        {
            if (active == null)
            {
                GameObject root = new GameObject("TelderSettingsTabs", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
                active = root.AddComponent<SettingsTabsController>();
                var pause = FindObjectOfType<Game.UI.Pause.PauseMenuController>();
                if (pause != null) active.Font = pause.PixelFont;
                if (active.Font == null)
                {
                    var existing = FindObjectOfType<TMP_Text>();
                    if (existing != null) active.Font = existing.font;
                }
                Canvas c = root.GetComponent<Canvas>();
                c.renderMode = RenderMode.ScreenSpaceOverlay;
                c.sortingOrder = 1500;
                CanvasScaler scale = root.GetComponent<CanvasScaler>();
                scale.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
                scale.referenceResolution = new Vector2(1280, 800);
                scale.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
                scale.matchWidthOrHeight = .5f;
                active.Build();
            }
            active.onClosed = closed;
            active.gameObject.SetActive(true);
            active.RenderContent();
        }
        public static void Close(bool callBack = false)
        {
            if (active == null) return;
            var callback = active.onClosed;
            active.bindingCapture = null;
            GameInput.IsRebinding = false;
            active.gameObject.SetActive(false);
            if (callBack) { active.onClosed = null; if (callback != null) callback(); }
        }
        private static RectTransform Rect(Transform parent, string name, Vector2 position, Vector2 size)
        {
            GameObject go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            RectTransform r = go.GetComponent<RectTransform>();
            r.anchorMin = r.anchorMax = new Vector2(.5f, .5f);
            r.anchoredPosition = position;
            r.sizeDelta = size;
            return r;
        }
        private Image Surface(Transform parent, string name, Vector2 pos, Vector2 size, Color color, Sprite texture = null)
        {
            RectTransform r = Rect(parent, name, pos, size);
            Image i = r.gameObject.AddComponent<Image>();
            i.sprite = texture;
            i.type = texture != null && texture.border.sqrMagnitude > 0 ? Image.Type.Sliced : Image.Type.Simple;
            i.color = color;
            return i;
        }
        private TMP_Text Text(Transform parent, string label, Vector2 pos, Vector2 size, int fontSize = 20)
        {
            RectTransform r = Rect(parent, "Label_" + label, pos, size);
            TextMeshProUGUI t = r.gameObject.AddComponent<TextMeshProUGUI>();
            if (Font != null) t.font = Font;
            t.text = label;
            t.fontSize = fontSize;
            t.color = TextColor;
            t.alignment = TextAlignmentOptions.Center;
            t.enableAutoSizing = false;
            t.raycastTarget = false;
            t.overflowMode = TextOverflowModes.Ellipsis;
            return t;
        }
        private Button AddButton(Transform parent, string caption, Vector2 pos, Vector2 size, Action onClick, bool selected = false)
        {
            Image image = Surface(parent, "Button_" + caption, pos, size, selected ? SelectedColor : ButtonColor, ButtonTexture);
            Button button = image.gameObject.AddComponent<Button>();
            ColorBlock cb = button.colors;
            cb.normalColor = Color.white;
            cb.highlightedColor = new Color(1.18f, 1.18f, 1.18f);
            cb.pressedColor = new Color(.75f, .82f, .9f);
            cb.selectedColor = new Color(1.18f, 1.18f, 1.18f);
            button.colors = cb;
            button.onClick.AddListener(() => onClick());
            Text(image.transform, caption, Vector2.zero, size - new Vector2(10, 4), 18);
            return button;
        }
        private void Build()
        {
            RectTransform canvas = transform as RectTransform;
            Image dim = Surface(canvas, "Dimmer", Vector2.zero, new Vector2(6000, 6000), new Color(0, 0, 0, .66f));
            dim.raycastTarget = true;
            window = Surface(canvas, "Window", new Vector2(0, 0), new Vector2(1040, 675), WindowColor, WindowTexture).rectTransform;
            Text(window, "НАСТРОЙКИ", new Vector2(0, 301), new Vector2(420, 40), 28);
            string[] tabNames = { "ОБЩИЕ", "ГРАФИКА", "УПРАВЛЕНИЕ" };
            tabs = new Button[3];
            for (int i = 0; i < 3; ++i)
            {
                int id = i;
                tabs[i] = AddButton(window, tabNames[i], new Vector2(-335 + i * 335, 248), new Vector2(315, 52), () => { tab = id; RenderContent(); });
            }
            content = Surface(window, "TwoColumnContent", new Vector2(0, -33), new Vector2(1002, 494), new Color(.03f, .04f, .06f, .75f)).rectTransform;
            AddButton(window, "НАЗАД", new Vector2(0, -308), new Vector2(220, 47), () => Close(true));
        }
        private void ClearContent()
        {
            foreach (GameObject item in contentItems) if (item != null) Destroy(item);
            contentItems.Clear();
        }
        private void Register(GameObject o) { contentItems.Add(o); }
        private void Heading(string text, int column, int row = 0)
        {
            TMP_Text t = Text(content, text, new Vector2(column == 0 ? -252 : 252, 202 - row * 41), new Vector2(462, 32), 20);
            Register(t.gameObject);
        }
        private void Entry(string label, string current, int col, int index, Action clicked)
        {
            float x = col == 0 ? -252f : 252f;
            float y = 160 - index * 39;
            TMP_Text t = Text(content, label, new Vector2(x - 99, y), new Vector2(251, 35), 15);
            t.alignment = TextAlignmentOptions.MidlineLeft;
            Register(t.gameObject);
            Button b = AddButton(content, current, new Vector2(x + 136, y), new Vector2(178, 34), clicked);
            Register(b.gameObject);
        }
        private void RenderContent()
        {
            if (content == null) return;
            ClearContent();
            for (int i = 0; i < tabs.Length; ++i)
                tabs[i].GetComponent<Image>().color = i == tab ? SelectedColor : ButtonColor;
            if (tab == 0) RenderGeneral();
            else if (tab == 1) RenderGraphics();
            else RenderBindings();
        }
        private void MusicVolumeSlider()
        {
            TMP_Text caption = Text(content, "Музыка", new Vector2(-351, 121), new Vector2(251, 35), 15);
            caption.alignment = TextAlignmentOptions.MidlineLeft;
            Register(caption.gameObject);
            Image track = Surface(content, "MusicVolume_Track", new Vector2(-116, 121),
                new Vector2(178, 34), new Color(.13f, .16f, .2f));
            Register(track.gameObject);
            Slider slider = track.gameObject.AddComponent<Slider>();
            slider.direction = Slider.Direction.LeftToRight;
            RectTransform fillArea = Rect(track.transform, "FillArea", Vector2.zero, new Vector2(154, 22));
            Image fill = Surface(fillArea, "MusicFill", Vector2.zero,
                new Vector2(152, 22), new Color(.33f, .64f, .76f));
            slider.fillRect = fill.rectTransform;
            RectTransform handleArea = Rect(track.transform, "HandleArea", Vector2.zero, new Vector2(154, 30));
            Image handle = Surface(handleArea, "Handle", Vector2.zero,
                new Vector2(16, 33), Color.white);
            slider.handleRect = handle.rectTransform;
            slider.targetGraphic = handle;
            slider.minValue = 0f;
            slider.maxValue = 1f;
            slider.wholeNumbers = false;
            slider.SetValueWithoutNotify(Game.Audio.TelderAudioSystem.MusicVolume);
            TMP_Text percent = Text(content, Mathf.RoundToInt(slider.value * 100f) + "%",
                new Vector2(-20, 121), new Vector2(65, 30), 13);
            Register(percent.gameObject);
            slider.onValueChanged.AddListener(value =>
            {
                Game.Audio.TelderAudioSystem.MusicVolume = value;
                percent.text = Mathf.RoundToInt(value * 100f) + "%";
            });
        }

        private void RenderGeneral()
        {
            Heading("ОБЩИЕ", 0);
            Entry("Общая громкость", Mathf.RoundToInt(GameInput.Settings.MasterVolume * 100) + "%", 0, 0,
                () => { GameInput.Settings.MasterVolume = (GameInput.Settings.MasterVolume + .1f) % 1.1f; GameInput.Save(); RenderContent(); });
            MusicVolumeSlider();
            Entry("Звуки", Mathf.RoundToInt(Game.Audio.TelderAudioSystem.SfxVolume * 100f) + "%", 0, 2,
                () => { Game.Audio.TelderAudioSystem.SfxVolume = (Game.Audio.TelderAudioSystem.SfxVolume + .1f) % 1.1f; RenderContent(); });
            Entry("Вибрация", GameInput.Settings.Rumble ? "ВКЛ" : "ВЫКЛ", 0, 3,
                () => { GameInput.Settings.Rumble = !GameInput.Settings.Rumble; GameInput.Save(); RenderContent(); });
            Heading("ГЕЙМПАД", 1);
            Entry("Мёртвая зона стика", GameInput.Settings.StickDeadzone.ToString("0.00"), 1, 0,
                () => { GameInput.Settings.StickDeadzone += .05f; if (GameInput.Settings.StickDeadzone > .46f) GameInput.Settings.StickDeadzone = .1f; GameInput.Save(); RenderContent(); });
            Entry("Скорость курсора", GameInput.Settings.BuildAimSpeed.ToString("0.0"), 1, 1,
                () => { GameInput.Settings.BuildAimSpeed += 2.5f; if (GameInput.Settings.BuildAimSpeed > 32f) GameInput.Settings.BuildAimSpeed = 5f; GameInput.Save(); RenderContent(); });
            Entry("Радиус строительства", GameInput.Settings.BuildAimRadius.ToString("0.0"), 1, 2,
                () => { GameInput.Settings.BuildAimRadius += .5f; if (GameInput.Settings.BuildAimRadius > 5.25f) GameInput.Settings.BuildAimRadius = 1.5f; GameInput.Save(); RenderContent(); });
            Entry("Радиус прицела оружия", GameInput.Settings.CombatAimRadius.ToString("0.00"), 1, 3,
                () => { GameInput.Settings.CombatAimRadius += .25f; if (GameInput.Settings.CombatAimRadius > 4f) GameInput.Settings.CombatAimRadius = 1f; GameInput.Save(); RenderContent(); });
            Entry("Прицел геймпада", GameInput.Settings.DisableGamepadAim ? "ВЫКЛ" : "ВКЛ", 1, 4,
                () => { GameInput.Settings.DisableGamepadAim = !GameInput.Settings.DisableGamepadAim; GameInput.Save(); RenderContent(); });
            Entry("Принудительный прицел", GameInput.Settings.ForceGamepadAim ? "ВКЛ" : "ВЫКЛ", 1, 5,
                () => { GameInput.Settings.ForceGamepadAim = !GameInput.Settings.ForceGamepadAim; GameInput.Save(); RenderContent(); });
            Entry("Диагностика прицела", GameInput.Settings.ShowGamepadAimDiagnostics ? "ВКЛ" : "ВЫКЛ", 1, 6,
                () => { GameInput.Settings.ShowGamepadAimDiagnostics = !GameInput.Settings.ShowGamepadAimDiagnostics; GameInput.Save(); RenderContent(); });
            Register(Text(content, "Прицел появляется автоматически при обнаружении геймпада. Если Steam Input скрывает устройство, включи принудительный прицел.", new Vector2(0, -188), new Vector2(860, 46), 15).gameObject);
        }
        private void RenderGraphics()
        {
            Heading("ЭКРАН", 0);
            string[] mode = { "ОКНО", "БЕЗ РАМОК", "ПОЛНЫЙ" };
            Entry("Режим экрана", mode[Mathf.Clamp(GameInput.Settings.FullscreenMode,0,2)], 0, 0,
                () => { GameInput.Settings.FullscreenMode = (GameInput.Settings.FullscreenMode + 1) % 3; GameInput.Save(); RenderContent(); });
            Heading("ОСВЕЩЕНИЕ", 1);
            string[] quality = { "НИЗКАЯ", "СРЕДНЯЯ", "ВЫСОКАЯ" };
            Entry("Детализация", quality[Mathf.Clamp(GameInput.Settings.LightingQuality, 0, 2)], 1, 0,
                () => { GameInput.Settings.LightingQuality = (GameInput.Settings.LightingQuality + 1) % 3; GameInput.Save(); RenderContent(); });
            Register(Text(content, "Низкая: пиксельный свет, 2 чанка/кадр.\nСредняя: плавный свет, 4 чанка/кадр. Высокая: 6.",
                new Vector2(0, -155), new Vector2(850, 80), 17).gameObject);
        }
        private void RenderBindings()
        {
            Register(AddButton(content, "КЛАВИАТУРА", new Vector2(-137, 213), new Vector2(250, 38),
                () => { gamepadTab = false; RenderContent(); }, !gamepadTab).gameObject);
            Register(AddButton(content, "ГЕЙМПАД", new Vector2(137, 213), new Vector2(250, 38),
                () => { gamepadTab = true; RenderContent(); }, gamepadTab).gameObject);
            GameAction[] actions = GameInput.Actions;
            int start = bindingPage * 22;
            int count = Mathf.Min(22, actions.Length - start);
            int half = (count + 1) / 2;
            for (int i = 0; i < count; i++)
            {
                int id = start + i;
                int col = i < half ? 0 : 1;
                int row = i % half;
                Entry(Names[id], GameInput.Binding(actions[id], gamepadTab).Replace("JoystickButton", "J"), col, row,
                    () => { bindingCapture = actions[id]; captureStart = Time.unscaledTime; GameInput.IsRebinding = true; RenderCaptureHint(actions[id]); });
            }
            Register(AddButton(content, bindingPage == 0 ? "ДАЛЕЕ →" : "← НАЗАД",
                new Vector2(0, -230), new Vector2(190, 30),
                () => { bindingPage = 1 - bindingPage; RenderContent(); }).gameObject);
            Register(AddButton(window, "СБРОСИТЬ КНОПКИ", new Vector2(334, -308), new Vector2(280, 35),
                () => { GameInput.RestoreDefaults(!gamepadTab); RenderContent(); }).gameObject);
        }
        private void RenderCaptureHint(GameAction action)
        {
            TMP_Text overlay = Text(window, "Нажми новую кнопку для: " + Names[(int)action] + "  (Esc — отмена)",
                new Vector2(0, -271), new Vector2(880, 39), 18);
            overlay.color = Color.yellow;
            // Hint is destroyed when the next binding page is rendered.
            contentItems.Add(overlay.gameObject);
        }
        private void Update()
        {
            if (!bindingCapture.HasValue && GameInput.GamepadConnected)
            {
                if (GameInput.Pressed(GameAction.HotbarNext)) { tab = (tab + 1) % 3; RenderContent(); }
                if (GameInput.Pressed(GameAction.HotbarPrevious)) { tab = (tab + 2) % 3; RenderContent(); }
            }
            if (bindingCapture.HasValue)
            {
                if (Time.unscaledTime - captureStart < .22f) return;
                if (Input.GetKeyDown(KeyCode.Escape)) { bindingCapture = null; GameInput.IsRebinding = false; RenderContent(); return; }
                string candidate;
                if (GameInput.TryCapture(gamepadTab, out candidate))
                {
                    GameInput.Rebind(bindingCapture.Value, gamepadTab, candidate);
                    bindingCapture = null;
                    GameInput.IsRebinding = false;
                    RenderContent();
                }
            }
        }
    }
}
