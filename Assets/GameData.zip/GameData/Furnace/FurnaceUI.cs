using UnityEngine;
using UnityEngine.UI;
using Game.Inventory;

namespace Game.GameplaySystems.Furnace
{
    public sealed class FurnaceUI : MonoBehaviour
    {
        public bool IsOpen=>root!=null;
        private GameObject root;private FurnaceState state;private PlayerInventory inventory;private Text inputText,fuelText,outputText,progressText,burnText;private Image progressFill,burnFill;
        public void Open(FurnaceState s,PlayerInventory inv){Close();state=s;inventory=inv;Build();}
        private void Update(){if(root==null)return;if(Input.GetKeyDown(KeyCode.Escape)){Close();return;}Refresh();}
        public void Close(){if(root!=null)Destroy(root);root=null;state=null;/*Cursor.visible=true;*/if(FurnaceRuntime.Instance!=null)FurnaceRuntime.Instance.ForceSave();}
        private void Build()
        {
            root=new GameObject("FurnaceUI",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));Canvas c=root.GetComponent<Canvas>();c.renderMode=RenderMode.ScreenSpaceOverlay;c.sortingOrder=25000;CanvasScaler sc=root.GetComponent<CanvasScaler>();sc.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;sc.referenceResolution=new Vector2(1280,720);
            Image panel=RuntimeUI.Image(root.transform,"Panel",new Color32(252,252,252,255));RectTransform pr=(RectTransform)panel.transform;pr.anchorMin=pr.anchorMax=new Vector2(.5f,.5f);pr.sizeDelta=new Vector2(600,420);RuntimeUI.AddBorder(pr,8);
            Text title=RuntimeUI.Text(pr,"Title","Печь",32,TextAnchor.MiddleCenter);Set(title.rectTransform,0,160,400,50);
            inputText=CreateSlot(pr,"Input",-150,65,OnInput);fuelText=CreateSlot(pr,"Fuel",-150,-75,OnFuel);outputText=CreateSlot(pr,"Output",160,0,OnOutput);
            Text fire=RuntimeUI.Text(pr,"Fire","🔥",28,TextAnchor.MiddleCenter);Set(fire.rectTransform,-15,-55,50,50);
            progressFill=Bar(pr,"Progress",-40,40,150,12);burnFill=Bar(pr,"Burn",-40,-35,150,10);
            progressText=RuntimeUI.Text(pr,"ProgressText","",16,TextAnchor.MiddleLeft);Set(progressText.rectTransform,-40,60,200,30);
            burnText=RuntimeUI.Text(pr,"BurnText","",16,TextAnchor.MiddleLeft);Set(burnText.rectTransform,-40,-15,220,30);
            Button close=RuntimeUI.Button(pr,"Close","Закрыть",new Vector2(200,55));Set((RectTransform)close.transform,0,-155,200,55);close.onClick.AddListener(Close);/*Cursor.visible=true;*/Refresh();
        }
        private Text CreateSlot(Transform p,string n,float x,float y,UnityEngine.Events.UnityAction action)
        {Button b=RuntimeUI.Button(p,n,"",new Vector2(112,112));Set((RectTransform)b.transform,x,y,112,112);b.onClick.AddListener(action);Text t=RuntimeUI.Text(b.transform,"Content","Пусто",16,TextAnchor.MiddleCenter);RectTransform r=t.rectTransform;r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=r.offsetMax=Vector2.zero;return t;}
        private Image Bar(Transform p,string n,float x,float y,float w,float h){Image bg=RuntimeUI.Image(p,n+"Bg",RuntimeUI.Gray);Set((RectTransform)bg.transform,x,y,w,h);Image fill=RuntimeUI.Image(bg.transform,n+"Fill",RuntimeUI.Brown);RectTransform r=(RectTransform)fill.transform;r.anchorMin=Vector2.zero;r.anchorMax=new Vector2(0,1);r.pivot=new Vector2(0,.5f);r.anchoredPosition=Vector2.zero;r.sizeDelta=new Vector2(0,0);return fill;}
        private void Refresh(){if(state==null)return;inputText.text=Fmt(state.InputId,state.InputCount);fuelText.text=Fmt(state.FuelId,state.FuelCount);outputText.text=Fmt(state.OutputId,state.OutputCount);float sm=0;if(FurnaceMetadataRegistry.TryRecipe(state.InputId,out _,out _,out float time)&&time>0)sm=Mathf.Clamp01(state.SmeltProgress/time);SetFill(progressFill,sm);float burn=state.BurnTotal>0?Mathf.Clamp01(state.BurnRemaining/state.BurnTotal):0;SetFill(burnFill,burn);progressText.text="Переплавка: "+Mathf.RoundToInt(sm*100)+"%";burnText.text="Топливо: "+state.BurnRemaining.ToString("0.0")+" c";}
        private void OnInput(){if(state==null||inventory==null)return;if(state.InputCount>0){GiveBack(ref state.InputId,ref state.InputCount);return;}MoveSelectedTo(ref state.InputId,ref state.InputCount,false);}
        private void OnFuel(){if(state==null||inventory==null)return;if(state.FuelCount>0){GiveBack(ref state.FuelId,ref state.FuelCount);return;}MoveSelectedTo(ref state.FuelId,ref state.FuelCount,true);}
        private void OnOutput(){if(state==null||inventory==null||state.OutputCount<=0)return;int rem=inventory.AddItem(state.OutputId,state.OutputCount);state.OutputCount=rem;if(rem<=0)state.OutputId=null;}
        private void MoveSelectedTo(ref string id,ref int count,bool fuel){ItemStack s=inventory.GetSelectedStack();if(s==null||s.IsEmpty)return;if(fuel&&!FurnaceMetadataRegistry.TryFuel(s.ItemId,out _))return;if(!fuel&&!FurnaceMetadataRegistry.TryRecipe(s.ItemId,out _,out _,out _))return;id=s.ItemId;count=s.Count;s.Clear();NotifyInventory();}
        private void GiveBack(ref string id,ref int count){if(string.IsNullOrWhiteSpace(id)||count<=0)return;int rem=inventory.AddItem(id,count);count=rem;if(rem<=0)id=null;}
        private void NotifyInventory(){try{typeof(PlayerInventory).GetMethod("NotifyChanged",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic)?.Invoke(inventory,null);}catch{}}
        private string Fmt(string id,int count)=>string.IsNullOrWhiteSpace(id)||count<=0?"Пусто":id+"\nx"+count;
        private void SetFill(Image img,float v){RectTransform r=(RectTransform)img.transform;r.anchorMax=new Vector2(v,1);r.offsetMin=r.offsetMax=Vector2.zero;}
        private static void Set(RectTransform r,float x,float y,float w,float h){r.anchorMin=r.anchorMax=new Vector2(.5f,.5f);r.pivot=new Vector2(.5f,.5f);r.anchoredPosition=new Vector2(x,y);r.sizeDelta=new Vector2(w,h);}
    }
}
