using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using Game.Inventory;
using Game.World.Furniture;
using Game.World.Items;
using Game.GameplaySystems;

namespace Game.GameplaySystems.Furnace
{
    [Serializable] public sealed class FurnaceState { public int X;public int Y;public string InputId;public int InputCount;public string FuelId;public int FuelCount;public string OutputId;public int OutputCount;public float BurnRemaining;public float BurnTotal;public float SmeltProgress;public long LastTicks; }
    [Serializable] internal sealed class FurnaceSaveFile { public List<FurnaceState> Entries=new List<FurnaceState>(); }

    public sealed class FurnaceRuntime : MonoBehaviour
    {
        public static FurnaceRuntime Instance{get;private set;}
        private string key; private FurnaceSaveFile data=new FurnaceSaveFile(); private float saveTimer; private PlayerInventory playerInventory; private Camera cam; private FurnaceUI ui;
        private void Awake(){if(Instance!=null&&Instance!=this){Destroy(this);return;}Instance=this;DontDestroyOnLoad(gameObject);FurnitureLayerManager.FurnitureRemoved+=OnFurnitureRemoved;}
        private void OnDestroy(){FurnitureLayerManager.FurnitureRemoved-=OnFurnitureRemoved;if(Instance==this)Instance=null;}
        private void Update()
        {
            EnsureContext(); if(playerInventory==null)playerInventory=FindObjectOfType<PlayerInventory>(); if(cam==null)cam=Camera.main;
            float dt=Time.deltaTime; for(int i=0;i<data.Entries.Count;i++)Tick(data.Entries[i],dt);
            saveTimer+=Time.unscaledDeltaTime;if(saveTimer>=1f){saveTimer=0;Save();}
            if(playerInventory!=null&&cam!=null&&Input.GetMouseButtonDown(1)&& (ui==null||!ui.IsOpen)) TryOpenAtMouse();
        }
        private void TryOpenAtMouse()
        {
            Vector3 wp=cam.ScreenToWorldPoint(Input.mousePosition);int x=Mathf.FloorToInt(wp.x),y=Mathf.FloorToInt(wp.y);
            if(Vector2.Distance(playerInventory.transform.position,new Vector2(x+.5f,y+.5f))>6f)return;
            FurnitureLayerManager f=FurnitureLayerManager.EnsureInstance(); if(f==null)return; string id=f.GetFurniture(x,y); if(!FurnaceMetadataRegistry.IsFurnace(id))return;
            FurnaceState s=GetOrCreate(x,y); if(ui==null)ui=gameObject.AddComponent<FurnaceUI>();ui.Open(s,playerInventory);
        }
        public FurnaceState GetOrCreate(int x,int y){EnsureContext();for(int i=0;i<data.Entries.Count;i++)if(data.Entries[i].X==x&&data.Entries[i].Y==y)return data.Entries[i];FurnaceState s=new FurnaceState{X=x,Y=y,LastTicks=DateTime.UtcNow.Ticks};data.Entries.Add(s);Save();return s;}
        private void Tick(FurnaceState s,float dt)
        {
            if(dt<=0)return; bool recipe=FurnaceMetadataRegistry.TryRecipe(s.InputId,out string outId,out int outCount,out float smeltTime)&&s.InputCount>0;
            bool outputOk=recipe&&(string.IsNullOrWhiteSpace(s.OutputId)||string.Equals(s.OutputId,outId,StringComparison.OrdinalIgnoreCase))&&s.OutputCount+outCount<=100;
            if(!recipe||!outputOk){s.SmeltProgress=0;if(s.BurnRemaining>0)s.BurnRemaining=Mathf.Max(0,s.BurnRemaining-dt);return;}
            if(s.BurnRemaining<=0)
            {
                if(s.FuelCount<=0||!FurnaceMetadataRegistry.TryFuel(s.FuelId,out float burn))return;
                s.FuelCount--; if(s.FuelCount<=0){s.FuelCount=0;s.FuelId=null;} s.BurnRemaining=burn;s.BurnTotal=burn;
            }
            float used=Mathf.Min(dt,s.BurnRemaining);s.BurnRemaining-=used;s.SmeltProgress+=used;
            while(s.SmeltProgress>=smeltTime&&s.InputCount>0&&s.OutputCount+outCount<=100)
            {s.SmeltProgress-=smeltTime;s.InputCount--;if(s.InputCount<=0){s.InputCount=0;s.InputId=null;}if(string.IsNullOrWhiteSpace(s.OutputId))s.OutputId=outId;s.OutputCount+=outCount;}
        }
        private void OnFurnitureRemoved(int x,int y,string id)
        {
            if(!FurnaceMetadataRegistry.IsFurnace(id))return;EnsureContext();
            for(int i=data.Entries.Count-1;i>=0;i--)if(data.Entries[i].X==x&&data.Entries[i].Y==y){DropContents(data.Entries[i]);data.Entries.RemoveAt(i);}Save();
        }
        private void DropContents(FurnaceState s)
        {
            if(ItemDropSpawner.Instance==null)return;Vector2 p=new Vector2(s.X+.5f,s.Y+.5f);
            if(s.InputCount>0&&!string.IsNullOrWhiteSpace(s.InputId))ItemDropSpawner.Instance.SpawnFromPlayer(s.InputId,s.InputCount,p);
            if(s.FuelCount>0&&!string.IsNullOrWhiteSpace(s.FuelId))ItemDropSpawner.Instance.SpawnFromPlayer(s.FuelId,s.FuelCount,p);
            if(s.OutputCount>0&&!string.IsNullOrWhiteSpace(s.OutputId))ItemDropSpawner.Instance.SpawnFromPlayer(s.OutputId,s.OutputCount,p);
        }
        private void EnsureContext(){string now=GameplayContextKey.Get();if(now==key)return;if(key!=null)Save();key=now;data=new FurnaceSaveFile();string p=PathNow();if(File.Exists(p))try{data=JsonUtility.FromJson<FurnaceSaveFile>(File.ReadAllText(p))??new FurnaceSaveFile();}catch{data=new FurnaceSaveFile();}}
        public void ForceSave()=>Save();
        private void Save(){if(string.IsNullOrWhiteSpace(key))return;Directory.CreateDirectory(Folder());for(int i=0;i<data.Entries.Count;i++)data.Entries[i].LastTicks=DateTime.UtcNow.Ticks;File.WriteAllText(PathNow(),JsonUtility.ToJson(data,true));}
        private string Folder()=>Path.Combine(Application.persistentDataPath,"TelderGameplaySystems");private string PathNow()=>Path.Combine(Folder(),"furnaces_"+key+".json");
    }
}
