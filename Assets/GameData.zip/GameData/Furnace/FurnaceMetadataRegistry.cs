using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using Game.GameplaySystems.Multiblock;

namespace Game.GameplaySystems.Furnace
{
    [Serializable] internal sealed class RawItemSmeltMeta { public string ID; public string[] Tags; public float FuelBurnTime; public string SmeltResult; public int SmeltResultCount=1; public float SmeltTime=5f; }
    internal static class FurnaceMetadataRegistry
    {
        private static readonly Dictionary<string,RawItemSmeltMeta> items=new Dictionary<string,RawItemSmeltMeta>(StringComparer.OrdinalIgnoreCase); private static bool loaded;
        public static bool IsFurnace(string blockId)=>MultiBlockMetadataRegistry.HasTag(blockId,"furnace") || (blockId??"").IndexOf("furnace",StringComparison.OrdinalIgnoreCase)>=0;
        public static bool TryFuel(string id,out float seconds){Ensure();seconds=0;if(!items.TryGetValue(id??"",out RawItemSmeltMeta m)||m.FuelBurnTime<=0)return false;bool tagged=false;if(m.Tags!=null)for(int i=0;i<m.Tags.Length;i++)if(string.Equals(m.Tags[i],"fuel",StringComparison.OrdinalIgnoreCase)||string.Equals(m.Tags[i],"burnable",StringComparison.OrdinalIgnoreCase)){tagged=true;break;}if(!tagged)return false;seconds=m.FuelBurnTime;return true;}
        public static bool TryRecipe(string id,out string result,out int count,out float time){Ensure();result=null;count=1;time=5;if(!items.TryGetValue(id??"",out RawItemSmeltMeta m)||string.IsNullOrWhiteSpace(m.SmeltResult))return false;result=m.SmeltResult;count=Mathf.Max(1,m.SmeltResultCount);time=Mathf.Max(.05f,m.SmeltTime);return true;}
        private static void Ensure(){if(loaded)return;loaded=true;string root=Path.Combine(Application.dataPath,"GameData","Items");if(!Directory.Exists(root))return;foreach(string f in Directory.GetFiles(root,"*.json",SearchOption.AllDirectories)){try{RawItemSmeltMeta m=JsonUtility.FromJson<RawItemSmeltMeta>(File.ReadAllText(f));if(m!=null&&!string.IsNullOrWhiteSpace(m.ID))items[m.ID]=m;}catch(Exception e){Debug.LogWarning("FURNACE META: "+Path.GetFileName(f)+": "+e.Message);}}}
    }
}
