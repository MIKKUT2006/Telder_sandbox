using System;
using UnityEngine;
using Game.Inventory;
using Game.World.Furniture;
using Game.GameplaySystems.Respawn;

namespace Game.GameplaySystems.Multiblock
{
    [DefaultExecutionOrder(-20000)]
    public sealed class MultiBlockPlayerController : MonoBehaviour
    {
        [SerializeField] private float interactionDistance = 6f;
        private PlayerInventory inventory;
        private Camera cam;
        private MonoBehaviour legacyFurnitureController;
        private bool reenableLegacy;

        private void Awake() { inventory=GetComponent<PlayerInventory>(); cam=Camera.main; ResolveLegacy(); }
        private void ResolveLegacy()
        {
            MonoBehaviour[] all=GetComponents<MonoBehaviour>();
            for(int i=0;i<all.Length;i++) if(all[i]!=null && all[i]!=this && all[i].GetType().Name=="FurniturePlacementModeController") { legacyFurnitureController=all[i]; break; }
        }

        private void Update()
        {
            if (cam==null) cam=Camera.main;
            if (inventory==null || cam==null) return;
            Vector3 wp=cam.ScreenToWorldPoint(Input.mousePosition); int x=Mathf.FloorToInt(wp.x), y=Mathf.FloorToInt(wp.y);
            if (Vector2.Distance(transform.position,new Vector2(x+0.5f,y+0.5f))>interactionDistance) return;

            MultiBlockRecord existing=MultiBlockStore.FindCell(x,y);
            if(existing!=null)
            {
                if(Input.GetMouseButtonDown(1))
                {
                    SuppressLegacyOneFrame();
                    if(string.Equals(existing.Kind,"bed",StringComparison.OrdinalIgnoreCase) || MultiBlockMetadataRegistry.HasTag(existing.BlockId,"bed"))
                        RespawnPointService.SetSpawn(existing.X, existing.Y, existing.Width, existing.Height);
                }
                if(Input.GetMouseButtonDown(0))
                {
                    SuppressLegacyOneFrame();
                    Break(existing);
                }
                return;
            }

            if(!Input.GetMouseButtonDown(1)) return;
            string itemId=inventory.GetSelectedItemId();
            if(!MultiBlockMetadataRegistry.TryGet(itemId,out MultiBlockMetadata meta)) return;
            FurnitureLayerManager furniture=FurnitureLayerManager.EnsureInstance(); if(furniture==null) return;

            int anchorX=x, anchorY=y; int minX=anchorX-meta.AnchorX, minY=anchorY-meta.AnchorY;
            for(int ix=0;ix<meta.Width;ix++) for(int iy=0;iy<meta.Height;iy++)
            {
                int cx=minX+ix, cy=minY+iy;
                if(furniture.HasFurniture(cx,cy) || MultiBlockStore.FindCell(cx,cy)!=null) return;
            }

            SuppressLegacyOneFrame();
            if(!furniture.SetFurniture(anchorX,anchorY,itemId)) return;
            if(!inventory.TryConsumeSelected(1)) { furniture.RemoveFurniture(anchorX,anchorY); return; }
            MultiBlockStore.Add(new MultiBlockRecord{X=anchorX,Y=anchorY,Width=Mathf.Max(1,meta.Width),Height=Mathf.Max(1,meta.Height),AnchorX=meta.AnchorX,AnchorY=meta.AnchorY,BlockId=itemId,Kind=meta.Kind});
        }

        private void Break(MultiBlockRecord r)
        {
            FurnitureLayerManager f=FurnitureLayerManager.EnsureInstance();
            if(f!=null) f.BreakFurniture(r.X,r.Y);
            MultiBlockStore.Remove(r);
        }

        private void SuppressLegacyOneFrame()
        {
            if(legacyFurnitureController==null) ResolveLegacy();
            if(legacyFurnitureController!=null && legacyFurnitureController.enabled) { legacyFurnitureController.enabled=false; reenableLegacy=true; }
        }
        private void LateUpdate() { if(reenableLegacy && legacyFurnitureController!=null) { legacyFurnitureController.enabled=true; reenableLegacy=false; } }
    }
}
