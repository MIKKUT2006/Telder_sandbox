using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace Game.GameplaySystems.Multiblock
{
    [Serializable] public sealed class MultiBlockMetadata { public int Width = 1; public int Height = 1; public int AnchorX; public int AnchorY; public string Kind; }
    [Serializable] internal sealed class RawBlockMetadata { public string ID; public string[] Tags; public MultiBlockMetadata MultiBlock; }

    internal static class MultiBlockMetadataRegistry
    {
        private static readonly Dictionary<string, RawBlockMetadata> byId = new Dictionary<string, RawBlockMetadata>(StringComparer.OrdinalIgnoreCase);
        private static bool loaded;

        public static bool TryGet(string id, out MultiBlockMetadata meta)
        {
            Ensure(); meta = null;
            if (string.IsNullOrWhiteSpace(id) || !byId.TryGetValue(id, out RawBlockMetadata raw) || raw.MultiBlock == null) return false;
            if (raw.MultiBlock.Width <= 1 && raw.MultiBlock.Height <= 1) return false;
            meta = raw.MultiBlock; return true;
        }

        public static bool HasTag(string id, string tag)
        {
            Ensure();
            if (!byId.TryGetValue(id ?? "", out RawBlockMetadata raw) || raw.Tags == null) return false;
            for (int i=0;i<raw.Tags.Length;i++) if (string.Equals(raw.Tags[i], tag, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }

        private static void Ensure()
        {
            if (loaded) return; loaded = true;
            string root = Path.Combine(Application.dataPath, "GameData", "Blocks");
            if (!Directory.Exists(root)) return;
            string[] files = Directory.GetFiles(root, "*.json", SearchOption.AllDirectories);
            for (int i=0;i<files.Length;i++)
            {
                try
                {
                    RawBlockMetadata raw = JsonUtility.FromJson<RawBlockMetadata>(File.ReadAllText(files[i]));
                    if (raw != null && !string.IsNullOrWhiteSpace(raw.ID)) byId[raw.ID] = raw;
                }
                catch (Exception e) { Debug.LogWarning("MULTIBLOCK META: " + Path.GetFileName(files[i]) + ": " + e.Message); }
            }
        }
    }
}
