using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using Game.GameplaySystems;

namespace Game.GameplaySystems.Multiblock
{
    [Serializable] public sealed class MultiBlockRecord { public int X; public int Y; public int Width; public int Height; public int AnchorX; public int AnchorY; public string BlockId; public string Kind; }
    [Serializable] internal sealed class MultiBlockSaveFile { public List<MultiBlockRecord> Entries = new List<MultiBlockRecord>(); }

    internal static class MultiBlockStore
    {
        private static string loadedKey;
        private static MultiBlockSaveFile data = new MultiBlockSaveFile();

        public static IEnumerable<MultiBlockRecord> Entries { get { Ensure(); return data.Entries; } }

        public static MultiBlockRecord FindCell(int x, int y)
        {
            Ensure();
            for (int i=0;i<data.Entries.Count;i++)
            {
                MultiBlockRecord r=data.Entries[i];
                int minX=r.X-r.AnchorX, minY=r.Y-r.AnchorY;
                if (x>=minX && x<minX+r.Width && y>=minY && y<minY+r.Height) return r;
            }
            return null;
        }

        public static void Add(MultiBlockRecord r) { Ensure(); data.Entries.Add(r); Save(); }
        public static void Remove(MultiBlockRecord r) { Ensure(); data.Entries.Remove(r); Save(); }

        private static void Ensure()
        {
            string key = GameplayContextKey.Get(); if (key == loadedKey) return;
            loadedKey=key; data=new MultiBlockSaveFile();
            string path=PathFor(key);
            if (File.Exists(path)) try { data=JsonUtility.FromJson<MultiBlockSaveFile>(File.ReadAllText(path)) ?? new MultiBlockSaveFile(); } catch { data=new MultiBlockSaveFile(); }
        }
        private static void Save() { Directory.CreateDirectory(Folder()); File.WriteAllText(PathFor(loadedKey), JsonUtility.ToJson(data,true)); }
        private static string Folder() { return Path.Combine(Application.persistentDataPath,"TelderGameplaySystems"); }
        private static string PathFor(string key) { return Path.Combine(Folder(),"multiblocks_"+key+".json"); }
    }
}
