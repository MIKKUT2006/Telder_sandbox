Shader "Game/TelderPixelLiquid"
{
 Properties
 {
 _MainTex("Main",2D)="white"{}
 _LightTex("Lighting",2D)="white"{}
 _Color("Tint",Color)=(1,1,1,1)
 _LightUVScaleOffset("Lighting UV",Vector)=(1,1,0,0)
 _LayerBrightness("Brightness",Float)=1
 _Ambient("Ambient",Float)=0
 _LightGamma("Gamma",Float)=.72
 _PixelsPerBlock("Pixels Per Block",Float)=36
 _Distortion("Distortion",Range(0,1))=.35
 _Reflection("Reflection",Range(0,1))=.22
 }
 SubShader
 {
  Tags{"Queue"="Transparent+20" "RenderType"="Transparent"}
  Cull Off ZWrite Off Blend SrcAlpha OneMinusSrcAlpha
  Pass
  {
   CGPROGRAM
   #pragma vertex vert
   #pragma fragment frag
   #include "UnityCG.cginc"
   struct a{float4 vertex:POSITION;float2 uv:TEXCOORD0;fixed4 color:COLOR;};
   struct v{float4 pos:SV_POSITION;float2 uv:TEXCOORD0;float2 world:TEXCOORD1;fixed4 color:COLOR;};
   sampler2D _MainTex,_LightTex; float4 _LightUVScaleOffset; fixed4 _Color;
   float _LayerBrightness,_Ambient,_LightGamma,_PixelsPerBlock,_Distortion,_Reflection,_TelderDayFactor,_DebugFullBright;
   v vert(a i){v o; o.pos=UnityObjectToClipPos(i.vertex); o.uv=i.uv; o.world=mul(unity_ObjectToWorld,i.vertex).xy; o.color=i.color*_Color; return o;}
   float hash21(float2 p){ return frac(sin(dot(p,float2(27.17,91.31)))*43758.5453); }
   fixed4 frag(v i):SV_Target
   {
     float ppb=max(8.0,_PixelsPerBlock);
     float2 cell=floor(i.world*ppb)/ppb;
     float n1=hash21(cell*0.71+3.1);
     float n2=hash21(cell.yx*1.13+7.7);
     float2 distort=(float2(n1,n2)-0.5)*(_Distortion/10.0);
     float2 sampleUV=i.uv+distort;
     fixed4 tex=tex2D(_MainTex,sampleUV)*i.color;
     float2 lightUV=clamp(i.uv*_LightUVScaleOffset.xy+_LightUVScaleOffset.zw,0,1);
     float4 enc=tex2D(_LightTex,lightUV);
     float day=(_TelderDayFactor>0.001?_TelderDayFactor:1.0);
     float3 light=max(enc.rgb, enc.a*day);
     light=pow(saturate(light), max(.01,_LightGamma));
     light=max(light,_Ambient.xxx)*_LayerBrightness;
     light=lerp(light,float3(1,1,1),saturate(_DebugFullBright));
     float shine=saturate((n1*0.55+n2*0.45))*_Reflection;
     float edge=saturate(1.0-abs(i.uv.y-0.5)*2.0);
     float3 rgb=tex.rgb*light;
     rgb += shine*edge*float3(.18,.28,.33)*light;
     return fixed4(saturate(rgb), tex.a);
   }
   ENDCG
  }
 }
 Fallback "Sprites/Default"
}
