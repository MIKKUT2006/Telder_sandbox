using System.Collections.Generic;
using Game.InputSupport;
using UnityEngine;
using Game.Content;
using Game.Inventory;
using Game.Blocks;
using Game.Mining;
using Game.World.Items;

namespace Game.World.Voxel3D
{
    /// <summary>
    /// Minecraft-style center-screen voxel interaction.
    /// LMB hold = mine, RMB = place. Targeting always follows the camera crosshair.
    /// </summary>
    [DefaultExecutionOrder(31000)]
    public sealed class VoxelBlockInteraction3D : MonoBehaviour
    {
        public float interactionDistance = 6f;
        public float baseMiningPower = 1f;

        private Camera cam;
        private VoxelWorld3DRuntime runtime;
        private PlayerInventory inventory;
        private Vector3Int miningCell;
        private bool hasTarget;
        private float progress;

        private GameObject selectionObject;
        private MeshRenderer selectionRenderer;

        private static Texture2D crosshairTexture;

        public void Initialize(Camera camera, VoxelWorld3DRuntime worldRuntime)
        {
            cam = camera;
            runtime = worldRuntime;
            inventory = GetComponent<PlayerInventory>();
            EnsureSelectionOutline();
        }

        private void Update()
        {
            if (cam == null || runtime == null)
                return;

            if (UnityEngine.Cursor.lockState != CursorLockMode.Locked)
            {
                SetSelectionVisible(false);
                ResetMining();
                return;
            }

            Ray ray = new Ray(cam.transform.position, cam.transform.forward);
            RaycastHit hit;
            bool hitBlock = UnityEngine.Physics.Raycast(
                ray,
                out hit,
                interactionDistance,
                ~(1 << 2),
                QueryTriggerInteraction.Ignore);

            if (hitBlock)
            {
                Vector3Int targetCell = Vector3Int.FloorToInt(hit.point - hit.normal * .01f);
                UpdateSelection(targetCell);

                if (GameInput.Held(GameAction.Attack))
                    Mine(targetCell);
                else
                    ResetMining();

                if ((GameInput.Pressed(GameAction.Use) || GameInput.Pressed(GameAction.Interact)))
                {
                    Vector3Int placeCell = Vector3Int.FloorToInt(hit.point + hit.normal * .01f);
                    Place(placeCell);
                }
            }
            else
            {
                SetSelectionVisible(false);
                ResetMining();
            }
        }

        private void Mine(Vector3Int cell)
        {
            ushort id = runtime.World.GetBlock(cell.x, cell.y, cell.z);
            if (id == 0)
            {
                ResetMining();
                return;
            }

            if (!hasTarget || cell != miningCell)
            {
                miningCell = cell;
                progress = 0f;
                hasTarget = true;
            }

            BlockDefinition def = GetDef(id);
            if (!MiningToolRules.CanBreak(id, inventory))
            {
                progress = 0f;
                return;
            }

            float hardness = Mathf.Max(.05f, def != null ? def.Hardness : 1f);
            float miningSpeed = MiningToolRules.GetSelectedMiningSpeed(inventory);
            progress += baseMiningPower * Mathf.Max(.05f, miningSpeed) * Time.deltaTime / hardness;

            if (progress < 1f)
                return;

            runtime.SetBlock(cell, 0);

            if (def != null && inventory != null)
            {
                string fallbackBlockId = null;
                try
                {
                    fallbackBlockId = BlockIDRegistry.GetContentID(id).ToString();
                }
                catch
                {
                }

                List<BlockLootResult> drops = BlockLootDropper.RollDrops(def, fallbackBlockId);
                for (int i = 0; i < drops.Count; i++)
                {
                    BlockLootResult drop = drops[i];
                    if (drop != null && drop.Count > 0 && !string.IsNullOrWhiteSpace(drop.ItemId))
                        inventory.AddItem(drop.ItemId, drop.Count);
                }
            }

            ResetMining();
        }

        private void Place(Vector3Int cell)
        {
            if (inventory == null || runtime.World.GetBlock(cell.x, cell.y, cell.z) != 0)
                return;

            // Do not place a block inside the 3D player's body.
            CharacterController controller = GetComponentInParent<CharacterController>();
            Bounds playerBounds = controller != null
                ? controller.bounds
                : new Bounds(transform.position, new Vector3(.6f, 1.8f, .6f));
            Bounds blockBounds = new Bounds((Vector3)cell + Vector3.one * .5f, Vector3.one * .98f);
            if (playerBounds.Intersects(blockBounds))
                return;

            string selected = inventory.GetSelectedItemId();
            if (string.IsNullOrWhiteSpace(selected))
                return;

            try
            {
                ContentID cid = ContentID.Parse(selected);
                if (!BlockIDRegistry.Contains(cid))
                    return;

                ushort id = BlockIDRegistry.GetID(cid);
                runtime.SetBlock(cell, id);
                inventory.TryConsumeSelected(1);
            }
            catch
            {
            }
        }

        private void ResetMining()
        {
            hasTarget = false;
            progress = 0f;
        }

        private void EnsureSelectionOutline()
        {
            if (selectionObject != null)
                return;

            selectionObject = new GameObject("Voxel3D Block Selection");
            selectionObject.layer = 2;

            MeshFilter filter = selectionObject.AddComponent<MeshFilter>();
            selectionRenderer = selectionObject.AddComponent<MeshRenderer>();
            filter.sharedMesh = BuildWireCube();

            Shader shader = Shader.Find("Unlit/Color");
            if (shader == null)
                shader = Shader.Find("Sprites/Default");
            if (shader == null)
                shader = Shader.Find("Standard");

            if (shader != null)
            {
                Material material = new Material(shader);
                material.color = new Color(0f, 0f, 0f, .92f);
                selectionRenderer.sharedMaterial = material;
            }

            selectionObject.transform.localScale = Vector3.one * 1.006f;
            SetSelectionVisible(false);
        }

        private static Mesh BuildWireCube()
        {
            Vector3[] v =
            {
                new Vector3(0,0,0), new Vector3(1,0,0), new Vector3(1,1,0), new Vector3(0,1,0),
                new Vector3(0,0,1), new Vector3(1,0,1), new Vector3(1,1,1), new Vector3(0,1,1)
            };

            int[] lines =
            {
                0,1, 1,2, 2,3, 3,0,
                4,5, 5,6, 6,7, 7,4,
                0,4, 1,5, 2,6, 3,7
            };

            Mesh mesh = new Mesh();
            mesh.name = "Voxel3D Selection Wire Cube";
            mesh.vertices = v;
            mesh.SetIndices(lines, MeshTopology.Lines, 0);
            mesh.RecalculateBounds();
            return mesh;
        }

        private void UpdateSelection(Vector3Int cell)
        {
            EnsureSelectionOutline();
            selectionObject.transform.position = (Vector3)cell - Vector3.one * .003f;
            SetSelectionVisible(true);
        }

        private void SetSelectionVisible(bool visible)
        {
            if (selectionRenderer != null)
                selectionRenderer.enabled = visible;
        }

        private void OnGUI()
        {
            if (cam == null || UnityEngine.Cursor.lockState != CursorLockMode.Locked)
                return;

            if (crosshairTexture == null)
            {
                crosshairTexture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
                crosshairTexture.SetPixel(0, 0, Color.white);
                crosshairTexture.Apply();
            }

            float cx = Screen.width * .5f;
            float cy = Screen.height * .5f;

            // Alpha-era simple white + with a dark one-pixel shadow/edge.
            Color old = GUI.color;
            GUI.color = new Color(0f, 0f, 0f, .85f);
            GUI.DrawTexture(new Rect(cx - 1f, cy - 8f, 3f, 17f), crosshairTexture);
            GUI.DrawTexture(new Rect(cx - 8f, cy - 1f, 17f, 3f), crosshairTexture);

            GUI.color = Color.white;
            GUI.DrawTexture(new Rect(cx, cy - 7f, 1f, 15f), crosshairTexture);
            GUI.DrawTexture(new Rect(cx - 7f, cy, 15f, 1f), crosshairTexture);
            GUI.color = old;
        }

        private void OnDestroy()
        {
            if (selectionObject != null)
                Destroy(selectionObject);
        }

        private static BlockDefinition GetDef(ushort id)
        {
            try
            {
                ContentID cid = BlockIDRegistry.GetContentID(id);
                return BlockRegistry.Contains(cid) ? BlockRegistry.Get(cid) : null;
            }
            catch
            {
                return null;
            }
        }
    }
}
