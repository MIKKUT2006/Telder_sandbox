
Shader "Game/PixelatedWaveLitSprite"
{
    Properties
    {
        [PerRendererData] _MainTex ("Sprite Texture", 2D) = "white" {}
        _Color ("Tint", Color) = (1,1,1,1)

        _LightTex ("Light Texture", 2D) = "white" {}
        _LightUVScaleOffset ("Light UV Scale Offset", Vector) = (1,1,0,0)
        _LayerBrightness ("Layer Brightness", Float) = 1
        _Ambient ("Ambient", Range(0,1)) = 0.05
        _LightGamma ("Light Gamma", Range(0.01,3)) = 0.72

        [HideInInspector] _FurnitureWorldLightMode ("Furniture World Lighting", Float) = 0
        [HideInInspector] _FurnitureWorldLightUV ("Furniture World Light UV", Vector) = (0,0,0,0)
        [HideInInspector] _FurnitureFallbackMode ("Furniture Light Fallback", Float) = 0
        
        _WindStrength ("Wind Strength (pixels)", Range(0,8)) = 5
        _WindSpeed ("Wind Speed", Range(0,4)) = 1
        _WindFrequency ("Wind Frequency", Range(0,4)) = 1.1
        _BlockPixelSize ("Pixels Per Block", Float) = 16
        _WindWorldOffset ("World Offset", Vector) = (0,0,0,0)
    }

    SubShader
    {
        Tags
        {
            "Queue" = "Transparent"
            "IgnoreProjector" = "True"
            "RenderType" = "Transparent"
            "PreviewType" = "Plane"
            "CanUseSpriteAtlas" = "False"
        }

        Cull Off
        Lighting Off
        ZWrite Off
        Blend SrcAlpha OneMinusSrcAlpha

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            sampler2D _MainTex;
            float4 _MainTex_TexelSize;
            sampler2D _LightTex;

            fixed4 _Color;
            float4 _LightUVScaleOffset;
            float4 _FurnitureWorldLightUV;
            float4 _WindWorldOffset;

            float _LayerBrightness;
            float _Ambient;
            float _LightGamma;
            float _FurnitureWorldLightMode;
            float _FurnitureFallbackMode;
            float _WindStrength;
            float _WindSpeed;
            float _WindFrequency;
            float _BlockPixelSize;
            float _DebugFullBright;
            float _TelderDayFactor;

            struct appdata
            {
                float4 vertex : POSITION;
                float2 uv : TEXCOORD0;
                fixed4 color : COLOR;
            };

            struct v2f
            {
                float4 vertex : SV_POSITION;
                float2 uv : TEXCOORD0;
                fixed4 color : COLOR;
                float2 worldXY : TEXCOORD1;
            };

            v2f vert(appdata v)
            {
                v2f o;
                o.vertex = UnityObjectToClipPos(v.vertex);
                o.uv = v.uv;
                o.color = v.color * _Color;
                o.worldXY = mul(unity_ObjectToWorld, v.vertex).xy;
                return o;
            }

            fixed4 frag(v2f i) : SV_Target
            {
                float2 uv = i.uv;

                float texWidth = max(1.0, _MainTex_TexelSize.z);
                float texHeight = max(1.0, _MainTex_TexelSize.w);
                float blockPixels = max(1.0, _BlockPixelSize);

                // Pixel-space displacement. Movement snaps to whole pixels.
                float2 pixel = uv * float2(texWidth, texHeight);
                float cellX = floor(pixel.x / blockPixels);
                float cellY = floor(pixel.y / blockPixels);
                float localY = frac(pixel.y / blockPixels);

                // Anchor the bottom and sway the upper part more strongly.
                float heightWeight = smoothstep(0.05, 0.95, localY);

                // World anchor is supplied per chunk or per furniture object.
                float worldCellX = cellX + _WindWorldOffset.x;
                float worldCellY = cellY + _WindWorldOffset.y;

                float phase = _Time.y * _WindSpeed
                    + worldCellX * 0.73
                    + worldCellY * 0.31;

                float gust = 0.58
                    + 0.42 * sin(_Time.y * 0.37 + worldCellX * 0.11);

                float sway = sin(phase * _WindFrequency) * gust;
                float offsetPixels =
                    floor(sway * _WindStrength * heightWeight + 0.5);

                // Keep the sample inside its source 16x16 cell.
                float cellLeft = cellX * blockPixels;
                float samplePixelX = clamp(
                    pixel.x - offsetPixels,
                    cellLeft + 0.5,
                    cellLeft + blockPixels - 0.5
                );

                float2 sampleUV = float2(samplePixelX / texWidth, uv.y);
                fixed4 color = tex2D(_MainTex, sampleUV) * i.color;

                if (color.a <= 0.001)
                    return fixed4(0, 0, 0, 0);

                // Chunk light UVs are used by terrain; furniture uses world UVs.
                float2 chunkLightUV =
                    uv * _LightUVScaleOffset.xy + _LightUVScaleOffset.zw;

                float2 furnitureLightUV =
                    i.worldXY * _FurnitureWorldLightUV.xy
                    + _FurnitureWorldLightUV.zw;

                float2 lightUV = lerp(
                    chunkLightUV,
                    saturate(furnitureLightUV),
                    saturate(_FurnitureWorldLightMode)
                );

                float4 encodedLight = tex2D(_LightTex, lightUV);

                // Preserve the existing lighting convention:
                // RGB carries block light, alpha carries sunlight.
                float day = (_TelderDayFactor > 0.001)
                    ? _TelderDayFactor
                    : 1.0;

                float3 light = max(encodedLight.rgb, encodedLight.aaa * day);
                light = lerp(
                    light,
                    float3(day, day, day),
                    saturate(_FurnitureFallbackMode)
                );

                light = pow(
                    saturate(light),
                    max(0.01, _LightGamma)
                );

                light = max(light, _Ambient.xxx);
                light *= _LayerBrightness;

                light = lerp(
                    light,
                    float3(1, 1, 1),
                    saturate(_DebugFullBright)
                );

                color.rgb *= saturate(light);
                return color;
            }
            ENDCG
        }
    }

    Fallback "Sprites/Default"
}
