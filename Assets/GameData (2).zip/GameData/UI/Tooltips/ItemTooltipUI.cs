﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Game.InputSupport;
using Game.Items;

namespace Game.UI.Tooltips
{
    public class ItemTooltipUI : MonoBehaviour
    {
        public static ItemTooltipUI Instance { get; private set; }

        private RectTransform panel;
        private TMP_Text text;

        private Canvas cachedCanvas;
        private RectTransform cachedCanvasRect;
        private Camera cachedCamera;

        private bool visible;
        private float currentDownOffset = 34f;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void EnsureRuntime()
        {
            if (Instance != null) return;

            Canvas chosen = null;

            foreach (var c in Object.FindObjectsByType<Canvas>(FindObjectsSortMode.None))
            {
                if (c == null || !c.isActiveAndEnabled) continue;
                if (c.renderMode != RenderMode.ScreenSpaceOverlay) continue;
                if (c.name == "GamepadFocusOverlay") continue;
                if (c.sortingOrder >= 3000) continue; // gamepad overlay
                chosen = c;
                break;
            }

            if (chosen == null)
            {
                Debug.LogWarning("[Tooltip] No suitable UI Canvas found, tooltip not created.");
                return;
            }

            Create(chosen.transform);
        }

        public static ItemTooltipUI Create(Transform parent)
        {
            if (Instance != null) return Instance;

            GameObject root = new GameObject("ItemTooltip",
                typeof(RectTransform), typeof(Image));
            root.transform.SetParent(parent, false);

            ItemTooltipUI ui = root.AddComponent<ItemTooltipUI>();
            ui.panel = root.GetComponent<RectTransform>();
            ui.panel.anchorMin = ui.panel.anchorMax = new Vector2(.5f, .5f);
            ui.panel.pivot = new Vector2(0f, 1f);   // растёт вниз-вправо от курсора
            ui.panel.sizeDelta = new Vector2(220f, 34f);

            Image bg = root.GetComponent<Image>();
            bg.color = new Color(.02f, .02f, .025f, .94f);
            bg.raycastTarget = false;               // не блокировать слот под собой

            GameObject t = new GameObject("Text",
                typeof(RectTransform), typeof(TextMeshProUGUI));
            t.transform.SetParent(root.transform, false);

            RectTransform tr = t.GetComponent<RectTransform>();
            tr.anchorMin = Vector2.zero;
            tr.anchorMax = Vector2.one;
            tr.offsetMin = new Vector2(7, 2);
            tr.offsetMax = new Vector2(-7, -2);

            ui.text = t.GetComponent<TMP_Text>();
            ui.text.fontSize = 15;
            ui.text.alignment = TextAlignmentOptions.Center;
            ui.text.raycastTarget = false;

            root.transform.SetAsLastSibling();
            root.SetActive(false);
            Instance = ui;
            return ui;
        }

        public static void ShowItem(string itemId, Vector2 screenPosition, float downOffset = 34f)
        {
            if (Instance == null) EnsureRuntime();
            if (Instance == null || string.IsNullOrWhiteSpace(itemId)) return;

            string name = itemId;
            if (ItemRegistry.TryGet(itemId, out ItemDefinition def) &&
                def != null && !string.IsNullOrWhiteSpace(def.Name))
            {
                name = def.Name;
            }

            Instance.Show(name, screenPosition, downOffset);
        }

        public void Show(string value, Vector2 screenPosition, float downOffset = 34f)
        {
            if (panel == null) return;

            gameObject.SetActive(true);
            transform.SetAsLastSibling();
            text.text = value;

            currentDownOffset = downOffset;
            visible = true;
            ResolveCanvas();

            Reposition(screenPosition);
        }

        public static void Hide()
        {
            if (Instance == null) return;
            Instance.visible = false;
            if (Instance.gameObject.activeSelf) Instance.gameObject.SetActive(false);
        }

        // Каждый кадр после Update — двигаем панель за курсором, пока она видна.
        private void LateUpdate()
        {
            if (!visible) return;

            // GameInput.PointerPosition работает и для мыши, и для
            // UI-фокуса геймпада (см. GamepadUIFocusDriver.SetUiFocusPointer).
            Vector3 pointer = GameInput.PointerPosition;
            Reposition(new Vector2(pointer.x, pointer.y));
        }

        private void ResolveCanvas()
        {
            cachedCanvas = GetComponentInParent<Canvas>();
            cachedCanvasRect = cachedCanvas != null ? cachedCanvas.transform as RectTransform : null;

            if (cachedCanvas != null && cachedCanvas.renderMode != RenderMode.ScreenSpaceOverlay)
            {
                cachedCamera = cachedCanvas.worldCamera != null
                    ? cachedCanvas.worldCamera
                    : Camera.main;
            }
            else
            {
                cachedCamera = null;
            }
        }

        private void Reposition(Vector2 screenPosition)
        {
            if (cachedCanvasRect == null) ResolveCanvas();
            if (cachedCanvasRect == null) return;

            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    cachedCanvasRect, screenPosition, cachedCamera, out Vector2 local))
                return;

            // Позиция «по умолчанию» — чуть ниже курсора.
            Vector2 pos = local + Vector2.down * currentDownOffset;

            // ---- clamp: не вылезать за края Canvas ----
            Vector2 canvasSize = cachedCanvasRect.rect.size;

            // Панель растёт вниз-вправо от pivot (0, 1).
            // Левый-верхний угол панели = pos.
            // Значит её правая граница = pos.x + panelW, нижняя = pos.y - panelH.
            float panelW = panel.rect.width;
            float panelH = panel.rect.height;

            float halfW = canvasSize.x * 0.5f;
            float halfH = canvasSize.y * 0.5f;

            // Слева: pos.x >= -halfW. Справа: pos.x + panelW <= halfW → pos.x <= halfW - panelW
            pos.x = Mathf.Clamp(pos.x, -halfW, halfW - panelW);

            // Сверху: pos.y <= halfH. Снизу: pos.y - panelH >= -halfH → pos.y >= -halfH + panelH
            pos.y = Mathf.Clamp(pos.y, -halfH + panelH, halfH);

            panel.anchoredPosition = pos;
        }
    }
}