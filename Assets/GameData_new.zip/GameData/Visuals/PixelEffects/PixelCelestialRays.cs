using System;
using System.Collections.Generic;
using Game.World;
using UnityEngine;
using GameWorld = Game.World.World;

namespace Game.Visuals.PixelEffects
{
    // Parallel rays are evaluated in beam coordinates. Each column is marched once,
    // top to bottom; this avoids a long ray cast for every output pixel.
    public sealed class PixelCelestialRays : IDisposable
    {
        private readonly GameObject root;
        private readonly Mesh mesh;
        private readonly MeshRenderer renderer;
        private readonly Material material;
        private readonly Vector3[] vertices = new Vector3[4];
        private readonly Vector2[] uvs = { Vector2.zero, Vector2.right, Vector2.one, Vector2.up };
        private readonly int[] triangles = { 0,2,1,0,3,2 };
        private GameWorld world;
        private PixelWorldOcclusion occlusion;
        private Texture2D mask;
        private Color32[] pixels;
        private int width,height,column;
        private float density,uMin,yMin,slope,nextBuild;
        private bool building;
        private Rect buildView;
        private Vector2 buildCenter;
        private Transform sun,moon;
        private float nextCelestialSearch;
        private readonly Dictionary<int,int> surfaceHeights = new Dictionary<int,int>(256);

        public PixelCelestialRays(Transform parent)
        {
            root=new GameObject("Pixel Sun and Moon Rays");
            root.transform.SetParent(parent,false);
            mesh=new Mesh { name="Celestial Ray Background" };
            root.AddComponent<MeshFilter>().sharedMesh=mesh;
            renderer=root.AddComponent<MeshRenderer>();
            renderer.sortingOrder=-1;
            renderer.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;
            renderer.receiveShadows=false;
            Shader shader=UnityEngine.Resources.Load<Shader>("Shaders/TelderPixelCelestialRays");
            if (shader!=null)
            {
                material=new Material(shader) { name="Pixel Celestial Rays" };
                renderer.sharedMaterial=material;
            }
            renderer.enabled=false;
        }

        public void Bind(GameWorld value,PixelWorldOcclusion sampler)
        {
            world=value; occlusion=sampler;
            building=false; nextBuild=0f; renderer.enabled=false;
            sun=null; moon=null; nextCelestialSearch=0f;
            surfaceHeights.Clear();
        }

        public void Hide() { renderer.enabled=false; building=false; }

        public void Tick(Camera camera,int pixelsPerBlock,float sunlightOpacity,float moonlightOpacity,int order)
        {
            if (material==null || world==null || camera==null) { Hide(); return; }
            Vector2 towardLight=GetSource(camera,out bool solar);
            float elevation=Mathf.Clamp01(towardLight.y);
            float horizonFade=Mathf.SmoothStep(0f,1f,Mathf.InverseLerp(.10f,.4f,elevation));
            if (horizonFade<=.001f) { Hide(); return; }

            Color tint=solar ? new Color(1f,.88f,.57f,sunlightOpacity) :
                new Color(.57f,.73f,1f,moonlightOpacity);
            tint.a*=horizonFade;
            material.SetColor("_RayColor",tint);
            renderer.sortingOrder=order;
            float hh=camera.orthographicSize+2f, hw=hh*camera.aspect+2f;
            Vector2 center=camera.transform.position;
            Rect view=Rect.MinMaxRect(center.x-hw,center.y-hh,center.x+hw,center.y+hh);
            if (building && ((center-buildCenter).sqrMagnitude>16f ||
                Mathf.Abs(view.height-buildView.height)>1f))
            { building=false; renderer.enabled=false; nextBuild=0f; }
            if (!building)
            {
                if (Time.time<nextBuild) return;
                Begin(view,towardLight,pixelsPerBlock);
            }
            // A fixed column budget prevents a large one-frame hitch at high zoom levels.
            int end=Mathf.Min(width,column+48);
            float step=1f/density;
            float distance=step*Mathf.Sqrt(1f+slope*slope);
            Vector2 upRay=new Vector2(slope,1f).normalized;
            for (;column<end;column++)
            {
                float beamU=uMin+(column+.5f)*step;
                float top=yMin+(height-.5f)*step;
                Vector2 start=new Vector2(beamU+top*slope,top);
                float energy=TraceSky(start,upRay,out bool canopy);
                for (int row=height-1;row>=0;row--)
                {
                    if (energy<.008f) break;
                    float y=yMin+(row+.5f)*step;
                    Vector2 at=new Vector2(beamU+y*slope,y);
                    float transmission=occlusion.Transmission(at,out bool foliage);
                    canopy|=foliage;
                    if (transmission<=.001f) energy=0f;
                    else if (transmission<.999f) energy*=Mathf.Pow(transmission,distance);
                    // Visible light gradually fades in long shafts below a canopy.
                    if (canopy) energy*=Mathf.Exp(-distance*.025f);
                    pixels[column+row*width]=new Color32(
                        (byte)Mathf.RoundToInt(Mathf.Clamp01(energy)*255f),
                        canopy ? (byte)255 : (byte)0,0,255);
                }
            }
            if (column<width) return;
            mask.SetPixels32(pixels);
            mask.Apply(false,false);
            material.SetTexture("_RayMask",mask);
            material.SetVector("_BeamUV",new Vector4(uMin,yMin,1f/(width/density),1f/(height/density)));
            material.SetFloat("_BeamSlope",slope);
            material.SetFloat("_PixelsPerBlock",density);
            vertices[0]=new Vector3(buildView.xMin,buildView.yMin,.2f);
            vertices[1]=new Vector3(buildView.xMax,buildView.yMin,.2f);
            vertices[2]=new Vector3(buildView.xMax,buildView.yMax,.2f);
            vertices[3]=new Vector3(buildView.xMin,buildView.yMax,.2f);
            mesh.Clear();
            mesh.vertices=vertices; mesh.uv=uvs; mesh.triangles=triangles;
            mesh.RecalculateBounds();
            renderer.enabled=true;
            building=false; nextBuild=Time.time+.04f;
        }

        private void Begin(Rect view,Vector2 towardLight,int ppb)
        {
            buildView=view; buildCenter=view.center;
            slope=Mathf.Clamp(towardLight.x/Mathf.Max(.1f,towardLight.y),-1.6f,1.6f);
            density=Mathf.Clamp(ppb,2,8);
            float extra=Mathf.Abs(slope)*view.height;
            while ((view.width+extra)*view.height*density*density>100000f && density>2f) density-=1f;
            // Reuse allocations as the orbit slowly changes the projected width.
            width=Mathf.Clamp(Mathf.CeilToInt(((view.width+extra)*density+2)/32f)*32,32,1024);
            height=Mathf.Clamp(Mathf.CeilToInt((view.height*density+2)/16f)*16,16,768);
            float uA=view.xMin-view.yMin*slope, uB=view.xMin-view.yMax*slope;
            uMin=Mathf.Floor(Mathf.Min(uA,uB)*density)/density-1f/density;
            yMin=Mathf.Floor(view.yMin*density)/density-1f/density;
            if (mask==null || mask.width!=width || mask.height!=height)
            {
                if (mask!=null) UnityEngine.Object.Destroy(mask);
                mask=new Texture2D(width,height,TextureFormat.RGBA32,false,true)
                { name="Pixel Celestial Visibility",filterMode=FilterMode.Point,wrapMode=TextureWrapMode.Clamp };
                pixels=new Color32[width*height];
            }
            else Array.Clear(pixels,0,pixels.Length);
            occlusion.BeginMask();
            surfaceHeights.Clear();
            column=0; building=true;
        }

        private float TraceSky(Vector2 start,Vector2 direction,out bool canopy)
        {
            canopy=false;
            float energy=1f;
            WorldManager manager=WorldManager.Instance;
            var generator=manager!=null ? manager.GetGenerator() : null;
            int lastX=int.MinValue;
            int surface=0;
            // 64 world units is enough for the local tree canopy and most roofs.
            // Unknown underground chunks are conservatively opaque.
            for (int i=1;i<=128;i++)
            {
                Vector2 p=start+direction*(i*.5f);
                int x=Mathf.FloorToInt(p.x),y=Mathf.FloorToInt(p.y);
                if (x!=lastX)
                {
                    if (!surfaceHeights.TryGetValue(x,out surface))
                    {
                        surface=generator!=null ? generator.GetSurfaceHeight(x) : y+1000;
                        surfaceHeights[x]=surface;
                    }
                    lastX=x;
                }
                if (!world.IsLoaded(x,y))
                    return y>surface+28 ? energy : 0f;
                float transmission=occlusion.Transmission(p,out bool foliage);
                canopy|=foliage;
                if (transmission<.001f) return 0f;
                if (transmission<.999f) energy*=Mathf.Sqrt(transmission);
                if (energy<.008f) return 0f;
            }
            return start.y+direction.y*64f>surface+28 ? energy : 0f;
        }

        private Vector2 GetSource(Camera camera,out bool solar)
        {
            if ((sun==null || moon==null) && Time.time>=nextCelestialSearch)
            {
                nextCelestialSearch=Time.time+1f;
                GameObject s=GameObject.Find("Sky Sun"),m=GameObject.Find("Sky Moon");
                sun=s!=null ? s.transform : null;
                moon=m!=null ? m.transform : null;
            }
            Vector2 center=camera.transform.position;
            Vector2 sunDirection=sun!=null ? (Vector2)sun.position-center : Vector2.zero;
            Vector2 moonDirection=moon!=null ? (Vector2)moon.position-center : Vector2.zero;
            if (sunDirection.y>.01f || moonDirection.y>.01f)
            {
                solar=sunDirection.y>=moonDirection.y;
                return (solar ? sunDirection : moonDirection).normalized;
            }
            float time=Mathf.Repeat(Shader.GetGlobalFloat("_TelderDayTime"),1f);
            float angle=-time*Mathf.PI*2f-Mathf.PI*.5f;
            Vector2 direction=new Vector2(Mathf.Cos(angle),Mathf.Sin(angle));
            solar=direction.y>=0f;
            return solar ? direction : -direction;
        }

        public void Dispose()
        {
            if (root!=null) UnityEngine.Object.Destroy(root);
            if (mesh!=null) UnityEngine.Object.Destroy(mesh);
            if (mask!=null) UnityEngine.Object.Destroy(mask);
            if (material!=null) UnityEngine.Object.Destroy(material);
        }
    }
}

