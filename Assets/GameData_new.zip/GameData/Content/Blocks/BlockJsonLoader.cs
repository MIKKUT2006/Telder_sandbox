using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Game.Blocks;


namespace Game.Content
{

    public static class BlockJsonLoader
    {

        public static BlockDefinition Load(
            string path
        )
        {

            if (!File.Exists(path))
            {
                return null;
            }


            string json =
                File.ReadAllText(path);



            BlockDefinition block =
                JsonConvert.DeserializeObject<BlockDefinition>(
                    json
                );

            if (block != null)
            {
                try
                {
                    JObject root = JObject.Parse(json);
                    block.HasLootTable = root.Property("Loot") != null;
                }
                catch
                {
                    block.HasLootTable = block.Loot != null && block.Loot.Count > 0;
                }
            }

            return block;

        }

    }

}