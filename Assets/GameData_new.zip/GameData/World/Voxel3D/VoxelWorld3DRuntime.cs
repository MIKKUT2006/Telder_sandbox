using System.Collections.Generic;
using UnityEngine;
using Game.Content;
using Game.Blocks;
using Game.Save;

namespace Game.World.Voxel3D
{
    public sealed class VoxelWorld3DRuntime : MonoBehaviour
    {
        [Header("3D Chunk Streaming")]
        [SerializeField] private int horizontalChunkRadius = 4;
        [SerializeField] private int verticalChunkRadius = 4;
        [SerializeField] private int chunksPerFrame = 2;

        public VoxelWorld3D World { get; private set; }

        private Voxel3DGenerator generator;
        private VoxelChunkRenderer3D renderer;
        private VoxelChunkLoader3D loader;
        private Transform player;
        private Transform chunkRoot;
        private Camera playerCamera;
        private Material biomeSkyboxMaterial;
        private VoxelBiome3DDefinition currentSkyBiome;
        private float nextSkyUpdate;
        private readonly Dictionary<VoxelCoord3D, Light> blockLights = new Dictionary<VoxelCoord3D, Light>();

        public void Initialize(Transform playerTransform)
        {
            player = playerTransform != null ? playerTransform : FindPlayer();
            World = new VoxelWorld3D();
            generator = new Voxel3DGenerator(Game.World.Dimensions.DimensionTravelRuntime.Current.Seed);

            chunkRoot = new GameObject("Voxel3D Chunks").transform;
            chunkRoot.SetParent(transform, false);

            renderer = new VoxelChunkRenderer3D(World, chunkRoot);
            loader = new VoxelChunkLoader3D(
                World,
                generator,
                renderer,
                horizontalChunkRadius,
                verticalChunkRadius,
                HandleChunkLoaded);

            SetupEnvironment();
            SetupPlayer();
            Voxel3DSaveRuntime.EnsureLoaded();
        }

        private void Update()
        {
            if (player == null || loader == null)
                return;

            loader.UpdatePlayer(player.position);
            loader.Process(Mathf.Max(1, chunksPerFrame));

            if (Time.unscaledTime >= nextSkyUpdate)
            {
                nextSkyUpdate = Time.unscaledTime + .25f;
                UpdateBiomeSky(player.position);
            }
        }

        private void OnDestroy()
        {
            Voxel3DSaveRuntime.Flush();
        }

        public void SetBlock(Vector3Int cell, ushort id)
        {
            if (World == null)
                return;

            World.SetBlock(cell.x, cell.y, cell.z, id);
            Voxel3DSaveRuntime.Record(cell.x, cell.y, cell.z, id);

            Vector3Int c = VoxelWorld3D.WorldToChunk(cell.x, cell.y, cell.z);
            renderer.Rebuild(c);

            Vector3Int l = VoxelWorld3D.WorldToLocal(cell.x, cell.y, cell.z);
            if (l.x == 0) renderer.Rebuild(c + Vector3Int.left);
            if (l.x == 15) renderer.Rebuild(c + Vector3Int.right);
            if (l.y == 0) renderer.Rebuild(c + Vector3Int.down);
            if (l.y == 15) renderer.Rebuild(c + Vector3Int.up);
            if (l.z == 0) renderer.Rebuild(c + new Vector3Int(0, 0, -1));
            if (l.z == 15) renderer.Rebuild(c + new Vector3Int(0, 0, 1));

            UpdateBlockLight(cell, id);
        }

        private void SetupPlayer()
        {
            if (player == null)
            {
                Debug.LogError("VOXEL3D: Player not found.");
                return;
            }

            var p2 = player.GetComponent<PlayerController>();
            if (p2 != null) p2.enabled = false;

            var b2 = player.GetComponent<BlockInteraction>();
            if (b2 != null) b2.enabled = false;

            var oldFall = player.GetComponent<Game.PlayerStats.PlayerFallDamage>();
            if (oldFall != null) oldFall.enabled = false;

            var rb2d = player.GetComponent<Rigidbody2D>();
            if (rb2d != null) rb2d.simulated = false;

            playerCamera = Camera.main;
            if (playerCamera == null)
            {
                GameObject cameraGo = new GameObject("Voxel3D Camera");
                playerCamera = cameraGo.AddComponent<Camera>();
                cameraGo.tag = "MainCamera";
            }

            // Force a clean old-school voxel camera. Position/rotation are then written
            // in LateUpdate by VoxelPlayerController3D so 2D camera followers cannot skew it.
            playerCamera.orthographic = false;
            playerCamera.fieldOfView = 70f;
            playerCamera.nearClipPlane = .04f;
            playerCamera.farClipPlane = 110f;
            playerCamera.clearFlags = CameraClearFlags.Skybox;

            Vector3 targetPosition;
            if (!SaveGameRuntime.TryGetCurrentPlayerPosition(out targetPosition))
            {
                int y = generator.GetSurfaceHeight(0, 0) + 3;
                targetPosition = new Vector3(.5f, y, .5f);
            }

            GameObject motorGo = new GameObject("Voxel3D Player Motor");
            motorGo.transform.SetParent(transform, false);
            motorGo.transform.position = targetPosition;
            motorGo.layer = 2;

            CharacterController cc = motorGo.AddComponent<CharacterController>();
            if (cc == null)
            {
                Debug.LogError("VOXEL3D: Could not create CharacterController on clean motor object.");
                Destroy(motorGo);
                return;
            }

            player.SetParent(motorGo.transform, true);
            player.localPosition = Vector3.zero;
            player.localRotation = Quaternion.identity;

            var ctrl = motorGo.AddComponent<VoxelPlayerController3D>();
            if (ctrl == null || !ctrl.Initialize(playerCamera, player))
            {
                Debug.LogError("VOXEL3D: Failed to initialize 3D player controller.");
                return;
            }

            var interaction = player.GetComponent<VoxelBlockInteraction3D>();
            if (interaction == null)
                interaction = player.gameObject.AddComponent<VoxelBlockInteraction3D>();

            if (interaction != null)
                interaction.Initialize(playerCamera, this);

            loader.UpdatePlayer(player.position);

            // Generate a small core immediately. It prevents the player from spending the
            // first frames falling through an unloaded surface and makes entry feel solid.
            loader.Process(5);
        }

        private void HandleChunkLoaded(VoxelChunk3D chunk)
        {
            if (chunk == null)
                return;

            Vector3Int o = chunk.WorldOrigin;
            for (int x = 0; x < VoxelChunk3D.Size; x++)
            for (int y = 0; y < VoxelChunk3D.Size; y++)
            for (int z = 0; z < VoxelChunk3D.Size; z++)
            {
                ushort id = chunk.Get(x, y, z);
                if (id != 0)
                    UpdateBlockLight(o + new Vector3Int(x, y, z), id);
            }
        }

        private void SetupEnvironment()
        {
            // Real skybox instead of a camera gradient/solid background. The procedural
            // sky material is created at runtime, so no scene component or asset is required.
            Shader skyShader = Shader.Find("Skybox/Procedural");
            if (skyShader != null)
            {
                biomeSkyboxMaterial = new Material(skyShader);
                biomeSkyboxMaterial.name = "Voxel3D Biome Skybox (Runtime)";
                biomeSkyboxMaterial.SetFloat("_SunSize", .035f);
                biomeSkyboxMaterial.SetFloat("_SunSizeConvergence", 5f);
                biomeSkyboxMaterial.SetFloat("_AtmosphereThickness", .78f);
                biomeSkyboxMaterial.SetFloat("_Exposure", 1.15f);
                RenderSettings.skybox = biomeSkyboxMaterial;
            }

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(.58f, .59f, .62f, 1f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 42f;
            RenderSettings.fogEndDistance = 100f;

            GameObject sun = new GameObject("Voxel3D Sun");
            sun.transform.SetParent(transform, false);
            sun.transform.rotation = Quaternion.Euler(50f, -35f, 0f);

            Light light = sun.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.05f;
            light.color = new Color(1f, .96f, .86f, 1f);
            light.shadows = LightShadows.Hard;

            UpdateBiomeSky(Vector3.zero, true);
        }

        private void UpdateBiomeSky(Vector3 position, bool force = false)
        {
            if (generator == null)
                return;

            VoxelBiome3DDefinition biome = generator.GetBiome(
                Mathf.FloorToInt(position.x),
                Mathf.FloorToInt(position.z));

            if (biome == null)
                return;
            if (!force && ReferenceEquals(currentSkyBiome, biome))
                return;

            currentSkyBiome = biome;
            Color sky = biome.SkyColor;
            Color ground = biome.GroundColor;
            Color fog = biome.FogColor;

            if (biomeSkyboxMaterial != null)
            {
                biomeSkyboxMaterial.SetColor("_SkyTint", sky);
                biomeSkyboxMaterial.SetColor("_GroundColor", ground);
            }

            RenderSettings.fogColor = fog;
            // Keep ambient light readable but biome-tinted, matching old voxel games.
            RenderSettings.ambientLight = Color.Lerp(new Color(.42f, .42f, .44f, 1f), sky, .24f);

            if (playerCamera != null)
                playerCamera.backgroundColor = sky; // fallback if procedural sky shader is unavailable
        }

        private void UpdateBlockLight(Vector3Int cell, ushort id)
        {
            VoxelCoord3D key = VoxelCoord3D.From(cell);
            Light old;
            if (blockLights.TryGetValue(key, out old))
            {
                if (old != null)
                    Destroy(old.gameObject);
                blockLights.Remove(key);
            }

            if (id == 0)
                return;

            BlockDefinition d = GetDef(id);
            if (d == null)
                return;

            float r = d.LightEmissionR / 255f;
            float g = d.LightEmissionG / 255f;
            float b = d.LightEmissionB / 255f;
            float max = Mathf.Max(r, Mathf.Max(g, b));
            if (max <= 0f)
                return;

            GameObject go = new GameObject("BlockLight_" + cell.x + "_" + cell.y + "_" + cell.z);
            go.transform.SetParent(transform);
            go.transform.position = (Vector3)cell + Vector3.one * .5f;

            Light l = go.AddComponent<Light>();
            l.type = LightType.Point;
            l.color = new Color(r / max, g / max, b / max);
            l.intensity = Mathf.Lerp(.7f, 2.2f, max);
            l.range = Mathf.Lerp(3f, 8f, max);
            l.shadows = LightShadows.Hard;
            blockLights[key] = l;
        }

        private static BlockDefinition GetDef(ushort id)
        {
            try
            {
                var cid = BlockIDRegistry.GetContentID(id);
                return BlockRegistry.Contains(cid) ? BlockRegistry.Get(cid) : null;
            }
            catch
            {
                return null;
            }
        }

        private static Transform FindPlayer()
        {
            GameObject tagged = GameObject.FindGameObjectWithTag("Player");
            if (tagged != null)
                return tagged.transform;

            var inv = FindFirstObjectByType<Game.Inventory.PlayerInventory>();
            return inv != null ? inv.transform : null;
        }
    }
}
