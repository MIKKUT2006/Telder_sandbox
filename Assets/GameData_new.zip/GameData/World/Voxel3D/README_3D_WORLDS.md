# Telder 2D + Voxel 3D dimensions

## Что добавлено
- Новый `DimensionGeometryMode`: `TwoD` / `Voxel3D`.
- Новый тип измерения `voxel3d`.
- 3D чанки строго 16x16x16.
- Независимый 3D loader, generator, mesh renderer и MeshCollider.
- Бесконечная генерация по X/Z и вниз по Y.
- JSON 3D-биомы: `Assets/GameData/VoxelBiomes3D/*.json`.
- 3D горы и объёмные пещеры.
- Те же BlockDefinition/ContentID/Texture/Hardness/RequiredTool/Drop, что в 2D.
- WASD + Space, Ctrl = бег.
- F5 переключает first-person / third-person.
- Один и тот же PlayerInventory и PlayerStats между измерениями.
- Позиция 3D игрока сохраняется обычным SaveGameRuntime.
- Изменённые 3D блоки сохраняются отдельно в папке dimensions текущего сейва.
- Directional light + Point Light для блоков с LightEmissionR/G/B.
- 3D структуры: GeometryMode, Depth, OriginZ, cell.Z.
- Кнопка `3D РЕДАКТОР` в текущем Structure Editor.
- В меню сохранений текущий 3D-мир помечается `[3D]`.

## 3D Structure Editor
- WASD — движение.
- Q/E — вниз/вверх.
- RMB — вращение камеры.
- LMB — поставить выбранный блок.
- MMB — удалить блок.
- F5 — сохранить JSON.
- ESC — закрыть 3D-редактор.

Пример обязательного поля 3D структуры:
`"GeometryMode": 1`

## 3D biome JSON
Поля:
- `TerrainBaseHeight`
- `MountainStrength`, `MountainScale`
- `DetailStrength`, `DetailScale`
- `CaveScale`, `CaveThreshold`
- `SurfaceBlock`, `SubsurfaceBlock`, `StoneBlock`

## Архитектурный принцип
Старый 2D Chunk/ChunkData намеренно не переделан в 3D. Это защищает существующие жидкости, мебель, освещение, генерацию и коллизии 2D мира. Voxel3D — отдельный runtime, использующий общий content/save/player слой.


## Alpha-style gameplay hotfix
- Terrain uses multi-octave hills + ridged mountain ranges instead of one flat Perlin layer.
- Mouse is captured for standard first-person look; ESC releases it, click captures again.
- Center crosshair is the source of mining/placement raycasts.
- Target block gets a wire selection outline.
- LMB hold mines, RMB places, F5 toggles first/third person.
- Simple blue sky + linear distance fog + hard directional shadows approximate an early voxel-game look.
