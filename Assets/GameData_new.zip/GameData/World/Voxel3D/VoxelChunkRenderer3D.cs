using System.Collections.Generic;
using UnityEngine;
using Game.Blocks;
using Game.Content;
using Game.Resources;

namespace Game.World.Voxel3D
{
    public sealed class VoxelChunkRenderer3D
    {
        private readonly VoxelWorld3D world;
        private readonly Transform root;
        private readonly Dictionary<Vector3Int,GameObject> objects = new Dictionary<Vector3Int,GameObject>();
        private readonly Dictionary<string,Material> materials = new Dictionary<string,Material>();
        private static readonly Vector3Int[] dirs={Vector3Int.right,Vector3Int.left,Vector3Int.up,Vector3Int.down,new Vector3Int(0,0,1),new Vector3Int(0,0,-1)};
        private static readonly int[,] faceCorners={ {1,0,0, 1,1,0, 1,1,1, 1,0,1}, {0,0,1, 0,1,1, 0,1,0, 0,0,0}, {0,1,0, 0,1,1, 1,1,1, 1,1,0}, {0,0,1, 0,0,0, 1,0,0, 1,0,1}, {1,0,1, 1,1,1, 0,1,1, 0,0,1}, {0,0,0, 0,1,0, 1,1,0, 1,0,0} };

        public VoxelChunkRenderer3D(VoxelWorld3D world,Transform root){this.world=world;this.root=root;}
        public void Remove(Vector3Int c){GameObject go;if(objects.TryGetValue(c,out go)){Object.Destroy(go);objects.Remove(c);}}
        public void Rebuild(Vector3Int c)
        {
            VoxelChunk3D chunk;if(!world.TryGetChunk(c,out chunk)){Remove(c);return;}
            Remove(c); var go=new GameObject("VoxelChunk_"+c.x+"_"+c.y+"_"+c.z);go.transform.SetParent(root,false);go.transform.position=chunk.WorldOrigin;
            var mf=go.AddComponent<MeshFilter>(); var mr=go.AddComponent<MeshRenderer>(); var mc=go.AddComponent<MeshCollider>();
            var verts=new List<Vector3>();var uvs=new List<Vector2>();var trisByMat=new Dictionary<Material,List<int>>();
            Vector3Int o=chunk.WorldOrigin;
            for(int x=0;x<16;x++)for(int y=0;y<16;y++)for(int z=0;z<16;z++){
                ushort id=chunk.Get(x,y,z);if(id==0)continue; BlockDefinition def=GetDef(id); Material mat=GetMaterial(def);
                if(!trisByMat.ContainsKey(mat))trisByMat[mat]=new List<int>();
                for(int f=0;f<6;f++){Vector3Int n=new Vector3Int(o.x+x,o.y+y,o.z+z)+dirs[f]; if(world.GetBlock(n.x,n.y,n.z)!=0)continue;
                    int b=verts.Count;for(int k=0;k<4;k++)verts.Add(new Vector3(x+faceCorners[f,k*3],y+faceCorners[f,k*3+1],z+faceCorners[f,k*3+2]));
                    uvs.Add(new Vector2(0,0));uvs.Add(new Vector2(0,1));uvs.Add(new Vector2(1,1));uvs.Add(new Vector2(1,0));
                    var t=trisByMat[mat];t.Add(b);t.Add(b+1);t.Add(b+2);t.Add(b);t.Add(b+2);t.Add(b+3);
                }
            }
            var mesh=new Mesh();mesh.indexFormat=UnityEngine.Rendering.IndexFormat.UInt32;mesh.SetVertices(verts);mesh.SetUVs(0,uvs);mesh.subMeshCount=trisByMat.Count;
            var mats=new Material[trisByMat.Count];int sm=0;foreach(var kv in trisByMat){mesh.SetTriangles(kv.Value,sm);mats[sm]=kv.Key;sm++;}mesh.RecalculateNormals();mesh.RecalculateBounds();mf.sharedMesh=mesh;mr.sharedMaterials=mats;mc.sharedMesh=mesh;objects[c]=go;
        }
        private static BlockDefinition GetDef(ushort id){try{var cid=BlockIDRegistry.GetContentID(id);return BlockRegistry.Contains(cid)?BlockRegistry.Get(cid):null;}catch{return null;}}
        private Material GetMaterial(BlockDefinition d){string key=d?.Texture??"__fallback";Material m;if(materials.TryGetValue(key,out m))return m;Shader s=Shader.Find("Universal Render Pipeline/Lit")??Shader.Find("Standard");m=new Material(s);Texture2D t=d==null?null:TextureManager.Get(d.Texture);if(t!=null){m.mainTexture=t;t.wrapMode=TextureWrapMode.Repeat;t.filterMode=FilterMode.Point;} if(d!=null && d.Transparent){m.SetFloat("_Surface",1f);m.renderQueue=3000;}materials[key]=m;return m;}
    }
}
