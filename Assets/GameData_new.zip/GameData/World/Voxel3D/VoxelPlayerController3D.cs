using Game.InputSupport;
using UnityEngine;
using Game.PlayerStats;

namespace Game.World.Voxel3D
{
    /// <summary>
    /// First-person voxel controller with Minecraft-like mouse look.
    /// It lives on the dedicated 3D motor; the original 2D Player stays as a child so
    /// inventory/stats/model remain the same between dimensions.
    /// </summary>
    [DefaultExecutionOrder(30000)]
    public sealed class VoxelPlayerController3D : MonoBehaviour
    {
        [Header("Movement")]
        public float walkSpeed = 4.7f;
        public float runSpeed = 7.4f;
        public float jumpSpeed = 7.2f;
        public float gravity = 22f;

        [Header("Look")]
        public float mouseSensitivity = 2.0f;
        public float eyeHeight = 1.62f;
        public float thirdPersonDistance = 4.2f;
        public float thirdPersonHeight = .18f;

        private CharacterController cc;
        private Camera cam;
        private Transform playerVisualRoot;
        private float yaw;
        private float pitch;
        private float verticalVelocity;
        private bool thirdPerson;
        private Renderer[] playerRenderers;
        private PlayerStats.PlayerStats stats;
        private float fallApex;
        private bool falling;

        public bool IsGrounded => cc != null && cc.isGrounded;
        public bool ThirdPerson => thirdPerson;

        public bool Initialize(Camera camera, Transform visualRoot)
        {
            Game.InputSupport.Mobile.MobileGameplayControls.EnsureInstalled();
            cam = camera;
            playerVisualRoot = visualRoot;

            cc = GetComponent<CharacterController>();
            if (cc == null)
                cc = gameObject.AddComponent<CharacterController>();

            if (cc == null)
            {
                Debug.LogError("VOXEL3D PLAYER: CharacterController could not be created on dedicated motor object '" + gameObject.name + "'.");
                enabled = false;
                return false;
            }

            if (cam == null)
            {
                Debug.LogError("VOXEL3D PLAYER: Camera is null.");
                enabled = false;
                return false;
            }

            stats = playerVisualRoot != null ? playerVisualRoot.GetComponent<PlayerStats.PlayerStats>() : null;
            playerRenderers = playerVisualRoot != null
                ? playerVisualRoot.GetComponentsInChildren<Renderer>(true)
                : new Renderer[0];

            cc.height = 1.8f;
            cc.radius = .30f;
            cc.center = new Vector3(0f, .9f, 0f);
            cc.stepOffset = .5f;
            cc.slopeLimit = 58f;
            cc.skinWidth = .04f;
            cc.minMoveDistance = 0f;
            cc.enabled = true;

            yaw = transform.eulerAngles.y;
            pitch = 0f;

            cam.orthographic = false;
            cam.fieldOfView = 70f;
            cam.nearClipPlane = .04f;

            // Android/iOS have no desktop pointer to lock. The mobile right
            // stick controls yaw/pitch directly instead.
            LockMouse(!GameInput.MobileEnabled);
            ApplyViewMode();
            return true;
        }

        private void Update()
        {
            if (cc == null || cam == null)
                return;
            bool uiOpen = Game.UI.Settings.SettingsTabsController.IsOpen ||
                Time.timeScale < 0.001f ||
                (Game.Inventory.UI.InventoryUI.Instance != null && Game.Inventory.UI.InventoryUI.Instance.IsOpen);
            if (uiOpen)
            {
                if (UnityEngine.Cursor.lockState == CursorLockMode.Locked) LockMouse(false);
                return;
            }
            if (!GameInput.MobileEnabled && GameInput.GamepadConnected && !GameInput.Pressed(GameAction.Pause) &&
                UnityEngine.Cursor.lockState != CursorLockMode.Locked &&
                !Game.GameplaySystems.Respawn.DeathScreenUI.IsVisible)
                LockMouse(true);

            // ESC frees the mouse for menus/editor UI. A left click captures it again.
            if (GameInput.Pressed(GameAction.Pause))
                LockMouse(false);
            else if (!GameInput.MobileEnabled && UnityEngine.Cursor.lockState != CursorLockMode.Locked && GameInput.Pressed(GameAction.Attack))
                LockMouse(true);

            if (GameInput.Pressed(GameAction.Toggle3DView))
            {
                thirdPerson = !thirdPerson;
                ApplyViewMode();
            }

            if (GameInput.MobileEnabled)
            {
                // Consistent angular speed independent of phone frame rate.
                Vector2 stick = GameInput.Look;
                yaw += stick.x * 140f * Time.deltaTime;
                pitch -= stick.y * 110f * Time.deltaTime;
                pitch = Mathf.Clamp(pitch, -89f, 89f);
            }
            else if (UnityEngine.Cursor.lockState == CursorLockMode.Locked)
            {
                yaw += (Input.GetAxisRaw("Mouse X") + GameInput.Look.x) * mouseSensitivity;
                pitch -= (Input.GetAxisRaw("Mouse Y") + GameInput.Look.y) * mouseSensitivity;
                pitch = Mathf.Clamp(pitch, -89f, 89f);
            }

            transform.rotation = Quaternion.Euler(0f, yaw, 0f);

            float h = GameInput.Horizontal;
            float v = GameInput.Vertical;
            Vector3 wish = transform.right * h + transform.forward * v;
            if (wish.sqrMagnitude > 1f)
                wish.Normalize();

            bool running = Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl);
            float speed = running ? runSpeed : walkSpeed;

            if (cc.isGrounded)
            {
                if (falling)
                    ApplyFallDamage(fallApex - transform.position.y);

                falling = false;
                if (verticalVelocity < 0f)
                    verticalVelocity = -2f;

                if (GameInput.Pressed(GameAction.Jump))
                    verticalVelocity = jumpSpeed;
            }
            else
            {
                if (!falling)
                {
                    falling = true;
                    fallApex = transform.position.y;
                }
                else if (transform.position.y > fallApex)
                {
                    fallApex = transform.position.y;
                }

                verticalVelocity -= gravity * Time.deltaTime;
            }

            cc.Move((wish * speed + Vector3.up * verticalVelocity) * Time.deltaTime);
        }

        // Camera is written at the end of the frame so old 2D camera followers cannot
        // pull it sideways after the mouse-look code runs.
        private void LateUpdate()
        {
            UpdateCamera();
        }

        private void UpdateCamera()
        {
            if (cam == null)
                return;

            Quaternion lookRotation = Quaternion.Euler(pitch, yaw, 0f);
            Vector3 eye = transform.position + Vector3.up * eyeHeight;

            if (!thirdPerson)
            {
                cam.transform.SetPositionAndRotation(eye, lookRotation);
                return;
            }

            Vector3 lookForward = lookRotation * Vector3.forward;
            Vector3 desired = eye - lookForward * thirdPersonDistance + Vector3.up * thirdPersonHeight;
            Vector3 delta = desired - eye;
            float distance = delta.magnitude;

            if (distance > .001f)
            {
                RaycastHit hit;
                if (UnityEngine.Physics.SphereCast(eye, .16f, delta / distance, out hit, distance, ~(1 << 2), QueryTriggerInteraction.Ignore))
                    desired = hit.point + hit.normal * .12f;
            }

            cam.transform.SetPositionAndRotation(desired, lookRotation);
        }

        private void ApplyViewMode()
        {
            if (playerRenderers != null)
            {
                foreach (Renderer r in playerRenderers)
                {
                    if (r != null)
                        r.enabled = thirdPerson;
                }
            }

            UpdateCamera();
        }

        private void ApplyFallDamage(float distance)
        {
            if (stats == null || distance <= 6f)
                return;

            float damage = 5f + Mathf.Floor(Mathf.Max(0f, distance - 6f)) * 5f;
            stats.TakeDamage(damage);
        }

        private static void LockMouse(bool locked)
        {
            UnityEngine.Cursor.lockState = locked ? CursorLockMode.Locked : CursorLockMode.None;
            UnityEngine.Cursor.visible = !locked;
        }

        private void OnDisable()
        {
            LockMouse(false);
        }
    }
}
