using UnityEngine;
using Game.World.Generation;
using Game.World;

namespace Game.World.Weather
{
    // Ground-anchored fog ribbon. The camera only chooses which horizontal cells are
    // visible: all fog vertices and noise stay in absolute world coordinates.
    public sealed class PixelFogRenderer : MonoBehaviour
    {
        [SerializeField] private float fogHeight = 8f;
        [SerializeField] private int sampleStep = 2;
        private Camera targetCamera;
        private WorldGenerator generator;
        private Mesh mesh;
        private Material material;
        private MeshRenderer meshRenderer;
        private bool activeFog;
        private int previousLeft = int.MinValue;
        private int previousRight = int.MinValue;
        private float nextRebuild;

        public void Initialize(Camera camera, WorldGenerator worldGenerator)
        {
            targetCamera = camera;
            generator = worldGenerator;
            if (meshRenderer != null) return;
            Shader shader = Shader.Find("Game/TelderPixelFog");
            if (shader == null)
            {
                Debug.LogWarning("FOG: Game/TelderPixelFog shader unavailable");
                return;
            }
            GameObject go = new GameObject("[Runtime] Surface Fog Ribbon");
            go.transform.SetParent(transform, false);
            go.transform.localPosition = Vector3.zero;
            mesh = new Mesh { name = "TelderGroundFogRibbon" };
            mesh.MarkDynamic();
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            meshRenderer = go.AddComponent<MeshRenderer>();
            material = new Material(shader) { name = "Telder World Anchored Fog" };
            material.SetFloat("_PixelSize", 0.11f);
            material.SetFloat("_Speed", 0.15f);
            meshRenderer.sharedMaterial = material;
            meshRenderer.sortingLayerName = "Default";
            meshRenderer.sortingOrder = 5300;
            go.SetActive(activeFog);
        }

        public void SetFog(bool enabled, Color color, float intensity)
        {
            activeFog = enabled;
            if (meshRenderer != null)
                meshRenderer.gameObject.SetActive(enabled);
            if (material != null)
            {
                material.SetColor("_FogColor", color);
                material.SetFloat("_Intensity", Mathf.Clamp(intensity, 0f, 1.5f));
            }
            if (enabled) previousLeft = int.MinValue;
        }

        private void LateUpdate()
        {
            if (!activeFog || mesh == null || generator == null || targetCamera == null || !targetCamera.orthographic)
                return;

            // Vertical camera movement (jump, falling, climbing) NEVER affects the ribbon.
            float width = 2f * targetCamera.orthographicSize * targetCamera.aspect;
            int step = Mathf.Max(1, sampleStep);
            int left = Mathf.FloorToInt((targetCamera.transform.position.x - width * 0.5f - 14f) / (float)(step*4)) * step*4;
            int right = Mathf.CeilToInt((targetCamera.transform.position.x + width * 0.5f + 14f) / (float)(step*4)) * step*4;
            if (left == previousLeft && right == previousRight) return;
            if (Time.unscaledTime < nextRebuild) return;
            nextRebuild = Time.unscaledTime + 0.06f;
            previousLeft = left;
            previousRight = right;
            int segments = Mathf.Max(1, (right - left) / step);
            Vector3[] vertices = new Vector3[(segments+1)*2];
            Vector2[] uv = new Vector2[vertices.Length];
            int[] triangles = new int[segments*6];
            for (int i = 0; i <= segments; ++i)
            {
                int x = left + i*step;
                float terrainY = ResolveSurfaceHeight(x);
                vertices[i*2] = new Vector3(x, terrainY + 0.05f, 0f);
                vertices[i*2+1] = new Vector3(x, terrainY + fogHeight, 0f);
                float u = i / (float)segments;
                uv[i*2] = new Vector2(u, 0f);
                uv[i*2+1] = new Vector2(u, 1f);
                if (i == segments) continue;
                int j = i*6;
                int k = i*2;
                triangles[j] = k;
                triangles[j+1] = k+1;
                triangles[j+2] = k+2;
                triangles[j+3] = k+1;
                triangles[j+4] = k+3;
                triangles[j+5] = k+2;
            }
            mesh.Clear(false);
            mesh.vertices = vertices;
            mesh.uv = uv;
            mesh.triangles = triangles;
            mesh.RecalculateBounds();
        }

        // Find the ACTUAL block surface, not just the generation estimate. Biome
        // modifiers, saved block changes and structures can offset the generator
        // surface by 10-20 tiles. Only sampled when rebuilding the ribbon.
        private float ResolveSurfaceHeight(int x)
        {
            int estimate = generator.GetSurfaceHeight(x);
            WorldManager manager = WorldManager.Instance;
            Game.World.World world = manager != null ? manager.GetWorld() : null;
            if (world == null) return estimate + 1f;

            // The generator height may be 15+ cells below the actual saved terrain.
            // Look upward first and find the highest continuous terrain column.
            int top = estimate + 96;
            int bottom = estimate - 20;
            for (int y = top; y >= bottom; --y)
            {
                if (world.GetBlock(x, y) == 0) continue;
                if (world.GetBlock(x, y + 1) != 0) continue;
                if (world.GetBlock(x, y - 1) == 0 || world.GetBlock(x, y - 2) == 0)
                    continue;
                return y + 1f;
            }
            return estimate + 1f;
        }

        private void OnDestroy()
        {
            if (material != null) Destroy(material);
            if (mesh != null) Destroy(mesh);
        }
    }
}
