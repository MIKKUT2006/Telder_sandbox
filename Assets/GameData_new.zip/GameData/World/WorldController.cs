using UnityEngine;
using Game.World.Loading;

namespace Game.World
{
    public class WorldController : MonoBehaviour
    {
        // =====================================================
        // PLAYER
        // =====================================================

        [Header("Player")]
        [SerializeField]
        private Transform player;


        // =====================================================
        // REFERENCES
        // =====================================================

        private WorldManager worldManager;

        private ChunkLoader loader;


        // =====================================================
        // STATE
        // =====================================================

        private int lastChunkX;

        private int lastChunkY;

        private bool hasLastChunk;


        // =====================================================
        // START
        // =====================================================

        private void Start()
        {
            // 3D dimensions use VoxelChunkLoader3D instead of the classic 2D ChunkLoader.
            // Do not initialize the 2D world controller in a voxel dimension.
            if (Game.World.Dimensions.DimensionTravelRuntime.Current != null &&
                Game.World.Dimensions.DimensionTravelRuntime.Current.Is3D)
            {
                enabled = false;
                return;
            }

            worldManager =
                WorldManager.Instance;


            if (worldManager == null)
            {
                Debug.LogError(
                    "WORLD CONTROLLER: WorldManager is null."
                );

                return;
            }


            loader =
                worldManager.GetLoader();


            if (loader == null)
            {
                Debug.LogError(
                    "WORLD CONTROLLER: ChunkLoader is null."
                );

                return;
            }


            if (player == null)
            {
                Debug.LogError(
                    "WORLD CONTROLLER: Player reference is null."
                );

                return;
            }


            Debug.Log(
                "WORLD CONTROLLER: Initialized."
            );


            // ��������� ��������
            UpdateChunks();
        }


        // =====================================================
        // UPDATE
        // =====================================================

        private void Update()
        {
            if (loader == null)
            {
                return;
            }


            if (player == null)
            {
                return;
            }


            // �������� ����������,
            // ��� ��������� �����.
            UpdateChunks();


            // ������������ ������� ��������.
            loader.Process();
        }


        // =====================================================
        // UPDATE CHUNKS
        // =====================================================

        private void UpdateChunks()
        {
            if (player == null)
            {
                return;
            }


            int chunkX =
                Mathf.FloorToInt(
                    player.position.x /
                    Chunk.SizeX
                );


            int chunkY =
                Mathf.FloorToInt(
                    player.position.y /
                    Chunk.SizeY
                );


            // ���� ����� �� ���
            // � ��� �� �����,
            // ����� ������� �������� �� �����.
            if (
                hasLastChunk &&
                chunkX == lastChunkX &&
                chunkY == lastChunkY
            )
            {
                return;
            }


            lastChunkX =
                chunkX;


            lastChunkY =
                chunkY;


            hasLastChunk =
                true;


            Debug.Log(
                "WORLD CONTROLLER: Player chunk = " +
                chunkX +
                ", " +
                chunkY
            );


            loader.SetPlayerChunk(
                chunkX,
                chunkY
            );
        }
    }
}