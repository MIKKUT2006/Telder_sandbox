using Game.InputSupport;
using System;
using System.Collections.Generic;

using TMPro;

using UnityEngine;
using UnityEngine.UI;

using Game.Chests.UI;
using Game.GameplaySystems.Furnace;


namespace Game.Inventory.UI
{

    [Serializable]
    public sealed class FurnaceInventoryAppearance
    {
        [Header("Textures")]
        [Tooltip("Optional furnace panel texture. Leave empty to use only Panel Color.")]
        public Sprite PanelSprite;

        [Tooltip("Optional input-slot texture. Falls back to the main inventory slot texture.")]
        public Sprite InputSlotSprite;

        [Tooltip("Optional fuel-slot texture. Falls back to the main inventory slot texture.")]
        public Sprite FuelSlotSprite;

        [Tooltip("Optional output-slot texture. Falls back to the main inventory slot texture.")]
        public Sprite OutputSlotSprite;

        [Tooltip("Optional full frame texture used as the burning-fuel progress outline. A transparent frame sprite works best.")]
        public Sprite BurnBorderSprite;

        [Tooltip("Optional background texture for the item smelting progress strip.")]
        public Sprite SmeltProgressBackgroundSprite;

        [Tooltip("Optional fill texture for the item smelting progress strip.")]
        public Sprite SmeltProgressFillSprite;

        [Header("Colors")]
        public Color PanelColor =
            new Color(0.025f, 0.025f, 0.035f, 0.92f);

        public Color InputSlotColor =
            new Color(0.07f, 0.07f, 0.085f, 0.96f);

        public Color FuelSlotColor =
            new Color(0.07f, 0.07f, 0.085f, 0.96f);

        public Color OutputSlotColor =
            new Color(0.07f, 0.07f, 0.085f, 0.96f);

        public Color SlotOutlineColor =
            new Color(1f, 1f, 1f, 0.18f);

        public Color BurnBorderColor =
            new Color32(255, 122, 38, 255);

        public Color SmeltProgressBackgroundColor =
            new Color(1f, 1f, 1f, 0.12f);

        public Color SmeltProgressFillColor =
            new Color32(187, 122, 87, 255);

        public Color IconColor =
            Color.white;

        public Color CountTextColor =
            Color.white;

        [Header("Layout")]
        [Tooltip("Compact furnace panel size shown above the normal inventory.")]
        public Vector2 PanelSize =
            new Vector2(190f, 132f);

        [Range(36f, 96f)]
        public float SlotSize =
            54f;

        [Tooltip("Distance between the top of the inventory panel and the furnace panel.")]
        public float InventoryGap =
            12f;

        [Tooltip("Additional position offset for the whole furnace panel.")]
        public Vector2 PanelOffset =
            Vector2.zero;

        public Vector2 InputSlotPosition =
            new Vector2(-46f, 31f);

        public Vector2 FuelSlotPosition =
            new Vector2(-46f, -31f);

        public Vector2 OutputSlotPosition =
            new Vector2(46f, 0f);

        public Vector2 SmeltProgressPosition =
            new Vector2(0f, 0f);

        public Vector2 SmeltProgressSize =
            new Vector2(28f, 6f);

        [Header("Outline")]
        [Range(1f, 8f)]
        public float SlotOutlineDistance =
            1f;

        [Range(1f, 12f)]
        public float BurnBorderThickness =
            5f;

        [Range(0f, 12f)]
        public float BurnBorderPadding =
            3f;
    }


    public class InventoryUI :
        MonoBehaviour
    {

        // =====================================================
        // SINGLETON
        // =====================================================

        public static InventoryUI Instance
        {
            get;
            private set;
        }


        // =====================================================
        // INVENTORY
        // =====================================================

        [Header("Inventory")]

        [SerializeField]
        private PlayerInventory inventory;


        // =====================================================
        // PANELS
        // =====================================================

        [Header("Panels")]

        [SerializeField]
        private GameObject inventoryPanel;


        // =====================================================
        // SLOTS
        // =====================================================

        [Header("Hotbar - 9 slots")]

        [SerializeField]
        private InventorySlotUI[] hotbarSlots;


        [Header("Storage - 36 slots")]

        [SerializeField]
        private InventorySlotUI[] storageSlots;


        // =====================================================
        // APPEARANCE
        // =====================================================

        [Header("Slot Appearance")]

        [Tooltip("Обычная текстура ячейки хотбара.")]
        [SerializeField]
        private Sprite hotbarSlotSprite;


        [Tooltip("Обычная текстура ячейки основного инвентаря.")]
        [SerializeField]
        private Sprite storageSlotSprite;


        [Tooltip("Необязательно. Отдельная текстура выбранной ячейки хотбара.")]
        [SerializeField]
        private Sprite selectedHotbarSlotSprite;


        [Tooltip("1.03 = +3%, 1.04 = +4%, 1.05 = +5%.")]
        [SerializeField]
        [Range(1f, 1.1f)]
        private float selectedHotbarScale =
            1.04f;


        // =====================================================
        // FURNACE APPEARANCE
        // =====================================================

        [Header("Furnace UI Appearance")]
        [Tooltip("All furnace-specific textures, colors and layout values. The furnace uses the normal inventory slot texture as fallback.")]
        [SerializeField]
        private FurnaceInventoryAppearance furnaceAppearance =
            new FurnaceInventoryAppearance();


        // =====================================================
        // CURSOR
        // =====================================================

        [Header("Cursor Item")]

        [SerializeField]
        private RectTransform cursorItemRoot;


        [SerializeField]
        private Image cursorIcon;


        [SerializeField]
        private TMP_Text cursorCount;


        // =====================================================
        // STATE
        // =====================================================

        private readonly ItemStack cursorStack =
            new ItemStack();


        private InventorySlotUI hoveredSlot;


        // =====================================================
        // RIGHT DRAG
        // =====================================================

        private bool rightDragActive;


        private readonly HashSet<int>
            rightDragVisited =
            new HashSet<int>();


        public bool IsOpen
        {
            get;
            private set;
        }


        public ItemStack CursorStack =>
            cursorStack;


        public PlayerInventory PlayerInventory =>
            inventory;


        public RectTransform InventoryPanelRect =>
            inventoryPanel != null
                ? inventoryPanel.transform as RectTransform
                : null;


        public Sprite StorageSlotSprite =>
            storageSlotSprite;


        public TMP_FontAsset InterfaceFont =>
            cursorCount != null
                ? cursorCount.font
                : null;


        public FurnaceInventoryAppearance FurnaceAppearance
        {
            get
            {
                if (furnaceAppearance == null)
                {
                    furnaceAppearance =
                        new FurnaceInventoryAppearance();
                }

                return furnaceAppearance;
            }
        }


        public void RefreshCursorExternal()
        {

            RefreshCursor();

        }


        // =====================================================
        // UNITY
        // =====================================================

        private void Awake()
        {

            Instance =
                this;


            IsOpen =
                false;


            if (
                inventoryPanel != null
            )
            {

                inventoryPanel.SetActive(
                    false
                );

            }


            if (
                cursorItemRoot != null
            )
            {

                cursorItemRoot.gameObject.SetActive(
                    false
                );

            }

        }


        private void Start()
        {

            if (
                inventory == null
            )
            {

                Debug.LogError(
                    "INVENTORY UI: PlayerInventory is not assigned."
                );


                return;

            }


            BindSlots();


            inventory.Changed +=
                RefreshAll;


            RefreshAll();

        }


        private void OnDestroy()
        {

            if (
                inventory != null
            )
            {

                inventory.Changed -=
                    RefreshAll;

            }


            if (
                Instance == this
            )
            {

                Instance =
                    null;

            }

        }


        private void Update()
        {

            if (
                inventory == null
            )
            {

                return;

            }


            HandleInventoryKey();


            HandleHotbarKeys();


            HandleMouseWheel();


            if (
                !IsOpen
            )
            {

                return;

            }


            UpdateCursorPosition();


            HandleDropKey();


            HandleRightDrag();

        }


        // =====================================================
        // BIND
        // =====================================================

        private void BindSlots()
        {

            if (
                hotbarSlots != null
            )
            {

                for (
                    int i = 0;
                    i < hotbarSlots.Length
                    &&
                    i < PlayerInventory.HotbarSize;
                    i++
                )
                {

                    if (
                        hotbarSlots[i] != null
                    )
                    {

                        hotbarSlots[i].Bind(
                            this,
                            i
                        );

                    }

                }

            }


            if (
                storageSlots != null
            )
            {

                for (
                    int i = 0;
                    i < storageSlots.Length
                    &&
                    i < PlayerInventory.StorageSize;
                    i++
                )
                {

                    if (
                        storageSlots[i] != null
                    )
                    {

                        storageSlots[i].Bind(
                            this,
                            PlayerInventory.HotbarSize +
                            i
                        );

                    }

                }

            }

        }


        // =====================================================
        // OPEN / CLOSE
        // =====================================================

        private void HandleInventoryKey()
        {

            if (
                !GameInput.Pressed(GameAction.Inventory)
            )
            {

                return;

            }


            if (
                IsOpen
            )
            {

                CloseInventory();

            }
            else
            {

                OpenInventory();

            }

        }


        public void OpenInventory()
        {
            if (!IsOpen) Game.Audio.TelderAudioSystem.Play("ui.inventory.open");
            IsOpen =
                true;


            hoveredSlot =
                null;


            rightDragActive =
                false;


            rightDragVisited.Clear();


            if (
                inventoryPanel != null
            )
            {

                inventoryPanel.SetActive(
                    true
                );

            }


            RefreshAll();

        }


        public void CloseInventory()
        {

            rightDragActive =
                false;


            rightDragVisited.Clear();


            if (
                !cursorStack.IsEmpty
            )
            {

                bool dropped =
                    inventory.DropCursorStack(
                        cursorStack
                    );


                if (
                    !dropped
                )
                {

                    return;

                }

            }


            if (
                FurnaceRuntime.Instance != null
                &&
                FurnaceRuntime.Instance.IsUIOpen
            )
            {
                FurnaceRuntime.Instance.CloseUI();
            }


            IsOpen =
                false;
            Game.Audio.TelderAudioSystem.Play("ui.inventory.close");

            hoveredSlot =
                null;


            if (
                inventoryPanel != null
            )
            {

                inventoryPanel.SetActive(
                    false
                );

            }


            RefreshCursor();


            RefreshAll();

        }


        // =====================================================
        // HOTBAR INPUT
        // =====================================================

        private void HandleHotbarKeys()
        {
            if (Game.UI.Settings.SettingsTabsController.IsOpen || Time.timeScale < 0.001f) return;
            if (!IsOpen)
            {
                int offset = GameInput.Pressed(GameAction.HotbarNext) ? 1 :
                    GameInput.Pressed(GameAction.HotbarPrevious) ? -1 : 0;
                if (offset != 0)
                {
                    int index = (inventory.SelectedHotbarIndex + offset + PlayerInventory.HotbarSize)
                        % PlayerInventory.HotbarSize;
                    inventory.SelectHotbarSlot(index);
                }
            }

            for (
                int i = 0;
                i < PlayerInventory.HotbarSize;
                i++
            )
            {

                if (GameInput.Pressed((GameAction)((int)GameAction.Hotbar1 + i)))
                {

                    inventory.SelectHotbarSlot(
                        i
                    );

                }

            }

        }


        private void HandleMouseWheel()
        {
            if (Game.UI.Settings.SettingsTabsController.IsOpen || Time.timeScale < 0.001f) return;

            float wheel =
                Input.mouseScrollDelta.y;


            if (
                Mathf.Abs(
                    wheel
                ) <
                0.01f
            )
            {

                return;

            }


            int index =
                inventory.SelectedHotbarIndex;


            index +=
                wheel > 0f
                    ? -1
                    : 1;


            if (
                index < 0
            )
            {

                index =
                    PlayerInventory.HotbarSize -
                    1;

            }


            if (
                index >=
                PlayerInventory.HotbarSize
            )
            {

                index =
                    0;

            }


            inventory.SelectHotbarSlot(
                index
            );

        }


        // =====================================================
        // LEFT CLICK / SHIFT CLICK
        // =====================================================

        public void GamepadQuickMoveSlot(int slotIndex)
        {
            if (!IsOpen || inventory == null) return;
            if (FurnaceRuntime.Instance != null && FurnaceRuntime.Instance.IsUIOpen &&
                FurnaceRuntime.Instance.QuickMoveFromPlayer(slotIndex)) return;
            if (ChestUIController.Instance != null && ChestUIController.Instance.IsOpen)
            {
                ChestUIController.Instance.QuickMoveFromPlayer(slotIndex);
                return;
            }
            inventory.QuickMove(slotIndex);
        }

        public void LeftClick(
            int slotIndex
        )
        {

            if (
                !IsOpen
            )
            {

                return;

            }


            bool shift =
                Input.GetKey(
                    KeyCode.LeftShift
                )
                ||
                Input.GetKey(
                    KeyCode.RightShift
                );


            // Shift-click работает только,
            // когда на курсоре ничего не висит.
            if (
                shift
                &&
                cursorStack.IsEmpty
            )
            {

                // Furnace has priority while its compact panel is open.
                // Smeltable items go to the input slot, fuel goes to the
                // fuel slot. Items rejected by the furnace keep the normal
                // hotbar <-> storage quick-move behaviour.
                if (
                    FurnaceRuntime.Instance != null
                    &&
                    FurnaceRuntime.Instance.IsUIOpen
                    &&
                    FurnaceRuntime.Instance.QuickMoveFromPlayer(
                        slotIndex
                    )
                )
                {
                    return;
                }


                // Когда открыт сундук, Shift + ЛКМ по любому
                // слоту игрока переносит предметы именно
                // в сундук, а не между hotbar/storage.
                if (
                    ChestUIController.Instance != null
                    &&
                    ChestUIController.Instance.IsOpen
                )
                {

                    ChestUIController.Instance
                        .QuickMoveFromPlayer(
                            slotIndex
                        );


                    return;

                }


                inventory.QuickMove(
                    slotIndex
                );


                return;

            }


            inventory.LeftClickSlot(
                slotIndex,
                cursorStack
            );


            RefreshCursor();

        }


        // =====================================================
        // RIGHT CLICK / START RIGHT DRAG
        // =====================================================

        public void RightPointerDown(
            int slotIndex
        )
        {

            if (
                !IsOpen
            )
            {

                return;

            }


            // Пустой курсор:
            // обычный ПКМ = взять половину.
            if (
                cursorStack.IsEmpty
            )
            {

                inventory.RightClickSlot(
                    slotIndex,
                    cursorStack
                );


                RefreshCursor();


                return;

            }


            // На курсоре есть предмет:
            // начинаем раздачу по одному.
            rightDragActive =
                true;


            rightDragVisited.Clear();


            TryRightDragSlot(
                slotIndex
            );

        }


        private void HandleRightDrag()
        {

            if (
                !rightDragActive
            )
            {

                return;

            }


            if (
                !Input.GetMouseButton(1)
                ||
                cursorStack.IsEmpty
            )
            {

                rightDragActive =
                    false;


                rightDragVisited.Clear();


                return;

            }


            if (
                hoveredSlot != null
            )
            {

                TryRightDragSlot(
                    hoveredSlot.SlotIndex
                );

            }

        }


        private void TryRightDragSlot(
            int slotIndex
        )
        {

            if (
                rightDragVisited.Contains(
                    slotIndex
                )
            )
            {

                return;

            }


            // Один слот за одно удержание ПКМ
            // посещается только один раз.
            rightDragVisited.Add(
                slotIndex
            );


            inventory.PlaceOneFromCursor(
                slotIndex,
                cursorStack
            );


            RefreshCursor();

        }


        // =====================================================
        // HOVER
        // =====================================================

        public void SetHoveredSlot(
            InventorySlotUI slot
        )
        {

            hoveredSlot =
                slot;


            if (
                rightDragActive
                &&
                Input.GetMouseButton(1)
                &&
                slot != null
            )
            {

                TryRightDragSlot(
                    slot.SlotIndex
                );

            }

        }


        public void ClearHoveredSlot(
            InventorySlotUI slot
        )
        {

            if (
                hoveredSlot ==
                slot
            )
            {

                hoveredSlot =
                    null;

            }

        }


        // =====================================================
        // G DROP
        // =====================================================

        private void HandleDropKey()
        {

            if (
                !GameInput.Pressed(GameAction.Drop)
                ||
                hoveredSlot == null
            )
            {

                return;

            }


            inventory.DropOneFromSlot(
                hoveredSlot.SlotIndex
            );

        }


        // =====================================================
        // CURSOR
        // =====================================================

        private void UpdateCursorPosition()
        {

            if (
                cursorItemRoot != null
            )
            {

                cursorItemRoot.position =
                    GameInput.PointerPosition;

            }

        }


        private void RefreshCursor()
        {

            if (
                cursorItemRoot == null
            )
            {

                return;

            }


            bool visible =
                IsOpen
                &&
                !cursorStack.IsEmpty;


            cursorItemRoot.gameObject.SetActive(
                visible
            );


            if (
                !visible
            )
            {

                return;

            }


            if (
                cursorIcon != null
            )
            {

                cursorIcon.sprite =
                    ItemIconProvider.GetIcon(
                        cursorStack.ItemId
                    );


                cursorIcon.enabled =
                    cursorIcon.sprite != null;

            }


            if (
                cursorCount != null
            )
            {

                cursorCount.text =
                    cursorStack.Count > 1
                        ? cursorStack.Count.ToString()
                        : string.Empty;

            }

        }


        // =====================================================
        // REFRESH
        // =====================================================

        private void RefreshAll()
        {

            if (
                inventory == null
            )
            {

                return;

            }


            // =================================================
            // HOTBAR
            // =================================================

            if (
                hotbarSlots != null
            )
            {

                for (
                    int i = 0;
                    i < hotbarSlots.Length
                    &&
                    i < PlayerInventory.HotbarSize;
                    i++
                )
                {

                    InventorySlotUI slot =
                        hotbarSlots[i];


                    if (
                        slot == null
                    )
                    {

                        continue;

                    }


                    bool selected =
                        i ==
                        inventory.SelectedHotbarIndex;


                    slot.ApplyBackground(
                        hotbarSlotSprite,
                        selectedHotbarSlotSprite,
                        selected
                    );


                    slot.Refresh(
                        inventory.GetSlot(
                            i
                        ),
                        selected,
                        selectedHotbarScale
                    );

                }

            }


            // =================================================
            // STORAGE
            // =================================================

            if (
                storageSlots != null
            )
            {

                for (
                    int i = 0;
                    i < storageSlots.Length
                    &&
                    i < PlayerInventory.StorageSize;
                    i++
                )
                {

                    InventorySlotUI slot =
                        storageSlots[i];


                    if (
                        slot == null
                    )
                    {

                        continue;

                    }


                    int inventoryIndex =
                        PlayerInventory.HotbarSize +
                        i;


                    slot.ApplyBackground(
                        storageSlotSprite,
                        null,
                        false
                    );


                    slot.Refresh(
                        inventory.GetSlot(
                            inventoryIndex
                        ),
                        false,
                        1f
                    );

                }

            }


            RefreshCursor();

        }

    }

}
