using UnityEngine;
using Game.World;

namespace Game.Entities.Boss
{
    /// <summary>A ground-following, single-hit wave propagating out from a boss slam.</summary>
    public sealed class BossShockwave : MonoBehaviour
    {
        private static Sprite sprite;
        private SpriteRenderer visual;
        private float direction;
        private float remaining;
        private float speed;
        private float damage;
        private bool hitPlayer;

        public static void Spawn(Vector2 origin, float sign, float range, float waveSpeed,
            float waveDamage, string textureName = null)
        {
            GameObject go = new GameObject("Boss ground shockwave");
            go.transform.position = origin + Vector2.up * .28f;
            BossShockwave wave = go.AddComponent<BossShockwave>();
            wave.direction = sign;
            wave.remaining = Mathf.Max(1f, range);
            wave.speed = Mathf.Max(1f, waveSpeed);
            wave.damage = Mathf.Max(0f, waveDamage);
            wave.visual.flipX = sign < 0f;
            wave.ApplyTexture(textureName);
        }
        private void Awake()
        {
            // Keep the renderer on a child: pivot adjustments must not move
            // the root transform used by terrain tracking and hit detection.
            GameObject visualObject = new GameObject("Wave visual");
            visualObject.transform.SetParent(transform, false);
            visual = visualObject.AddComponent<SpriteRenderer>();
            visual.sprite = MakeSprite();
            visual.sortingLayerName = "Default";
            visual.sortingOrder = 190;
            visual.color = new Color(.67f,.43f,1f,1f);
            transform.localScale = new Vector3(1.05f, .75f, 1f);
        }
        private void ApplyTexture(string configuredTexture)
        {
            if (string.IsNullOrWhiteSpace(configuredTexture)) return;

            Sprite custom = BossSlamGroundParticles.TryGetConfiguredSprite(configuredTexture);
            if (custom == null) return; // Keep the original visual if PNG is missing.

            visual.sprite = custom;
            visual.color = Color.white; // Preserve the pixels/alpha of the supplied texture.
            // Custom PNG sprites use a centered pivot, whereas the built-in
            // wave has its pivot at the bottom. Keep every custom wave grounded.
            visual.transform.localPosition = new Vector3(0f, -custom.bounds.min.y, 0f);
            if (custom.texture != null)
                custom.texture.filterMode = FilterMode.Point;
        }

        private static Sprite MakeSprite()
        {
            if (sprite != null) return sprite;
            Texture2D texture = new Texture2D(16,16,TextureFormat.RGBA32,false);
            texture.filterMode = FilterMode.Point;
            Color32[] pixels = new Color32[256];
            for (int x=0;x<16;x++)
                for (int y=0;y<16;y++)
                    if (y <= 12 - Mathf.Abs(8-x) && y > 0 && (x + y) % 5 != 0)
                        pixels[x+y*16] = new Color32(220,182,255,255);
            texture.SetPixels32(pixels); texture.Apply();
            sprite = Sprite.Create(texture,new Rect(0,0,16,16),new Vector2(.5f,0f),16);
            return sprite;
        }
        private void FixedUpdate()
        {
            float step = speed * Time.fixedDeltaTime;
            if (remaining <= 0f) { Destroy(gameObject); return; }
            remaining -= step;
            var manager = WorldManager.Instance;
            if (manager == null || manager.GetWorld() == null || manager.GetWorldCollision() == null)
            { Destroy(gameObject); return; }
            Vector2 pos = transform.position;
            pos.x += direction * step;
            int x = Mathf.FloorToInt(pos.x);
            // Track terrain height, with bounded search for slopes/low ledges.
            int estimate = Mathf.FloorToInt(pos.y);
            bool found = false;
            for (int y = estimate+2; y >= estimate-5; y--)
            {
                if (manager.GetWorldCollision().IsSolid(x,y-1) &&
                    !manager.GetWorldCollision().IsSolid(x,y))
                { pos.y = y + .1f; found=true; break; }
            }
            if (!found) { Destroy(gameObject); return; }
            transform.position = pos;
            var player = FindFirstObjectByType<Game.PlayerStats.PlayerStats>();
            if (!hitPlayer && player != null && !player.IsDead &&
                Mathf.Abs(player.transform.position.x - pos.x) < .75f &&
                Mathf.Abs(player.transform.position.y - pos.y) < 1.7f)
            { player.TakeDamage(damage); hitPlayer = true; }
        }
    }
}
